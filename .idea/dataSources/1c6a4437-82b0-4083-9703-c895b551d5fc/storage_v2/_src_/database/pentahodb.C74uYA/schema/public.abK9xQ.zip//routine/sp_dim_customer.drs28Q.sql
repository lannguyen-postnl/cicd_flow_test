CREATE PROCEDURE sp_dim_customer()
    SECURITY DEFINER
    LANGUAGE plpgsql
AS
$$






DECLARE
   _REC_duplicates 			record;
   _VAR_inserts 			int8;
   --_VAR_last_update_ts      timestamp := (SELECT MAX(s3_partition_ts) FROM prep_cbs_tom.orderline_invoiceinformation_customerrate);
BEGIN
	   -- IF _VAR_init = TRUE THEN
		TRUNCATE TABLE tom.dim_customer;
		RAISE WARNING 'WARNING: An Initiation has started and the table tom.dim_customer has been TRUNCATED.';
	   -- END IF;


	INSERT INTO tom.dim_customer
		SELECT
		*
		FROM
		(SELECT
			FNV_HASH(orderline_invoiceinformation_customerrate_customercode) as dim_customer_id_hid
			,orderline_invoiceinformation_customerrate_customercode as id_invoiceinformation_customercode_bk
			,CASE WHEN orderline_invoiceinformation_customerrate_customername='Koninklijke PostNL B.V. (NL export)' THEN 'Koninklijke PostNL B.V.' ELSE orderline_invoiceinformation_customerrate_customername END as customerrate_customername
			,orderline_invoiceinformation_customerrate_customerreference as customerrate_customerreference
		FROM ingest_db.prep_cbs_tom.orderline_invoiceinformation_customerrate
		)
		GROUP BY
		dim_customer_id_hid
		,id_invoiceinformation_customercode_bk
		,customerrate_customername
		,customerrate_customerreference
  ;

 GET DIAGNOSTICS _VAR_inserts := ROW_COUNT;
 RAISE INFO 'Update completed: % rows inserted in tom.dim_customer', _VAR_inserts;

     CALL admin.sp_pk_check_table( PG_Last_Query_ID() );
   		SELECT * INTO _REC_duplicates FROM #sp_pk_check_table;
    	IF _REC_duplicates.dupes_amount > 0 THEN
   		RAISE EXCEPTION 'Duplicates found'; RAISE INFO 'No duplicates found';
    	END IF;

    	EXCEPTION WHEN OTHERS THEN
        	IF SQLERRM = 'Duplicates found' THEN
         		RAISE EXCEPTION '% Duplicates found in total, for key values: %',_REC_duplicates.dupes_amount,_REC_duplicates.Duplicates_Check_PK;
            ELSE RAISE EXCEPTION 'Error %, State %', SQLERRM, SQLSTATE;
        	END IF;

END;






$$;

