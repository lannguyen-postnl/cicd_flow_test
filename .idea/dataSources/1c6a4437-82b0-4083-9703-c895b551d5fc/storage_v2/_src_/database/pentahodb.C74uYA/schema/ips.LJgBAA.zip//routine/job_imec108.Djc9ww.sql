CREATE PROCEDURE job_imec108(_var_init boolean)
    SECURITY DEFINER
    LANGUAGE plpgsql
AS
$$
BEGIN
	CALL ips.sp_imec108_staging(_VAR_init); -- init/flush_and_fill := FALSE
	CALL ips.sp_imec108(_VAR_init);

	RAISE INFO 'Procedure ips.job_imec108 is completed';
END; 
$$;

