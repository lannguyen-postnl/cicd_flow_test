CREATE PROCEDURE sp_imec_leg123_deduplicate()
    LANGUAGE plpgsql
AS
$$	
    DECLARE
        var_int INT8;
    BEGIN
	-- Create temp table with subset of imec_leg_123 for calculations, so that imec_leg_123 is impacted minimally
	CREATE TEMP TABLE #imec_leg_123_subset (LIKE ips.imec_leg_123)
  	;
 	INSERT INTO #imec_leg_123_subset
 		SELECT * FROM ips.imec_leg_123 AS leg123
		WHERE 0=0
		AND leg123.end_to_end_start_the_clock_final >= trunc(dateadd('month', -1, getdate()))
   	;
--	CREATE TABLE ips.imec_leg_123_dupes_staging (LIKE ips.imec_leg_123);
--   	ALTER TABLE ips.imec_leg_123_dupes_staging ADD COLUMN rnk int2;
--    	ALTER TABLE ips.imec_leg_123_dupes_staging ADD COLUMN lst varchar(max);
    TRUNCATE TABLE ips.imec_leg_123_dupes_staging
   	;
    -- Insert duplicate records (identical) from subset into dupes_staging table
    INSERT INTO ips.imec_leg_123_dupes_staging
        SELECT * FROM 
        (
        SELECT 
        *
        , listagg(rnk, ', ') WITHIN GROUP (ORDER BY item_id, rnk) OVER (PARTITION BY item_id) AS lst 
        FROM (
	        	SELECT
	                s.*
	                , ROW_NUMBER() OVER (PARTITION BY item_id, local_item_id, country_destination, country_origin, rec_id, ema_scan, emb_scan, emc_scan, emd_scan, edb_scan, eme_scan, edc_scan, emf_scan, edd_scan, ede_scan, emg_scan, edg_scan, edh_scan, emh_scan, emi_scan, mrdpoc, precon_actual_close_consignment, resdit_74_received, leg_1_start_the_clock_final_adjusted_for_collection_new, leg_1_stop_the_clock_event_based, leg_1_stop_the_clock_final_non_working_day_adjusted, leg_1_transit_time_calendar_days_new, leg_1_non_working_days, leg_1_transit_time_working_days, leg_1_validation_start_and_stop_the_clock, mrdpod, resdit_21_delivered, rescon_abroad, resdes_abroad, "emd_arrival_first_item_at_inward_(destinaton)_office_of_exchan", leg_2_start_the_clock_final, leg_2_stop_the_clock_event_based, leg_2_stop_the_clock_ctt_adjusted, leg_2_stop_the_clock_final_non_working_day_adjusted, ctt_scan_leg_2, ctt_standard, ctt_standard_exceeded, leg_2_transit_time_calendar_days, leg_2_non_working_days, leg_2_transit_time_working_days, leg_2_validation_start_and_stop_the_clock, create_despatch, transport_despatch_departure, transport_despatch_arrival, despatch_planned_handover_abroad, close_receptacle, predes_actual_close_despatch, predes_planned_close_despatch, receptacle_in_consignment, transport_consignment_departure, transport_consignment_arrival, consignment_planned_handover_abroad, precon_planned_close_consignment, resdit_41_handover, resdit_24_uplift, resdit_14_transport_leg_completed, leg_3_customs_in_start_the_clock_event_based_new, leg_3_customs_in_start_the_clock_ctt_adjusted, leg_3_customs_in_start_the_clock_final_non_working_day_adjusted, ctt_scan_leg_3_start, ctt_scan_leg_3_start_time, ctt_scan_leg_3_stop_time, standard_leg_3_start, standard_leg_3_stop, leg_3_customs_out_stop_the_clock_event_based_new, leg_3_customs_out_stop_the_clock_ctt_adjusted, leg_3_customs_out_stop_the_clock_final_non_working_day_adjusted, leg_3_start_the_clock_final, leg_3_stop_the_clock_event_based, leg_3_stop_the_clock_final_non_working_day_adjusted, leg_3_transit_time_calendar_days_new, leg_3_non_working_days, leg_3_customs_time_retention_code_to_exclude, leg_3_transit_time_working_days_including_customs_time, leg_3_transit_time_working_days_excluding_customs_time, leg_3_customs_transit_time_calendar_days_new, leg_3_customs_non_working_days, leg_3_customs_transit_time_working_days, leg_3_customs_validation_start_and_stop_the_clock, leg_3_validation_start_and_stop_the_clock, end_to_end_start_the_clock_final, end_to_end_stop_the_clock_final, end_to_end_calendar_days, end_to_end_non_working_days, end_to_end_transit_time_working_days_including_customs_time, end_to_end_transit_time_working_days_excluding_customs_time, end_to_end_validation_start_and_stop_the_clock, origin_oe, destination_oe, mailsubclass, product, identifier, standard, on_time_including_customs_time, on_time_excluding_customs_time, carrier, customer, container_journey_id, dim_item_id, transport_consignment_flight_nr, receptacle_weight, product_key, despatch_id, consignment_id, edx_scan, destination_country_item, eda_hold_item_at_ooe
	         			) AS rnk
	            FROM
	                #imec_leg_123_subset  AS s
             )
        )
		WHERE lst LIKE '1, 2%'
		ORDER BY item_id, rnk
 	;
 	DROP TABLE #imec_leg_123_subset
 	;
 	DELETE FROM ips.imec_leg_123 WHERE item_id IN (SELECT item_id FROM ips.imec_leg_123_dupes_staging)
 	;
 	INSERT INTO ips.imec_leg_123 
 		SELECT item_id, local_item_id, country_destination, country_origin, rec_id, ema_scan, emb_scan, emc_scan, emd_scan, edb_scan, eme_scan, edc_scan, emf_scan, edd_scan, ede_scan, emg_scan, edg_scan, edh_scan, emh_scan, emi_scan, mrdpoc, precon_actual_close_consignment, resdit_74_received, leg_1_start_the_clock_final_adjusted_for_collection_new, leg_1_stop_the_clock_event_based, leg_1_stop_the_clock_final_non_working_day_adjusted, leg_1_transit_time_calendar_days_new, leg_1_non_working_days, leg_1_transit_time_working_days, leg_1_validation_start_and_stop_the_clock, mrdpod, resdit_21_delivered, rescon_abroad, resdes_abroad, "emd_arrival_first_item_at_inward_(destinaton)_office_of_exchan", leg_2_start_the_clock_final, leg_2_stop_the_clock_event_based, leg_2_stop_the_clock_ctt_adjusted, leg_2_stop_the_clock_final_non_working_day_adjusted, ctt_scan_leg_2, ctt_standard, ctt_standard_exceeded, leg_2_transit_time_calendar_days, leg_2_non_working_days, leg_2_transit_time_working_days, leg_2_validation_start_and_stop_the_clock, create_despatch, transport_despatch_departure, transport_despatch_arrival, despatch_planned_handover_abroad, close_receptacle, predes_actual_close_despatch, predes_planned_close_despatch, receptacle_in_consignment, transport_consignment_departure, transport_consignment_arrival, consignment_planned_handover_abroad, precon_planned_close_consignment, resdit_41_handover, resdit_24_uplift, resdit_14_transport_leg_completed, leg_3_customs_in_start_the_clock_event_based_new, leg_3_customs_in_start_the_clock_ctt_adjusted, leg_3_customs_in_start_the_clock_final_non_working_day_adjusted, ctt_scan_leg_3_start, ctt_scan_leg_3_start_time, ctt_scan_leg_3_stop_time, standard_leg_3_start, standard_leg_3_stop, leg_3_customs_out_stop_the_clock_event_based_new, leg_3_customs_out_stop_the_clock_ctt_adjusted, leg_3_customs_out_stop_the_clock_final_non_working_day_adjusted, leg_3_start_the_clock_final, leg_3_stop_the_clock_event_based, leg_3_stop_the_clock_final_non_working_day_adjusted, leg_3_transit_time_calendar_days_new, leg_3_non_working_days, leg_3_customs_time_retention_code_to_exclude, leg_3_transit_time_working_days_including_customs_time, leg_3_transit_time_working_days_excluding_customs_time, leg_3_customs_transit_time_calendar_days_new, leg_3_customs_non_working_days, leg_3_customs_transit_time_working_days, leg_3_customs_validation_start_and_stop_the_clock, leg_3_validation_start_and_stop_the_clock, end_to_end_start_the_clock_final, end_to_end_stop_the_clock_final, end_to_end_calendar_days, end_to_end_non_working_days, end_to_end_transit_time_working_days_including_customs_time, end_to_end_transit_time_working_days_excluding_customs_time, end_to_end_validation_start_and_stop_the_clock, origin_oe, destination_oe, mailsubclass, product, identifier, standard, on_time_including_customs_time, on_time_excluding_customs_time, carrier, customer, container_journey_id, dim_item_id, transport_consignment_flight_nr, receptacle_weight, product_key, despatch_id, consignment_id, edx_scan, destination_country_item, eda_hold_item_at_ooe
		FROM ips.imec_leg_123_dupes_staging
		WHERE rnk = 1 		
	;
--	CREATE TABLE ips.imec_leg_123_dupes (LIKE ips.imec_leg_123);
--   		ALTER TABLE ips.imec_leg_123_dupes ADD COLUMN rnk int2;
--    	ALTER TABLE ips.imec_leg_123_dupes ADD COLUMN lst varchar(max)
    DELETE FROM ips.imec_leg_123_dupes WHERE item_id IN 
		(SELECT item_id FROM ips.imec_leg_123_dupes_staging) 
	;
	INSERT INTO ips.imec_leg_123_dupes 
		SELECT * FROM ips.imec_leg_123_dupes_staging 
	;
	
END;
$$;

