CREATE PROCEDURE sp_dim_invoice()
    SECURITY DEFINER
    LANGUAGE plpgsql
AS
$$







DECLARE
   _REC_duplicates 			record;
   _VAR_inserts 			int8;
   --_VAR_last_update_ts      timestamp := (SELECT MAX(s3_partition_ts) FROM prep_cbs_tom.orderline_invoiceinformation_customerrate);
BEGIN
	    --IF _VAR_init = TRUE THEN
		TRUNCATE TABLE tom.dim_invoice;
		RAISE WARNING 'WARNING: An Initiation has started and the table tom.dim_invoice has been TRUNCATED.';
		--END IF;


	INSERT INTO tom.dim_invoice
		SELECT
			c.id_index_orderline_invoiceinformation_customerrate_hid as dim_invoice_id_hid
			,dc.dim_customer_id_hid
			,c.id_orderline_invoiceinformation_customerrate as id_orderline_invoiceinformation_customerrate_bk
			,r.orderline_invoiceinformation_groupagerate
			,r.orderline_invoiceinformation_isgroupageorder
			,r.orderline_invoiceinformation_ratessame
		FROM ingest_db.prep_cbs_tom.orderline_invoiceinformation_customerrate c
		LEFT JOIN ingest_db.prep_cbs_tom.root r
		ON c.id_orderline_invoiceinformation_customerrate =r.orderline_invoiceinformation_customerrate
		LEFT JOIN tom.dim_customer dc ON c.orderline_invoiceinformation_customerrate_customercode=dc.id_invoiceinformation_customercode_bk
  ;
    GET DIAGNOSTICS _VAR_inserts := ROW_COUNT;
     RAISE INFO 'Update completed: % rows inserted in tom.dim_invoice', _VAR_inserts;

     CALL admin.sp_pk_check_table( PG_Last_Query_ID() );
   		SELECT * INTO _REC_duplicates FROM #sp_pk_check_table;
    	IF _REC_duplicates.dupes_amount > 0 THEN
   		RAISE EXCEPTION 'Duplicates found'; RAISE INFO 'No duplicates found';
    	END IF;

    	EXCEPTION WHEN OTHERS THEN
        	IF SQLERRM = 'Duplicates found' THEN
         		RAISE EXCEPTION '% Duplicates found in total, for key values: %',_REC_duplicates.dupes_amount,_REC_duplicates.Duplicates_Check_PK;
            ELSE RAISE EXCEPTION 'Error %, State %', SQLERRM, SQLSTATE;
        	END IF;

END;







$$;

