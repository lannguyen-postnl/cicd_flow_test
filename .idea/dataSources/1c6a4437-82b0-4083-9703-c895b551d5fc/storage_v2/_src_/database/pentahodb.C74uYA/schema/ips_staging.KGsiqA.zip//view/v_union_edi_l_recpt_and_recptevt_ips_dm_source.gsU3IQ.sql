CREATE OR REPLACE VIEW ips_staging.v_union_edi_l_recpt_and_recptevt_ips_dm_source AS
SELECT
    recpt_evt.dim_receptacle_id
  , fnv_hash(recpt_evt.ak_receptacle)                               AS recptcl_pid_hid
  , recpt_evt.ak_receptacle                                         AS recptcl_pid
  , COALESCE(fnv_hash(recpt.receptacle_code), -1)                   AS recptcl_fid_hid
  , COALESCE(recpt.receptacle_code, 'no_barcode')                   AS recptcl_fid
  , fnv_hash(recpt_evt.ak_consignment)                              AS consignment_pid_hid
  , recpt_evt.ak_consignment                                        AS consignment_pid
  , recpt_evt.event_local_datetime
  , recpt.dim_consignment_id                                        AS dim_consignment_id
  , recpt.dim_container_id                                          AS dim_container_id
  , recpt.dim_dispatch_id                                           AS dim_dispatch_id
  , recpt_evt.dim_event_type_id
  , recpt_evt.carrier_event_code
  , CASE WHEN recpt_evt.is_domestic THEN 'l' ELSE 'e' END ::char(2) AS receptacle_event_source
  , recpt_evt.load_dt_utc
--   , recpt_evt.s3_partition_ts
FROM
    ips_dm.fact_receptacle_event recpt_evt
        LEFT JOIN ips_dm.dim_receptacle recpt
                  ON recpt_evt.dim_receptacle_id = recpt.dim_receptacle_id
WITH NO SCHEMA BINDING;

ALTER TABLE v_union_edi_l_recpt_and_recptevt_ips_dm_source
    OWNER TO lannguyen;

GRANT DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE ON v_union_edi_l_recpt_and_recptevt_ips_dm_source TO GROUP analyst;

