--combining n_edi and l:
CREATE OR REPLACE VIEW ips_staging.v_union_edi_l_current_item_and_evt AS
SELECT
    l_evt.mailitm_pid_hid
  , COALESCE(l_itm.mailitm_fid, 'no barcode')                  AS mailitm_fid
  , COALESCE(l_itm.mailitm_fid_hid, -1)                        AS mailitm_fid_hid
  , l_evt.event_type_cd
  , l_evt.retention_reason_cd                                  AS retention_reason_code
  , DATEADD('h', l_evt.event_local_offset, l_evt.event_gmt_dt) AS event_local_dt --l_evt.event_gmt_dt
  , l_evt.s3_partition_ts                                      AS event_s3_partition_ts
  , 'l'::char(1)                                               AS item_event_source
FROM
    ingest_db.prep_ips_nationals.l_mailitm_events l_evt
        LEFT JOIN ingest_db.cleanse_ips_nationals.l_mailitms l_itm
                  ON l_evt.mailitm_pid_hid = l_itm.mailitm_pid_hid
UNION ALL
SELECT
    n_edi_evt.mailitem_pid_hid
  , COALESCE(n_edi_itm.mailitm_fid, 'no barcode') AS mailitm_fid
  , COALESCE(n_edi_itm.mailitem_fid_hid, -1)      AS mailitem_fid_hid
  , n_edi_evt.event_type_cd
  , n_edi_evt.retention_reason_cd                 AS retention_reason_code
  , n_edi_evt.event_local_dt
  , n_edi_evt.s3_partition_ts                     AS event_s3_partition_ts
  , 'e'::char(1)                                  AS item_event_source
FROM
    ingest_db.prep_ips_nationals.n_edi_mailitm_events n_edi_evt
        LEFT JOIN ingest_db.cleanse_ips_nationals.n_edi_mailitms n_edi_itm
                  ON n_edi_evt.mailitem_pid_hid = n_edi_itm.mailitem_pid_hid
WITH NO SCHEMA BINDING;

ALTER TABLE v_union_edi_l_current_item_and_evt
    OWNER TO lannguyen;

GRANT DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE ON v_union_edi_l_current_item_and_evt TO GROUP analyst;

