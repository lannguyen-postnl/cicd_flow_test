CREATE FUNCTION diff_days(date_begin character varying, date_end character varying) RETURNS integer
    IMMUTABLE
    LANGUAGE plpythonu
AS
$$
	def difference_days(date_begin, date_end):
		import datetime
		date_begin = date_begin.str.dt.date
		date_end = date_begin.str.dt.date
		diff = (date_end-date_begin).days
		return diff
		
	return difference_days(date_begin, date_end)
$$;

