CREATE FUNCTION working_days_function() RETURNS integer
    STABLE
    LANGUAGE plpythonu
AS
$$
import numpy as np
import datetime as dt

start = dt.date( 2014, 1, 1 )
end = dt.date( 2014, 1, 16 )

days = np.busday_count( start, end )
$$;

