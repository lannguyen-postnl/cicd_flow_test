CREATE PROCEDURE sp_fact_transport_orders()
    SECURITY DEFINER
    LANGUAGE plpgsql
AS
$$













DECLARE
   _REC_duplicates 			record;
   _VAR_inserts 			int8;
  -- _VAR_last_update_ts      timestamp := (SELECT MAX(s3_partition_ts) FROM tom.fact_transport_orders);
BEGIN
	    --IF _VAR_init = TRUE THEN
		TRUNCATE TABLE tom.fact_transport_orders;
		RAISE WARNING 'WARNING: An Initiation has started and the table tom.fact_transport_orders has been TRUNCATED.';
	    --END IF;

 INSERT INTO tom.fact_transport_orders
WITH orderline_stop AS (
			SELECT
				transport_order_id
				,LAST_VALUE(stop_city) OVER( PARTITION BY id_orderline_stop_bk  ORDER BY stop_index asc rows between unbounded preceding and unbounded following ) last_stop_city
				,FIRST_VALUE(stop_city) OVER( PARTITION BY id_orderline_stop_bk ORDER BY stop_index asc rows between unbounded preceding and unbounded following ) first_stop_city
				,LAST_VALUE(stop_country) OVER( PARTITION BY id_orderline_stop_bk ORDER BY stop_index asc rows between unbounded preceding and unbounded following ) last_stop_country
				,FIRST_VALUE(stop_country) OVER( PARTITION BY id_orderline_stop_bk ORDER BY stop_index asc rows between unbounded preceding and unbounded following ) first_stop_country
				,LAST_VALUE(stop_location) OVER( PARTITION BY id_orderline_stop_bk ORDER BY stop_index asc rows between unbounded preceding and unbounded following ) last_stop_location
				,FIRST_VALUE(stop_location) OVER( PARTITION BY id_orderline_stop_bk ORDER BY stop_index asc rows between unbounded preceding and unbounded following ) first_stop_location
			    ,case when dense_rank () OVER( PARTITION BY id_orderline_stop_bk ORDER BY stop_city )>2 then 1 else 0 end as d_rank_multiple_stops
			FROM tom.fact_stop
			where rnk=1
			),
		transport_orders AS (
			SELECT
				documentid_orderline_ids_hid
				,cancelledwithfee as cancelled_with_fee
				,documentdatetime as document_datetime
				,documentid as transport_order_id_bk
				,executiondate as loading_date
				,nullif(extrastops,'') as extra_stops
				,fueltype as fuel_type
				,fueltypereferencecode as fuel_type_reference_code
				,"handler"
				,hasplannedchange as has_planned_change
				,hasscheduledcancellation  as has_scheduled_cancellation
				,isdayorder
				,istransportorder
				,operationalstatus as operational_status
				,orderline_agreementschedule
				,orderline_distance as distance
				,orderline_executiondaysarrival as execution_arrival_day
				,orderline_executiondaysdeparture as execution_departure_day
				,orderline_invoiceinformation_additionalcost
				,orderline_invoiceinformation_carrierrate
				,orderline_invoiceinformation_customerrate
				,orderline_stop
				,orderline_transportequipmenttype_name as equipment_type
				,orderline_transportequipmenttype_referencecode as orderline_transportequipmenttype_referencecode_bk
				,orderline_transportequipmenttype_travelmethod as equipment_type_travel_method
				,orderline_transportserviceprovider_referencecode as orderline_transportserviceprovider_referencecode_bk
				,orderline_transportserviceprovider_referencenumber as carrier_reference_number
				,orderline_transportserviceprovider_tradename as carrier_name
				,orderline_transporthandlingunittotal_transporthandlingunit
				,orderreference
				,ordersort
				,ordertype
				,validfrom
				,validto
				,s3_partition_ts
				,row_number() over(partition by transport_order_id_bk,operational_status order by cast(s3_partition_ts as timestamp) desc) as status_rnk
		FROM ingest_db.prep_cbs_tom.root
		)

		SELECT
			t.documentid_orderline_ids_hid  AS fact_transport_order_id_hid
			--,ac.dim_additional_costs_id_hid
			--,iv.dim_invoice_id_hid
			,ts.dim_transport_serviceprovider_id_hid
			,te.dim_transport_equipment_id_hid
			,dto.dim_day_order_id_hid
			,tro.dim_transport_order_id_hid
			,t.cancelled_with_fee
			,cast(t.document_datetime as timestamp)
			,t.transport_order_id_bk
			,cast(t.loading_date as timestamp)
			,t.extra_stops
			,t.fuel_type
			,t.fuel_type_reference_code
			,t."handler"
			,t.has_planned_change
			,t.has_scheduled_cancellation
			,t.isdayorder
			,t.istransportorder
			,t.operational_status
			,t.orderline_agreementschedule as id_agreementschedule_bk
			,t.distance
			,t.execution_arrival_day
			,t.execution_departure_day
			,t.orderline_invoiceinformation_additionalcost as id_orderline_additionalcost_bk
			,t.orderline_invoiceinformation_carrierrate
			,t.orderline_invoiceinformation_customerrate as id_orderline_invoiceinformation_customerrate_bk
			,t.orderline_stop as id_orderline_stop_bk
			,t.orderline_transporthandlingunittotal_transporthandlingunit as id_orderline_transporthandlingunittotal_transporthandlingunit_bk
			,t.equipment_type
			,t.orderline_transportequipmenttype_referencecode_bk
			,t.equipment_type_travel_method
			,t.orderline_transportserviceprovider_referencecode_bk
			,t.carrier_reference_number
			,t.carrier_name
			,t.orderreference
			,t.ordersort
			,t.ordertype
			,cast(t.validfrom as timestamp)
			,cast(t.validto as timestamp)
			,s.last_stop_city
			,s.first_stop_city
			,s.last_stop_country
			,s.first_stop_country
			,s.last_stop_location
			,s.first_stop_location
			,case when sum(s.d_rank_multiple_stops)>1 then true else false end as multiple_stops
			,convert_timezone('Europe/Amsterdam', cast(t.loading_date  as timestamp)) as loading_date_ams_time
			,convert_timezone('Europe/Amsterdam', cast(t.validfrom  as timestamp)) as valid_from_ams_time
			,convert_timezone('Europe/Amsterdam', cast(t.validto  as timestamp)) as valid_to_ams_time
			,TO_TIMESTAMP((case when len(regexp_replace(t.execution_arrival_day ,'([^0-9-])',''))<>10 then null
							else regexp_replace(t.execution_arrival_day ,'([^0-9-])','')
							end),'DD-MM-YYYY HH24:MI:SS')as execution_arrival_date
			,TO_TIMESTAMP((case when len(regexp_replace(t.execution_departure_day ,'([^0-9-])',''))<>10 then null
							else regexp_replace(t.execution_departure_day ,'([^0-9-])','')
							end),'DD-MM-YYYY HH24:MI:SS')as execution_arrival_date
			,row_number() over(partition by t.transport_order_id_bk order by
               cast(t.s3_partition_ts as timestamp) desc) as rnk
			,t.s3_partition_ts
		from transport_orders t
		--left join tom.dim_additional_costs ac on t.orderline_invoiceinformation_additionalcost=ac.id_orderline_additionalcost_bk
		--left join tom.dim_invoice iv on t.orderline_invoiceinformation_customerrate=iv.id_orderline_invoiceinformation_customerrate_bk
		left join tom.dim_transport_serviceprovider ts on t.orderline_transportserviceprovider_referencecode_bk=ts.orderline_transportserviceprovider_referencecode_bk
		left join tom.dim_transport_equipment te on t.orderline_transportequipmenttype_referencecode_bk=te.orderline_transportequipmenttype_referencecode_bk
		left join tom.dim_day_transport_order dto on t.transport_order_id_bk=dto.transport_order_id_bk
		left join tom.dim_transport_order tro on t.transport_order_id_bk=tro.transport_order_id_bk
		left join orderline_stop s on t.transport_order_id_bk=s.transport_order_id
		WHERE 1=1

		--incremental load filter (comment out for initial load and don't forget to truncate the table :)):
		--AND t.s3_partition_ts  >_VAR_last_update_ts

		--normal filters:
		AND t.status_rnk=1
		GROUP BY
			t.documentid_orderline_ids_hid
			--,ac.dim_additional_costs_id_hid
			--,iv.dim_invoice_id_hid
			,ts.dim_transport_serviceprovider_id_hid
			,te.dim_transport_equipment_id_hid
			,dto.dim_day_order_id_hid
			,tro.dim_transport_order_id_hid
			,t.cancelled_with_fee
			,t.document_datetime
			,t.transport_order_id_bk
			,t.loading_date
			,t.extra_stops
			,t.fuel_type
			,t.fuel_type_reference_code
			,t."handler"
			,t.has_planned_change
			,t.has_scheduled_cancellation
			,t.isdayorder
			,t.istransportorder
			,t.operational_status
			,t.orderline_agreementschedule
			,t.distance
			,t.execution_arrival_day
			,t.execution_departure_day
			,t.orderline_invoiceinformation_additionalcost
			,t.orderline_invoiceinformation_carrierrate
			,t.orderline_invoiceinformation_customerrate
			,t.orderline_stop
			,t.orderline_transporthandlingunittotal_transporthandlingunit
			,t.equipment_type
			,t.orderline_transportequipmenttype_referencecode_bk
			,t.equipment_type_travel_method
			,t.orderline_transportserviceprovider_referencecode_bk
			,t.carrier_reference_number
			,t.carrier_name
			,t.orderreference
			,t.ordersort
			,t.ordertype
			,t.validfrom
			,t.validto
			,s.last_stop_city
			,s.first_stop_city
			,s.last_stop_country
			,s.first_stop_country
			,s.last_stop_location
			,s.first_stop_location
			,t.s3_partition_ts
	;


     GET DIAGNOSTICS _VAR_inserts := ROW_COUNT;
     RAISE INFO 'Update completed: % rows inserted in tom.fact_transport_orders', _VAR_inserts;

	CALL ct.sp_pk_check_table( PG_Last_Query_ID() );
   	SELECT * INTO _REC_duplicates FROM #sp_pk_check_table;
   	IF _REC_duplicates.dupes_amount > 0 THEN
   		RAISE EXCEPTION 'Duplicates found'; RAISE INFO 'No duplicates found';
   	END IF;

    	EXCEPTION WHEN OTHERS THEN
      	IF SQLERRM = 'Duplicates found' THEN
         		RAISE EXCEPTION '% Duplicates found in total, for key values: %', _REC_duplicates.dupes_amount,_REC_duplicates.Duplicates_Check_PK;
          ELSE RAISE EXCEPTION 'Error %, State %', SQLERRM, SQLSTATE;
       	END IF;

END;































$$;

