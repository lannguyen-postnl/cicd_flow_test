CREATE PROCEDURE sp_dim_agreement_schedule()
    SECURITY DEFINER
    LANGUAGE plpgsql
AS
$$








DECLARE
   _REC_duplicates 			record;
   _VAR_inserts 			int8;
   --_VAR_last_update_ts      timestamp := (SELECT MAX(s3_partition_ts) FROM prep_cbs_tom.orderline_agreementschedule);
BEGIN
	    --IF _VAR_init = TRUE THEN
		TRUNCATE TABLE tom.dim_agreement_schedule;
		RAISE WARNING 'WARNING: An Initiation has started and the table tom.dim_agreement_schedule has been TRUNCATED.';
	    --END IF;


	INSERT INTO tom.dim_agreement_schedule
		SELECT
			FNV_HASH(a.id_orderline_agreementschedule) as dim_agreementschedule_id_hid
			,a.id_orderline_agreementschedule as id_agreementschedule_bk
			,a.orderline_agreementschedule_showdate as agreementschedule_showdate
			,a.orderline_agreementschedule_warning as agreementschedule_warning
			,r.documentid as transport_order_id
    FROM
       ingest_db.prep_cbs_tom.orderline_agreementschedule a
    LEFT JOIN ingest_db.prep_cbs_tom.root r ON a.id_orderline_agreementschedule=r.orderline_agreementschedule
    GROUP BY
	    a.id_orderline_agreementschedule
	   ,a.orderline_agreementschedule_showdate
	   ,a.orderline_agreementschedule_warning
	   ,r.documentid

  ;

  GET DIAGNOSTICS _VAR_inserts := ROW_COUNT;
  RAISE INFO 'Update completed: % rows inserted in tom.dim_agreement_schedule', _VAR_inserts;


  CALL admin.sp_pk_check_table( PG_Last_Query_ID() );
   		SELECT * INTO _REC_duplicates FROM #sp_pk_check_table;
    	IF _REC_duplicates.dupes_amount > 0 THEN
   		RAISE EXCEPTION 'Duplicates found'; RAISE INFO 'No duplicates found';
    	END IF;

    	EXCEPTION WHEN OTHERS THEN
        	IF SQLERRM = 'Duplicates found' THEN
        		RAISE EXCEPTION '% Duplicates found in total, for key values: %',_REC_duplicates.dupes_amount,_REC_duplicates.Duplicates_Check_PK;
            ELSE RAISE EXCEPTION 'Error %, State %', SQLERRM, SQLSTATE;
        	END IF;

END;








$$;

