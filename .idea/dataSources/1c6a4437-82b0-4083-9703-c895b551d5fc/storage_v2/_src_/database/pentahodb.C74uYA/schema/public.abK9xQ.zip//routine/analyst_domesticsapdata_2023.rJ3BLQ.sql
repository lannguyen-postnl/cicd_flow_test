CREATE PROCEDURE analyst_domesticsapdata_2023()
    LANGUAGE plpgsql
AS
$$
	
	
begin
DROP TABLE IF exists analyst_datasets.domesticsapdata_2023;
CREATE TABLE analyst_datasets.domesticsapdata_2023
             (
       klantpakket_accountmng					varchar(255)
       ,klantpakket								varchar(255)
       ,customer_no								varchar(255)  
       ,customer_name							varchar(255)
       ,month_year								varchar(255)
       ,value									float4
       ,kpi										varchar(255),	
 		PRIMARY KEY (klantpakket_accountmng));
             GRANT ALL ON analyst_datasets.domesticsapdata_2023 TO GROUP analyst;
    COPY analyst_datasets.domesticsapdata_2023
    FROM 's3://postnl-datalake-cbs-consumption/Finance/input/NLX/NLX_sales/output/fact_kpis' 
    iam_role 'arn:aws:iam::815649711844:role/Redshift_FullAccesPlusAddedEc2S3Access' 
    ignoreheader 1
    truncatecolumns acceptinvchars AS ' '
    emptyasnull blanksasnull dateformat 'auto'
    timeformat 'auto' 
    format AS csv 
    delimiter ';' 
    NULL AS 'n/a' 
    compupdate ON;
  END; 
 

$$;

