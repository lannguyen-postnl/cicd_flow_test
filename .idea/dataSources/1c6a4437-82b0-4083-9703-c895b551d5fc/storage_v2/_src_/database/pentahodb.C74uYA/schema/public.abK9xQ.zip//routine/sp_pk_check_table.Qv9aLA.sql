CREATE PROCEDURE sp_pk_check_table(_in_rel_table_id integer, out _out_pk_duplicate_message character varying)
    LANGUAGE plpgsql
AS
$$
DECLARE 
   _VAR_dyn_query VARCHAR(MAX);
BEGIN
   --Generate dynamic SQL:
   _VAR_dyn_query := 
   (
      Select dyn_query From (
            Select
                 pg_get_constraintdef( con.oid )
               , conrelid
               , SUBSTRING( pg_get_constraintdef( con.oid ), 14, len( pg_get_constraintdef(con.oid) ) - 14 ) as PK_LIST
               , case when nspname ilike 'pg_temp_%' then '' else nspname || '.' end  || relname             as schema_table--temp tables don't use schema's nspname =schemaName. relName = table name
                  , 'With dupes_table as 
                     ( Select top 1000 ' 
                        || PK_LIST  
                        || ', count(*) as dupes' 
                     || ' From ' 
                        || schema_table 
                     || ' Group by ' 
                        || PK_LIST
                     || ' Having dupes 
                           > 1 Order by dupes desc)' 
                  ||' Select COALESCE( ''Duplicates found for ' || schema_table || '''||  listagg( '': Dupl_PK{'' ||' || PK_LIST || '|| ''}, #Dupl('' || dupes ||'')'', ''; ''), ''No Duplicates'') as Duplicates_Check_PK'
                  ||' From dupes_table'
               as dyn_query
            From
               pg_constraint CON 
               LEFT JOIN pg_class      AS tbl ON tbl.relnamespace = con.connamespace AND tbl.oid = con.conrelid
               LEFT JOIN pg_namespace  AS sch ON sch.oid          = tbl.relnamespace
            Where 1=1
                AND CON.contype  = 'p'
                AND CON.conrelid = _IN_rel_table_id
         )
      );
      
   --Execute generated statement and catch it with ouput var:
   EXECUTE _VAR_dyn_query INTO _OUT_PK_Duplicate_Message;

   --TRAP ERRORS:      
   EXCEPTION WHEN OTHERS THEN RAISE EXCEPTION 'Error %, State %', SQLERRM, SQLSTATE;
   
END;
$$;

