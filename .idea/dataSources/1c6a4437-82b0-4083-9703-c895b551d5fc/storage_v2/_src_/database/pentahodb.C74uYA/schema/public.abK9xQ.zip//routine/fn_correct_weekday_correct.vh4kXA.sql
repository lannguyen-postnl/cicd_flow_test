CREATE FUNCTION fn_correct_weekday_correct(start_date timestamp without time zone, end_date timestamp without time zone) RETURNS integer
    STABLE
    LANGUAGE plpythonu
AS
$$    
    import datetime as dt
    from datetime import timedelta as td
    import numpy as np
    import calendar
    diff = -2
    if start_date:
        if start_date.weekday() == 5:
            if start_date.day != 1 and start_date.month != 1:
                start_date = dt.datetime(start_date.year,start_date.month,start_date.day-1)
            elif start_date.day == 1 and start_date.month !=1:
                last_day = calendar.monthrange(start_date.year, start_date.month-1)[1]
                start_date = dt.datetime(start_date.year,start_date.month-1,last_day)
            elif start_date.day == 1 and start_date.month == 1:
                last_day = calendar.monthrange(start_date.year, 12)[1]
                start_date = dt.datetime(start_date.year-1,12,last_day)
        elif start_date.weekday() == 6:
            if start_date.day != 1 and start_date.day != 2 and start_date.month != 1:
                start_date = dt.datetime(start_date.year,start_date.month,start_date.day-2)
            elif start_date.day == 1 and start_date.month !=1:
                last_day = calendar.monthrange(start_date.year, start_date.month-1)[1]
                before_last_day = last_day-1
                start_date = dt.datetime(start_date.year,start_date.month-1,before_last_day)
            elif start_date.day == 1 and start_date.month == 1:
                last_day = calendar.monthrange(start_date.year, 12)[1]
                before_last_day = last_day-1
                start_date = dt.datetime(start_date.year-1,12,before_last_day)
            elif start_date.day == 2 and start_date.month !=1:
                last_day = calendar.monthrange(start_date.year, start_date.month-1)[1]
                before_last_day = last_day-1
                start_date = dt.datetime(start_date.year,start_date.month-1,last_day)
            elif start_date.day == 2 and start_date.month ==1:
                last_day = calendar.monthrange(start_date.year, 12)[1]
                before_last_day = last_day-1
                start_date = dt.datetime(start_date.year,12,last_day)
        if end_date:
            if end_date.weekday() == 5:
                last_day = calendar.monthrange(end_date.year, end_date.month)[1]
                before_last_day = last_day-1
                if end_date.day != last_day and end_date.day != before_last_day and end_date.month != 12:
                    end_date = dt.datetime(end_date.year,end_date.month,end_date.day+2)
                elif end_date.day == last_day and end_date.month !=12:
                    end_date = dt.datetime(end_date.year,end_date.month+1,2)
                elif end_date.day == last_day and end_date.month == 12:
                    end_date = dt.datetime(end_date.year+1,1,2)
                elif end_date.day == before_last_day and end_date.month !=12:
                    end_date = dt.datetime(end_date.year,end_date.month+1,1)
                elif end_date.day == before_last_day and end_date.month == 12:
                    end_date = dt.datetime(end_date.year+1,1,1)
            elif end_date.weekday() == 6:
                last_day = calendar.monthrange(end_date.year, end_date.month)[1]
                if end_date.day != last_day and end_date.month != 12:
                    end_date = dt.datetime(end_date.year,end_date.month,end_date.day+1)
                elif end_date.day == last_day and end_date.month !=12:
                    end_date = dt.datetime(end_date.year,end_date.month+1,1)
                elif end_date.day == last_day and end_date.month == 12:
                    end_date = dt.datetime(end_date.year+1,1,1)
            diff = (end_date.date()-start_date.date()).days
        counter = 0
        for single_date in (start_date +td(n+1) for n in range(diff)):
            if single_date.weekday() != 6 and single_date.weekday()!=5:
                counter+=1
        return counter
    return None
$$;

