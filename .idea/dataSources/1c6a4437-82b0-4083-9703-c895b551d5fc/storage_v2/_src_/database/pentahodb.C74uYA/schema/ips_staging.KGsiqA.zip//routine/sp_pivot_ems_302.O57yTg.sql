CREATE PROCEDURE sp_pivot_ems_302(_init_ts timestamp without time zone)
    LANGUAGE plpgsql
AS
$$
/**********************************************************************************************************************
  *
  * Purpose/Description     : This stored procedure updates their target tables in which contains calculations of
                                different first EMS events that are pivoted and ready as input for the IMEC302_staging.
                                To see which EMS events are tracked, please check ips_staging.config_ips_export_302_staging table.
  * Documentation reference : https://postnl.atlassian.net/wiki/spaces/CB/pages/3674866047/IMEC+202+302
  * Input expected          :
                                * _init_ts timestamp := '9999-12-31' then incremental data load for target tables
                                * _init_ts timestamp <> '9999-12-31' then flush & fill target tables
  * Output expected         : Inserts into target tables
                                * ips_staging.pivot_earliest_ems_302
  * Procedure called from   : ips_staging.job_update_pivot_earliest_ems_302(_init_ts:=timestamp)
  * Procedure calls         : n/a
  *
**********************************************************************************************************************/
DECLARE
    _var_colmn_expr_pivot   varchar(max);
    _var_alias_pivot        varchar(max);
    _var_fullquery_pivot    varchar(max);
    _var_current_ts         varchar := CURRENT_TIMESTAMP;
    _var_incremental_ts     timestamp;
    _var_inserts            int     := 0;
BEGIN
    IF _init_ts != '9999-12-31' THEN
        _var_incremental_ts := _init_ts;
        TRUNCATE ips_staging.pivot_earliest_ems_302;
        RAISE INFO '% - Truncated table ips_staging.pivot_earliest_ems_302 for initial load from %', _var_current_ts, _var_incremental_ts;
    ELSE
        _var_incremental_ts := (SELECT
                                    COALESCE(MAX(max_last_mod_dt), '2021-01-01')
                                FROM
                                    ips_staging.pivot_earliest_ems_302);
        RAISE INFO '% - Incremental partition date for ips_staging.pivot_earliest_ems_302: %', _var_current_ts, _var_incremental_ts;
    END IF;
    DROP TABLE IF EXISTS #colmn_expr_pivot;

     WITH
        column_expr_ems_events AS (SELECT DISTINCT
                                     ems_evt_name
                                   , ems_evt_id
                                   , ems_event_final_alias as alias
                                   , 'first_ems_events' AS label
                                   , 'MAX(CASE WHEN ems_evt_id = ' || ems_evt_id || ' THEN ' || sort_col ||
                                     ' END ) AS ' ||
                                     ems_event_final_alias
                                                        AS column_expr
                                 FROM
                                     ips_staging.config_ips_export_302_staging as config302)
    SELECT
        LISTAGG(column_expr, '\n, ') AS agg_column_expr
        , LISTAGG(alias, ', ') AS agg_alias
    INTO #colmn_expr_pivot
    FROM
        column_expr_ems_events;

    _var_colmn_expr_pivot := (SELECT agg_column_expr FROM #colmn_expr_pivot);
    _var_alias_pivot := (SELECT agg_alias FROM #colmn_expr_pivot);
    RAISE INFO 'Start execution';

    _var_fullquery_pivot := 'INSERT INTO ips_staging.pivot_earliest_ems_302 (redshifthashed_dim_mailitem_id, max_last_mod_dt, ' || _var_alias_pivot || ', ema_origin_system, retention_code)' ||
                            '\n SELECT fnv_hash(mailitm_fid) as redshifthashed_dim_mailitem_id, MAX(last_mod_dt) as max_last_mod_dt, ' || _var_colmn_expr_pivot ||
                            '\n , MAX(CASE
                                        WHEN ems_evt_id = 1 AND event_type_cd = 1245 THEN 2
                                        WHEN ems_evt_id = 1 AND event_type_cd = 1 THEN 1
                                        WHEN ems_evt_id = 1 AND event_type_cd = 1233 THEN 3
                                        WHEN ems_evt_id = 1 AND event_type_cd = 1237 THEN 4
                                   END) AS ema_origin_system
                                , MAX(CASE
                                          WHEN ems_evt_id = 6 AND event_type_cd = 34 THEN retention_reason_code
                                   END)     AS retention_code' ||
                            '\n FROM ips_staging.fact_earliest_ems_evt_302 ' ||
                            '\n WHERE last_mod_dt > \'' || _var_incremental_ts ||
                            '\'\n GROUP BY mailitm_fid;';

    RAISE INFO '%', _var_fullquery_pivot;

    EXECUTE _var_fullquery_pivot;
    GET DIAGNOSTICS _VAR_inserts := ROW_COUNT; RAISE INFO '% rows inserted into ips_staging.pivot_earliest_ems_302', _VAR_inserts;

END ;
$$;

