CREATE PROCEDURE sp_fact_earliest_ems_evt_202(_init_ts timestamp without time zone)
    LANGUAGE plpgsql
AS
$$
/**********************************************************************************************************************
  *
  * Purpose/Description     : This stored procedure updates their target tables in which contains calculations of
                                different tracked events (on receptacle, dispatch and consignment level). To see which events are tracked, please
                                check ips_staging.config_ips_export_202_staging table.
  * Documentation reference : https://postnl.atlassian.net/wiki/spaces/CB/pages/3674866047/IMEC+202+302
  * Input expected          :
                                * _init_ts timestamp := '9999-12-31' then incremental data load for target tables
                                * _init_ts timestamp <> '9999-12-31' then flush & fill target tables
  * Output expected         : Inserts into target tables
                                * ips_staging.fact_earliest_ems_evt_202
                                * ips_staging.fact_earliest_ems_evt_202_no_barcode
  * Procedure called from   : ips_staging.job_update_pivot_earliest_ems_202(_init_ts:=timestamp)
  * Procedure calls         : n/a
  *
**********************************************************************************************************************/
DECLARE
    _VAR_current_ts             varchar:= current_timestamp;
    _VAR_incremental_ts_nedi    timestamp;
    _VAR_incremental_ts_l       timestamp;
    _VAR_inserts		        INT:= 0;
BEGIN
    IF _init_ts != '9999-12-31'
        THEN
            _VAR_incremental_ts_nedi := _init_ts;
            _VAR_incremental_ts_l := _init_ts;
        RAISE INFO '% - Max partition date of previous load of target table both for local and external events: %', _VAR_current_ts, _init_ts;
        TRUNCATE ips_staging.fact_earliest_ems_evt_202;
        RAISE INFO '% - Truncated table ips_staging.fact_earliest_ems_evt_202 for initial load', _var_current_ts;
        TRUNCATE ips_staging.fact_earliest_ems_evt_202_no_barcode;
        RAISE INFO '% - Truncated table ips_staging.fact_earliest_ems_evt_202_no_barcode for initial load', _var_current_ts;
    ELSE
        _VAR_incremental_ts_nedi := (SELECT COALESCE(MAX(evt_s3_dt), '2021-01-01')
                                     FROM ips_staging.fact_earliest_ems_evt_202
                                     WHERE receptacle_event_source = 'e');
        _VAR_incremental_ts_l := (SELECT COALESCE(MAX(evt_s3_dt), '2021-01-01')
                                  FROM ips_staging.fact_earliest_ems_evt_202
                                  WHERE receptacle_event_source = 'l');
        RAISE INFO '% - Incremental partition date for external: %; for local: %', _VAR_current_ts, _VAR_incremental_ts_nedi, _VAR_incremental_ts_l;
    END IF;

    DROP TABLE if EXISTS #sta_fact_earliest_ems_evt_202;
    --staging table:
    CREATE TABLE #sta_fact_earliest_ems_evt_202 ( LIKE ips_staging.fact_earliest_ems_evt_202 );
    ALTER TABLE #sta_fact_earliest_ems_evt_202 ADD COLUMN r        int2;
    ALTER TABLE #sta_fact_earliest_ems_evt_202 ADD COLUMN t_action char(1);
	--insert statements
	INSERT INTO #sta_fact_earliest_ems_evt_202
    WITH
        duplicate_rows AS (
        SELECT
            --deg key:
            uni.recptcl_fid
          , coalesce(uni.recptcl_fid_hid,-1)  as recptcl_fid_hid
            --composite key:
          , uni.recptcl_pid_hid
          , uni.dim_event_type_id as event_type_code
          , uni.event_local_dt as event_local_datetime
            --incremental ts:
          , uni.s3_partition_ts as evt_s3_dt
            --hid from composite key:
          , fnv_hash( uni.recptcl_pid_hid, fnv_hash( uni.dim_event_type_id, fnv_hash( uni.event_local_dt ) ) ) AS composite_key_hid
            --local/operational indicator:
          , uni.receptacle_event_source
            --grouping property:
          , CASE
              WHEN uni.dim_event_type_id = 161
                  THEN
                    CASE
                        WHEN uni.carrier_event_code = 74 THEN 5
                        WHEN uni.carrier_event_code = 14 THEN 8
                        WHEN uni.carrier_event_code = 24 THEN 9
                        WHEN uni.carrier_event_code = 6 THEN 10
                        WHEN uni.carrier_event_code = 21 THEN 7
                        WHEN uni.carrier_event_code = 41 THEN 6
                    ELSE -1
                    END
              ELSE conf.ems_event_id END AS evt_id
          , CASE
              WHEN uni.dim_event_type_id = 161
                  THEN
                    CASE
                        WHEN  uni.carrier_event_code = 74 THEN 'first_resdit_74'
                        WHEN  uni.carrier_event_code = 14 THEN 'first_resdit_14'
                        WHEN  uni.carrier_event_code = 24 THEN 'first_resdit_24'
                        WHEN  uni.carrier_event_code = 6  THEN 'first_resdit_6'
                        WHEN  uni.carrier_event_code = 21 THEN 'first_resdit_21'
                        WHEN  uni.carrier_event_code = 41 THEN 'first_resdit_41'
                    ELSE '-1'
                    END
              ELSE conf.ems_evt_name END AS ems_evt_name
          , current_timestamp as last_mod_dt
          --preparing
          , row_number() OVER ( partition by uni.recptcl_fid_hid, evt_id order by uni.event_local_dt ASC ) as r
          , CASE
              WHEN t.recptcl_pid_hid  is null                  THEN 'i' --insert
              WHEN uni.event_local_dt < t.event_local_datetime THEN 'u' --update(delete then insert)
          END::char(1) as t_action
        FROM
            --master data:
            ips_staging.config_ips_export_202_staging conf
            --source:
            INNER JOIN ips_staging.v_union_edi_l_recpt_and_recptevt  uni  ON uni.dim_event_type_id   = conf.dim_event_type_id
            --target:
                --match should be on target ems_evt.
                --in the target table there is only 1 record per recptcl_pid_hid and ems_evt.
            LEFT JOIN  ips_staging.fact_earliest_ems_evt_202 t              ON uni.recptcl_pid_hid = t.recptcl_pid_hid AND conf.ems_event_id  = t.ems_evt_id
        WHERE 1=1
            --In the where clause only the conditions we're interested in related to time are filtered further.
            --incremental fetch to be analyzed, either time stamp is ahead or no barcode was found for previous load:
            AND
                (
                --external table (n_edi_load):
                     (uni.receptacle_event_source = 'e' and COALESCE(uni.s3_partition_ts, '9999-12-31') > _VAR_incremental_ts_nedi)
                 OR
                --local table (l_load):
                     (uni.receptacle_event_source = 'l' and COALESCE(uni.s3_partition_ts, '9999-12-31') > _VAR_incremental_ts_l)
                )
            --forces the latest timestamp to be used with a match and always include it in a match:
            AND uni.event_local_dt < COALESCE( t.event_local_datetime, '9999-12-31' )
            AND conf.ems_event_id in (1,2,3,4,5,6,7,8,9,10) --other ems_scans are constructed differently, hence not included
    )
    SELECT
        recptcl_fid
      , recptcl_fid_hid
      , recptcl_pid_hid
      , event_type_code
      , event_local_datetime
      , evt_s3_dt
      , composite_key_hid
      , receptacle_event_source
      , evt_id AS ems_evt_id
      , ems_evt_name
      , last_mod_dt
      , r
      , t_action
    FROM  duplicate_rows
    WHERE 1 = 1
      AND (r = 1 OR recptcl_pid_hid = -1)
      AND ems_evt_id <> -1
    ;

    --delete from target where status = update (u):
    DELETE FROM ips_staging.fact_earliest_ems_evt_202 WHERE composite_key_hid IN ( Select composite_key_hid FROM #sta_fact_earliest_ems_evt_202 WHERE t_action = 'u' );

    --why drop column this versus selecting explicitly?
    ALTER TABLE #sta_fact_earliest_ems_evt_202 DROP COLUMN r;
    ALTER TABLE #sta_fact_earliest_ems_evt_202 DROP COLUMN t_action; --could maybe be saved.

    --separate -1 barcode (barcodeless events) logic (data quality issue):
    INSERT INTO ips_staging.fact_earliest_ems_evt_202_no_barcode SELECT *  FROM #sta_fact_earliest_ems_evt_202 WHERE recptcl_fid_hid = -1;
	GET DIAGNOSTICS _VAR_inserts := ROW_COUNT; RAISE INFO '% rows inserted into ips_staging.fact_earliest_ems_evt_202_no_barcode', _VAR_inserts;

    -- insert the rest of the events in the target table
    DELETE FROM #sta_fact_earliest_ems_evt_202 WHERE recptcl_fid_hid = -1;
    INSERT INTO ips_staging.fact_earliest_ems_evt_202 SELECT * FROM #sta_fact_earliest_ems_evt_202;
	GET DIAGNOSTICS _VAR_inserts := ROW_COUNT; RAISE INFO '% rows inserted into ips_staging.fact_earliest_ems_evt_202', _VAR_inserts;

END;
$$;

