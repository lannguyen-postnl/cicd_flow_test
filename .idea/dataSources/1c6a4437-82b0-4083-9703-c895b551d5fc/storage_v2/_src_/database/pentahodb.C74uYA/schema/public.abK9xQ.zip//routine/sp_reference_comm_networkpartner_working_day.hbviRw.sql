CREATE PROCEDURE sp_reference_comm_networkpartner_working_day()
    SECURITY DEFINER
    LANGUAGE plpgsql
AS
$$

DECLARE
   _REC_stl_errors          RECORD;
   _REC_duplicates          RECORD;
BEGIN
   --CREATE TABLE IN PROD, truncate does not work, because of ownership issues (analysts need to run this procedure).
   TRUNCATE ct.reference_comm_networkpartner_working_day;

   --Grant access necessary, because
   GRANT SELECT ON ct.reference_comm_networkpartner_working_day TO GROUP ANALYST;
   GRANT SELECT ON ct.reference_comm_networkpartner_working_day TO powerbi;
   --Grant execute on procedure
   GRANT EXECUTE ON PROCEDURE ct.sp_reference_comm_networkpartner_working_day() TO GROUP ANALYST;

   --setting _REC_duplicates. Cannot use _REC_duplicates := syntax, because of subquery in from clause, combined with non-scalar output.
   --analyst_datasets.sp_pk_check_table, output function: #sp_pk_check_table

   INSERT INTO ct.reference_comm_networkpartner_working_day
      SELECT
           nwp.network_partner_id
         , nwp.network_partner_name
         , wdc."date"
         , wdc.day_of_week_name          AS day_short
         --leg 1:
         , 'NL'                          AS L1_country_cd
         , 'mon-fri'                     AS L1_wd
         , wdc.mon_to_fri_increment      AS l1_wd_incr
         --leg 2:
         , 'NL'                          AS L2_country_cd
         , 'mon-fri'                     AS L2_wd
         , wdc.mon_to_fri_increment      AS l2_wd_incr
         --leg 3:
         , nwp.country_code              AS L3_country_cd
         , nwp.workingdays_interval_leg3 AS L3_wd
         , CASE
               WHEN  nwp.workingdays_interval_leg3 IN('Country_default_increment', 'mon - fri') THEN wdc.mon_to_fri_increment
               WHEN  nwp.workingdays_interval_leg3 IN('tue - sat')                              THEN wdc.tue_to_sat_increment
               WHEN  nwp.workingdays_interval_leg3 IN('mon - sat')                              THEN wdc.mon_to_sat_increment
               ELSE -1
         END                             AS L3_wd_incr
      FROM
         ct.dim_networkpartner nwp
         LEFT JOIN mdm.dim_working_day_calculation wdc ON nwp.country_code = wdc.country_code
      WHERE 1=1
         --AND nwp_is_active = TRUE
         AND network_partner_type = 'Commercial'
         AND network_partner_country_undefined = FALSE
   ;

   CALL ct.sp_pk_check_table( pg_last_query_id() ); select * into _REC_duplicates from #sp_pk_check_table;
   IF _REC_duplicates.Dupes_Amount > 0 THEN RAISE EXCEPTION 'Duplicates found'; ELSE RAISE INFO 'No duplicates found'; END IF;

   EXCEPTION WHEN OTHERS THEN
   --GENERIC CANDIDATES:
      --Duplicate error:
      IF SQLERRM = 'Duplicates found' THEN
         RAISE EXCEPTION '% Duplicates found in total, for key values: %', _REC_duplicates.Dupes_Amount, _REC_duplicates.Duplicates_Check_PK;
            ELSE RAISE EXCEPTION 'Error %, State %', SQLERRM, SQLSTATE;
      END IF;
END;

$$;

