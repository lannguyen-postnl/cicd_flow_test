CREATE PROCEDURE sp_fact_parcel_event(_var_init boolean)
    SECURITY DEFINER
    LANGUAGE plpgsql
AS
$$


DECLARE
   _REC_duplicates 			record;
   _VAR_inserts 			int8;
   _VAR_last_update_ts      timestamp := (SELECT MAX(s3_partition_ts) FROM xbs.fact_parcel_event);
BEGIN
	    IF _VAR_init = TRUE THEN
		TRUNCATE TABLE xbs.fact_parcel_event;
		RAISE WARNING 'WARNING: An Initiation has started and the table fact_parcel_event has been TRUNCATED.';

INSERT INTO xbs.fact_parcel_event
				SELECT
				    case when event_trackingnumbercreationtime_utc is null then -1 else FNV_HASH(event_trackingnumber || event_trackingnumbercreationtime_utc || isnull(event_systemcode, '')||isnull(event_code,'')||event_datetime_utc||isnull(decode(event_testmode,1,'true',0,'false'),'')) end as fact_parcel_event_hid
				    ,case when event_trackingnumbercreationtime_utc is null then -1 else FNV_HASH(event_trackingnumber || event_trackingnumbercreationtime_utc) end as dim_trackingnumber_hid
				    ,case when event_sourcedevice_id is null then -1 else FNV_HASH(event_sourcedevice_id) end as dim_source_hid
				    ,case when event_systemcode is null then -1 else fnv_hash(event_systemcode) end as dim_systemcode_hid
				    ,event_trackingnumber as trackingnumber
				    ,event_trackingnumbercreationtime_utc  as creationtime_utc
				    ,event_trackingnumbercreationtime_utc_offset as creationtime_utc_offset
				    ,event_code
				    ,event_description
				    ,event_datetime_utc
				    ,event_datetime_utc_offset
				    ,event_location_code as location_code
				    ,event_location_name as location_name
				    ,event_testmode
				    ,max(s3_partition_ts)
				    FROM
				    ingest_db.cleanse_xbs.event_data ed
				    WHERE 0=0
				    and event_scannedtrackingnumber isnull
				    and ed.event_rnk=1
				    GROUP BY
				    fact_parcel_event_hid
				    ,dim_trackingnumber_hid
				    ,dim_source_hid
				    ,dim_systemcode_hid
				    ,event_trackingnumber
				    ,event_trackingnumbercreationtime_utc
				    ,event_trackingnumbercreationtime_utc_offset
				    ,event_code
				    ,event_description
				    ,event_datetime_utc
				    ,event_datetime_utc_offset
				    ,event_location_code
				    ,event_location_name
				    ,event_testmode
			  ;

     GET DIAGNOSTICS _VAR_inserts := ROW_COUNT;
     RAISE INFO 'Update completed: % rows inserted in xbs.fact_parcel_event', _VAR_inserts;
	 END IF;

	 IF _VAR_init = FALSE THEN
		RAISE WARNING 'WARNING: An incremental load on the table xbs.fact_parcel_event has been STARTED.';

INSERT INTO xbs.fact_parcel_event
				SELECT
				    case when event_trackingnumbercreationtime_utc is null then -1 else FNV_HASH(event_trackingnumber || event_trackingnumbercreationtime_utc || isnull(event_systemcode, '')||isnull(event_code,'')||event_datetime_utc||isnull(decode(event_testmode,1,'true',0,'false'),'')) end as fact_parcel_event_hid
				    ,case when event_trackingnumbercreationtime_utc is null then -1 else FNV_HASH(event_trackingnumber || event_trackingnumbercreationtime_utc) end as dim_trackingnumber_hid
				    ,case when event_sourcedevice_id is null then -1 else FNV_HASH(event_sourcedevice_id) end as dim_source_hid
				    ,case when event_systemcode is null then -1 else fnv_hash(event_systemcode) end as dim_systemcode_hid
				    ,event_trackingnumber as trackingnumber
				    ,event_trackingnumbercreationtime_utc  as creationtime_utc
				    ,event_trackingnumbercreationtime_utc_offset as creationtime_utc_offset
				    ,event_code
				    ,event_description
				    ,event_datetime_utc
				    ,event_datetime_utc_offset
				    ,event_location_code as location_code
				    ,event_location_name as location_name
				    ,event_testmode
				    ,max(s3_partition_ts)
				    FROM
				    ingest_db.cleanse_xbs.event_data ed
				    WHERE 0=0
				    and event_scannedtrackingnumber isnull
				    and ed.event_rnk=1
					and s3_partition_ts > _VAR_last_update_ts
				    GROUP BY
				    fact_parcel_event_hid
				    ,dim_trackingnumber_hid
				    ,dim_source_hid
				    ,dim_systemcode_hid
				    ,event_trackingnumber
				    ,event_trackingnumbercreationtime_utc
				    ,event_trackingnumbercreationtime_utc_offset
				    ,event_code
				    ,event_description
				    ,event_datetime_utc
				    ,event_datetime_utc_offset
				    ,event_location_code
				    ,event_location_name
				    ,event_testmode
			  ;

  GET DIAGNOSTICS _VAR_inserts := ROW_COUNT;
     RAISE INFO 'Update completed: % rows inserted in xbs.fact_parcel_event', _VAR_inserts;
	 END IF;

     CALL admin.sp_pk_check_table( PG_Last_Query_ID() );
   		SELECT * INTO _REC_duplicates FROM #sp_pk_check_table;
    	IF _REC_duplicates.dupes_amount > 0 THEN
   		RAISE EXCEPTION 'Duplicates found'; RAISE INFO 'No duplicates found';
    	END IF;

    	EXCEPTION WHEN OTHERS THEN
        	IF SQLERRM = 'Duplicates found' THEN
         		RAISE EXCEPTION '% Duplicates found in total, for key values: %',_REC_duplicates.dupes_amount,_REC_duplicates.Duplicates_Check_PK;
            ELSE RAISE EXCEPTION 'Error %, State %', SQLERRM, SQLSTATE;
        	END IF;

END;






$$;

