CREATE PROCEDURE sp_dim_systemcode(_var_init boolean)
    SECURITY DEFINER
    LANGUAGE plpgsql
AS
$$






DECLARE
   _REC_duplicates 			record;
   _VAR_inserts 			int8;
   --_VAR_last_update_ts      timestamp := (SELECT MAX(s3_partition_ts) FROM xbs.dim_systemcode);
BEGIN
	    --IF _VAR_init = TRUE THEN
		TRUNCATE TABLE xbs.dim_systemcode;
		RAISE WARNING 'WARNING: An Initiation has started and the table xbs.dim_systemcode has been TRUNCATED.';
	    --END IF;


	INSERT INTO xbs.dim_systemcode

with systemcode as (
select
case when event_systemcode is null then -1 else fnv_hash(event_systemcode) end as dim_systemcode_hid
, event_systemcode as systemcode
, case when event_systemcode = '0' then 'PARCEL CREATED'
	 when event_systemcode = '1' then 'ACCEPTED'
	 when event_systemcode = '2' then 'RELEASED'
	 when event_systemcode = '4' then 'ENCAPSULATED'
	 when event_systemcode = '12' then 'CUSTOMER PROCESS'
	 when event_systemcode = '15' then 'COLLECTION TRANSPORT'
	 when event_systemcode = '18' then 'COLLECTION'
	 when event_systemcode = '19' then 'PROCESSING DEPOT'
	 when event_systemcode = '20' then 'ACCEPTANCE'
	 when event_systemcode = '21' then 'INTERNATIONAL TRANSPORT'
	 when event_systemcode = '22' then 'CROSSDOCK'
	 when event_systemcode = '25' then 'END OF TRACKING UPDATES'
	 when event_systemcode = '31' then 'DELIVERY EXCEPTION (ACTION REQUIRED)'
	 when event_systemcode = '40' then 'IN CUSTOMS'
	 when event_systemcode = '41' then 'CUSTOMS EXCEPTION'
	 when event_systemcode = '91' then 'DELIVERY ATTEMPTED'
	 when event_systemcode = '92' then 'DELIVERY AWAITING COLLECTION'
	 when event_systemcode = '93' then 'AT LOCAL DEPOT LMC'
	 when event_systemcode = '100' then 'DELIVERED'
	 when event_systemcode = '101' then 'DELIVERED TO DESTINATION COUNTRY'
	 when event_systemcode = '111' then 'LOST OR DESTROYED'
	 when event_systemcode = '124' then 'RETURN IN TRANSIT'
	 when event_systemcode = '201' then 'FIRST ACCEPT'
	 when event_systemcode = '202' then 'FIRST RELEASE'
	 when event_systemcode = '301' then 'CUSTOMS EXPORT SCAN'
	 when event_systemcode = '302' then 'CUSTOMS IMPORT SCAN'
	 when event_systemcode = '303' then 'CUSTOMS IMPORT SCAN COMPLETED'
	 when event_systemcode = '1001' then 'ITEM INCOMPLETE DATA'
	 when event_systemcode = '1002' then 'ITEM RELEASED AFTER DATA COMPLETION (DEPRECATED)'
	 when event_systemcode = '1003' then 'PARCEL MARKED FOR CUSTOMS SPOT CHECK'
	 when event_systemcode = '1901' then 'PARCEL MARKED AS CORRECT AFTER CUSTOMS CHECK'
	 when event_systemcode = '1905' then 'PARCEL MARKED FOR PHYSICAL CHECK'
	 when event_systemcode = '2101' then 'IN TRANSIT - EXPORTED'
	 when event_systemcode = '2102' then 'ITEM RELEASED FROM CUSTOMS'
	 when event_systemcode = '4101' then 'ITEM HELD FOR CUSTOMS INSPECTION (DEPRECATED)'
	 when event_systemcode = '4102' then 'CONSIGNMENT CREATED (DEPRECATED)'
	 when event_systemcode = '4105' then 'CONSIGNMENT ERROR'
	 when event_systemcode = '4106' then 'CONSIGNMENT CANCELLED'
	 when event_systemcode = '9101' then 'AT TRANSFER DEPOT LMC'
	 when event_systemcode = '9102' then 'IN TRANSIT'
	 when event_systemcode = '9301' then 'OUT FOR DELIVERY'
	 when event_systemcode = '9302' then 'DELIVERY EXCEPTION - DELAYED'
	 when event_systemcode = '9303' then 'DELIVERY ATTEMPTED'
	 when event_systemcode = '9999' then 'INFORMATION'
	 when event_systemcode = '11101' then 'LOST'
	 when event_systemcode = '11102' then 'DESTROYED'
	 when event_systemcode = '11103' then 'ITEM SEIZED BY CUSTOMS'
	 when event_systemcode = '12401' then 'RETURN IN TRANSIT - REFUSED'
	 when event_systemcode = '12402' then 'RETURN IN TRANSIT - UNDELIVERABLE'
	 when event_systemcode = '12403' then 'RETURN IN TRANSIT - DAMAGED'
	 when event_systemcode = '12404' then 'RETURN IN TRANSIT - NOT COLLECTED (DEPRECATED)'
	 when event_systemcode = '12405' then 'RETURN IN TRANSIT - ACCORDING TO AGREEMENT'
	 when event_systemcode = '12406' then 'RETURN DELIVERED BY CARRIER'
	 when event_systemcode = '12501' then 'RETURN RECEIVED - REFUSED'
	 when event_systemcode = '12502' then 'RETURN RECEIVED - UNDELIVERABLE'
	 when event_systemcode = '12503' then 'RETURN RECEIVED - DAMAGED'
	 when event_systemcode = '12504' then 'RETURN RECEIVED - NOT COLLECTED'
	 when event_systemcode = '12505' then 'RETURN RECEIVED - ACCORDING TO AGREEMENT'
	 when event_systemcode = '12506' then 'RETURN RECEIVED - DESTROYED'
	 when event_systemcode = 'E03' then 'ACCEPTED'
	 when event_systemcode = 'E04' then 'RELEASED'
	 else UPPER(event_systemcodedescription)
	 end as systemcode_description,
	 min(s3_partition_ts) as s3_partition_ts
from ingest_db.cleanse_xbs.event_data
group by
dim_systemcode_hid
, event_systemcode
, event_systemcodedescription
)

select
dim_systemcode_hid
, systemcode
, systemcode_description
, min(s3_partition_ts) as s3_partition_ts
from systemcode
group by
dim_systemcode_hid
, systemcode
, systemcode_description

  ;

     GET DIAGNOSTICS _VAR_inserts := ROW_COUNT;
     RAISE INFO 'Update completed: % rows inserted in xbs.dim_system', _VAR_inserts;

     CALL admin.sp_pk_check_table( PG_Last_Query_ID() );
   		SELECT * INTO _REC_duplicates FROM #sp_pk_check_table;
    	IF _REC_duplicates.dupes_amount > 0 THEN
   		RAISE EXCEPTION 'Duplicates found'; RAISE INFO 'No duplicates found';
    	END IF;

    	EXCEPTION WHEN OTHERS THEN
        	IF SQLERRM = 'Duplicates found' THEN
         		RAISE EXCEPTION '% Duplicates found in total, for key values: %',_REC_duplicates.dupes_amount,_REC_duplicates.Duplicates_Check_PK;
            ELSE RAISE EXCEPTION 'Error %, State %', SQLERRM, SQLSTATE;
        	END IF;

END;






$$;

