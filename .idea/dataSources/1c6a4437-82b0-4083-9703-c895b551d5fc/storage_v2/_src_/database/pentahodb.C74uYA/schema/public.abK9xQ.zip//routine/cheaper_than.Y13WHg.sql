CREATE PROCEDURE cheaper_than()
    LANGUAGE plpgsql
AS
$$
  BEGIN
     COPY analyst_datasets.sp_Test_Ario2
   FROM 's3://postnl-datalake-cbs-consumption/Finance/input/ParcelMarginModel/ppm/translations/Test/Test.csv'
      iam_role 'arn:aws:iam::815649711844:role/Redshift_FullAccesPlusAddedEc2S3Access'
      IGNOREHEADER 1
      TRUNCATECOLUMNS
      ACCEPTINVCHARS as ' '
      emptyasnull
      blanksasnull
      dateformat 'auto'
      timeformat 'auto'
      format as csv
      delimiter ','
      NULL AS 'n/a';
  END
$$;

