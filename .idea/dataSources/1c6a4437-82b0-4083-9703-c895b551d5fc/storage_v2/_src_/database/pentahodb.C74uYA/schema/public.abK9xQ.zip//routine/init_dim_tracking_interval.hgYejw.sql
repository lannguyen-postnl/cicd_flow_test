CREATE PROCEDURE init_dim_tracking_interval()
    LANGUAGE plpgsql
AS
$$
DECLARE
     _VAR_inserts int;
     _VAR_deletes int;
     _VAR_TS varchar;
     _VAR_iterable int := 1;
BEGIN
   --Truncate target table:
   TRUNCATE TABLE  ldwh.dim_tracking_interval;
   
   --Create staging table part 1:
   DROP TABLE IF EXISTS   #sta_source;
   CREATE TEMPORARY TABLE #sta_source 
   (
       barcode_hid            BIGINT         ENCODE RAW
      ,barcode_bk             VARCHAR(256)   ENCODE lzo
      ,scan_ts                TIMESTAMP      ENCODE AZ64
      ,barcode_scan_hid       BIGINT         ENCODE RAW
      ,is_last_interval       BOOLEAN        ENCODE RAW
   );
   
   --Create staging table part 2:
   DROP TABLE IF EXISTS   #sta_mark_items;
   CREATE TEMPORARY TABLE #sta_mark_items 
   (
       barcode_hid            BIGINT         ENCODE RAW
      ,barcode_bk             VARCHAR(256)   ENCODE lzo
      ,scan_ts                TIMESTAMP      ENCODE az64
      ,barcode_scan_hid       BIGINT         ENCODE RAW
      ,row_nr                 INT2           ENCODE az64
      ,first_item_group       BOOLEAN       --ONLY WORKS FOR FLUSH AND FILL METHOD
      ,is_last_interval       BOOLEAN        ENCODE RAW
   )
   DISTSTYLE AUTO DISTKEY ( barcode_hid ) SORTKEY ( barcode_hid, scan_ts );
   _VAR_TS := ( SELECT admin.f_getdatetime_minutes() ||':' );
   RAISE INFO '% Created Staging tables', _VAR_TS;
   
   --Insert source items into staging table 1, remove any duplicates:
   INSERT INTO #sta_source
      SELECT
           barcode_hid  
         , barcode_bk   
         , scan_ts
         , fnv_hash( scan_ts , fnv_hash( barcode_hid ) ) AS barcode_scan_hid
         , CASE 
            WHEN max( scan_ts ) OVER ( PARTITION BY barcode_hid  ) = scan_ts 
               THEN TRUE ELSE FALSE 
         END AS is_last_interval
      FROM
         ldwh.merged_fact_postal_export_leg_1_sequence
   ;
   GET DIAGNOSTICS _VAR_inserts := ROW_COUNT; _VAR_TS := ( SELECT admin.f_getdatetime_minutes() ||':' );
   RAISE INFO '% % rows inserted in #sta_source', _VAR_TS, _VAR_inserts;
   
   RAISE INFO 'Start Loop:';
      --Start Loop:
      --Insert calculations into staging table 2.
      LOOP
      RAISE INFO 'Start Run: %', _VAR_iterable;
         INSERT INTO #sta_mark_items
            SELECT
                 barcode_hid  
               , barcode_bk   
               , scan_ts
               , barcode_scan_hid
               , ROW_NUMBER() OVER ( PARTITION BY barcode_hid ORDER BY scan_ts ) AS row_nr
               , CASE 
                  WHEN datediff(
                          d
                        , min(scan_ts) OVER ( PARTITION BY barcode_hid )       
                        , scan_ts
                     )   <= 300 
                  THEN TRUE ELSE FALSE END AS first_item_group
               , is_last_interval
            FROM
               #sta_source
            ORDER BY 
               barcode_hid, scan_ts;
            GET DIAGNOSTICS _VAR_inserts := ROW_COUNT; _VAR_TS := ( SELECT admin.f_getdatetime_minutes() ||':' );
            RAISE INFO '% % rows inserted in #sta_mark_items', _VAR_TS, _VAR_inserts;      
                  
         
         --Insert minimum value into fact_physical_item_ee
         INSERT INTO ldwh.dim_tracking_interval
            SELECT
                FNV_Hash( barcode_hid ,FNV_Hash( scan_ts ) )   AS ti_tracking_hid
               ,barcode_hid                                    AS ti_barcode_hid
               ,barcode_bk                                     AS ti_barcode_bk
               ,scan_ts                                        AS ti_scan_ts
               ,( scan_ts - 5   )::date                        AS ti_valid_from_dt
               ,( scan_ts + 300 )::date                        AS ti_valid_to_dt
               ,_VAR_iterable                                  AS ti_barcode_reused_nr
               ,is_last_interval                               AS ti_is_last_interval
               ,GETDATE()                                      AS record_last_modified_ts
            FROM 
               #sta_mark_items 
            WHERE 
               row_nr = 1;
         GET DIAGNOSTICS _VAR_inserts := ROW_COUNT; _VAR_TS := ( SELECT admin.f_getdatetime_minutes() ||':' );
         RAISE INFO '% % rows inserted in ldwh.dim_tracking_interval', _VAR_TS, _VAR_inserts;
         
         --Remove first item-group from #sta_source
         DELETE FROM 
            #sta_source
         USING
            #sta_mark_items
         WHERE 1=1
            AND #sta_mark_items.barcode_scan_hid = #sta_source.barcode_scan_hid
            AND #sta_mark_items.first_item_group = TRUE;

         _VAR_deletes := ( SELECT sum(rows) FROM STL_DELETE WHERE query = pg_last_query_id() );
         _VAR_TS := ( SELECT admin.f_getdatetime_minutes() ||':' );
         RAISE INFO '% % rows deleted from #sta_source', _VAR_TS, _VAR_deletes;
      
         --Truncate marking table 
         TRUNCATE #sta_mark_items;

         RAISE INFO 'End run %', _VAR_iterable;
         
         _VAR_iterable := _VAR_iterable + 1;
         
         EXIT WHEN ( SELECT Count(*) FROM #sta_source ) = 0;
      END LOOP;
   
   RAISE INFO 'End Loop';
   
EXCEPTION WHEN OTHERS THEN
   RAISE EXCEPTION 'Error %, State %', SQLERRM, SQLSTATE;
END;
$$;

