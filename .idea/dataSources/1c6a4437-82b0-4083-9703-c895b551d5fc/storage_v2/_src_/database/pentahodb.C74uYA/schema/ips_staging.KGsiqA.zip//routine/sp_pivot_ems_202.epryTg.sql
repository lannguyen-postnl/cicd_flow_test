CREATE PROCEDURE sp_pivot_ems_202(_init_ts timestamp without time zone)
    LANGUAGE plpgsql
AS
$$
/**********************************************************************************************************************
  *
  * Purpose/Description     : This stored procedure updates their target tables in which contains calculations of
                                different tracked events (on receptacle, dispatch and consignment level) that are pivoted and ready as input for the IMEC202_staging.
                                To see which events are tracked, please check ips_staging.config_ips_export_202_staging table.
  * Documentation reference : https://postnl.atlassian.net/wiki/spaces/CB/pages/3674866047/IMEC+202+302
  * Input expected          :
                                * _init_ts timestamp := '9999-12-31' then incremental data load for target tables
                                * _init_ts timestamp <> '9999-12-31' then flush & fill target tables
  * Output expected         : Inserts into target tables
                                * ips_staging.pivot_earliest_ems_202
  * Procedure called from   : ips_staging.job_update_pivot_earliest_ems_202(_init_ts:=timestamp)
  * Procedure calls         : n/a
  *
**********************************************************************************************************************/
DECLARE
    _var_colmn_expr_pivot   varchar(max);
    _var_alias_pivot        varchar(max);
    _var_fullquery_pivot    varchar(max);
    _var_current_ts         varchar := CURRENT_TIMESTAMP;
    _var_incremental_ts     timestamp;
    _var_inserts            int     := 0;
BEGIN
    IF _init_ts != '9999-12-31' THEN
        _var_incremental_ts := _init_ts;
        TRUNCATE ips_staging.pivot_earliest_ems_202;
        RAISE INFO '% - Truncated table ips_staging.pivot_earliest_ems_202 for initial load from %', _var_current_ts, _var_incremental_ts;
    ELSE
        _var_incremental_ts := (SELECT
                                    COALESCE(MAX(max_last_mod_dt), '2021-01-01')
                                FROM
                                    ips_staging.pivot_earliest_ems_202);
        RAISE INFO '% - Incremental partition date for ips_staging.pivot_earliest_ems_202: %', _var_current_ts, _var_incremental_ts;
    END IF;
    DROP TABLE IF EXISTS #colmn_expr_pivot;

     WITH
        column_expr_ems_events AS (SELECT DISTINCT
                                     ems_evt_name
                                   , ems_event_id
                                   , ems_event_final_alias as alias
                                   , 'first_ems_events' AS label
                                   , 'MAX(CASE WHEN ems_evt_id = ' || ems_event_id ||' AND ems_evt_name = \''|| ems_evt_name ||'\' THEN ' || sort_col ||
                                     ' END ) AS ' ||
                                     ems_event_final_alias
                                                        AS column_expr
                                 FROM
                                     ips_staging.config_ips_export_202_staging as config202
                                 where ems_event_id in (1,2,3,4,5,6,7,8,9,10)
                                 )
    SELECT
        LISTAGG(column_expr, '\n, ') AS agg_column_expr
        , LISTAGG(alias, ', ') AS agg_alias
    INTO #colmn_expr_pivot
    FROM
        column_expr_ems_events;

    _var_colmn_expr_pivot := (SELECT agg_column_expr FROM #colmn_expr_pivot);
    _var_alias_pivot := (SELECT agg_alias FROM #colmn_expr_pivot);
    RAISE INFO 'Start execution';

    _var_fullquery_pivot := 'INSERT INTO ips_staging.pivot_earliest_ems_202 (recptcl_fid_hid, max_last_mod_dt, ' || _var_alias_pivot ||')'||
                            '\n SELECT recptcl_fid_hid, MAX(last_mod_dt) as max_last_mod_dt, ' || _var_colmn_expr_pivot ||
                            '\n FROM ips_staging.fact_earliest_ems_evt_202 ' ||
                            '\n WHERE last_mod_dt > \'' || _var_incremental_ts ||
                            '\'\n GROUP BY recptcl_fid_hid;';

    RAISE INFO '%', _var_fullquery_pivot;

    EXECUTE _var_fullquery_pivot;
    GET DIAGNOSTICS _VAR_inserts := ROW_COUNT; RAISE INFO '% rows inserted into ips_staging.pivot_earliest_ems_202', _VAR_inserts;

END ;
$$;

