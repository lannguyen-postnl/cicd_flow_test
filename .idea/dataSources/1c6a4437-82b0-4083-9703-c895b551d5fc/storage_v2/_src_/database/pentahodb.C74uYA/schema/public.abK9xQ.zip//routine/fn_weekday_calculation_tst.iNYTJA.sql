CREATE FUNCTION fn_weekday_calculation_tst(start_date timestamp without time zone, end_date timestamp without time zone) RETURNS integer
    STABLE
    LANGUAGE plpythonu
AS
$$ 	 	
	from datetime import datetime as dt
	from datetime import timedelta as td
	import numpy as np
	if start_date:
		if end_date:
			if end_date.weekday() == 5:
				last_day = dt.DaysInMonth(end_date.year, end_date.month)
				if end_date.day != last_day and end_date.month != 12:
					end_date = dt.datetime(end_date.day+2,end_date.month,end_date.year)
				elif end_date.day == last_day and end_date.month !=12:
					end_date = dt.datetime(2,end_date.month+1,end_date.year)
				elif end_date.day == last_day and end_date.month == 12:
					end_date = dt.datetime(2,1,end_date.year+1)
			elif end_date.weekday() == 6:
				last_day = dt.DaysInMonth(end_date.year, end_date.month)
				if end_date.day != last_day and end_date.month != 12:
					end_date = dt.datetime(end_date.day+1,end_date.month,end_date.year)
				elif end_date.day == last_day and end_date.month !=12:
					end_date = dt.datetime(1,end_date.month+1,end_date.year)
				elif end_date.day == last_day and end_date.month == 12:
					end_date = dt.datetime(1,1,end_date.year+1)
			diff = (end_date.date()-start_date.date()).days
			counter = 0
			for single_date in (start_date +td(n) for n in xrange(diff)):
				print single_date, single_date.weekday()
			return counter
	return None
  $$;

