CREATE OR REPLACE VIEW commercial_parcels AS
WITH
    ktv AS
        (SELECT
             p.dn_barcode                                                            AS dn_barcode
           , da_downnetwpartnerbarcd                                                 AS nwpb
           , da_downnetwpartnercontractid                                            AS nwpid
           , p.da_downnetwpartnercontractid                                          AS da_downnetwpartnercontractid
           , nwp.network_partner_code_lookupkey                                      AS network_partner_code_lookupkey
           , nwp.network_partner_name                                                AS nwp_network_partner_name
           , namelook.network_partner_name                                           AS name_look_network_partner
           , p.da_landcode                                                           AS da_landcode
           , ROW_NUMBER() OVER ( PARTITION BY p.dn_barcode)                          AS rnk
           , infeed_method_code_bk                                                   AS me
           , da_postcode                                                             AS zipcode
           , postal_code
           , da_omschrijving
           , location_j61
           , ma_lengte
           , ma_breedte
           , ma_hoogte
           , ma_gewicht
           , (ma_lengte + ma_breedte + ma_hoogte)                                    AS omtrek
           , SUBSTRING(p.dn_barcode, 3, 4)                                           AS "clientcode"
           , date(j64)                                                               AS j64
           , date(q11)                                                               AS q11
           , date(q12)                                                               AS q12
           , date(x02)                                                               AS x02
           , date(x07)                                                               AS x07
           , date(x08)                                                               AS x08
           , date(y05)                                                               AS y05
           , date(y55)                                                               AS y55
           , date(j06)                                                               AS j06
           , date(j61)                                                               AS j61
           , date(b01)                                                               AS b01
           , date(LEAST(b01, j61, j64, j06))                                         AS "processed date"
           , date(LEAST(x05, y05, y55, z01, z02, z03, z04, z05, z06, z07, z08, z80)) AS "date_of_delivery"
           , CASE
                 WHEN infeed_method_code_bk = 'DI' THEN 'RI'
                 ELSE me
                 END                                                                 AS me2
           , CASE
                 WHEN p.da_downnetwpartnercontractid IN
                      ('COLISSIMO/FR/NONPOD', 'CPR-01-C/174069/FR/KI', 'CPR-01-C/174069/FR')
                     AND da_omschrijving = 'ColisPrive-Frankrijk' THEN 'Colis Prive - FR'
                 WHEN p.da_downnetwpartnercontractid IN ('DPD-01/23400/FR', 'DPD-01/23400/FR/TC')
                     AND da_omschrijving = 'DPD-Frankrijk' THEN 'DPD - FR'
                 --when da_downnetwpartnercontractid = 'DPD/23400/GB' and da_omschrijving = 'DPD-Frankrijk' then 'DPD - GB'
                 WHEN p.da_downnetwpartnercontractid IN
                      ('DPD-01/23400', 'DPD-01/23400/BG', 'DPD-01/23400/TC', 'G-01/UPU', 'DPD-01/23400/TOC/BG')
                     AND da_omschrijving = 'DPD-Bulgarije' THEN 'DPD - BG'
                 WHEN da_downnetwpartnercontractid IN
                      ('DPD-01/23400/DK', 'DPD-01/23400/DK', 'DPD-01/23400/TC', 'DPD-01/23400/TOC/DK')
                     AND da_omschrijving = 'DPD-Denemarken' THEN 'DPD - DK'
                 WHEN p.da_downnetwpartnercontractid = 'DPD-01/23400/TC'
                     AND da_omschrijving = 'DPD-Ierland' THEN 'DPD - IE'
                 WHEN p.da_downnetwpartnercontractid IN
                      ('DPD-01/23400', 'DPD/23400/LU', 'DPD-01/23400/LU', 'DPD-01/23400/TOC/LU')
                     AND da_omschrijving = 'DPD-Luxemburg' THEN 'DPD - LU'
                 WHEN p.da_downnetwpartnercontractid IN
                      ('DPD-01/23400', 'DPD-01/23400/PL', 'DPD-01/23400/TC', 'DPD-01/23400/TOC/PL')
                     AND da_omschrijving = 'DPD-Polen' THEN 'DPD - PL'
                 WHEN p.da_downnetwpartnercontractid IN
                      ('DPD-01/23400', 'DPD-01/23400/TC', 'DPD-01/23400/RO', 'DPD-01/23400/TOC/RO')
                     AND da_omschrijving = 'DPD-Roemenie' THEN 'DPD - RO'
                 WHEN p.da_downnetwpartnercontractid IN ('DPD-01/23400/SE', 'DPD-01/23400')
                     AND da_omschrijving = 'DPD-Zweden' THEN 'DPD - SE'
                 WHEN p.da_downnetwpartnercontractid IN
                      ('DPD-01/23400', 'DPD-01/23400/TC', 'DPD-01/23400/SI', 'DPD-01/23400/TOC/SI', 'G-01/UPU')
                     AND da_omschrijving = 'DPD-Slovenie' THEN 'DPD - SI'
                 WHEN p.da_downnetwpartnercontractid IN
                      ('EURODIS/160522/DNP', 'EURODIS/160522/DNP/TOC', 'EURODIS/160522/RTN', 'EU-01/EURODIS/DNP',
                       'EU-01/EURODIS/DNP/TOC')
                     AND da_omschrijving = 'EURODIS AT' THEN 'Eurodis - AT'
                 WHEN p.da_downnetwpartnercontractid = 'Eurodis/BG/DNP' THEN 'Eurodis - BG'
                 WHEN p.da_downnetwpartnercontractid IN
                      ('EURODIS/160526/DNP', 'EURODIS/160526/DNP/TOC', 'EU-01/EURODIS/DNP/TOC', 'EU-01/EURODIS/DNP')
                     AND da_omschrijving = 'EURODIS CZ' THEN 'Eurodis - CZ'
                 WHEN p.da_downnetwpartnercontractid IN
                      ('EURODIS/113846/DNP', 'EURODIS/113846/RTN', 'EURODIS/113850/RTN', 'EU-01/EURODIS/DNP',
                       'H-02/9652')
                     AND da_omschrijving = 'EURODIS DE' THEN 'Eurodis - DE'
                 WHEN p.da_downnetwpartnercontractid = 'Eurodis/DK/DNP'
                     AND da_omschrijving = 'EURODIS DK' THEN 'Eurodis - DK'
                 WHEN p.da_downnetwpartnercontractid = 'Eurodis/ES/DNP'
                     AND da_omschrijving = 'EURODIS ES' THEN 'Eurodis - ES'
                 WHEN p.da_downnetwpartnercontractid = 'Eurodis/FR/DNP'
                     AND da_omschrijving = 'EURODIS FR' THEN 'Eurodis - FR'
                 WHEN p.da_downnetwpartnercontractid IN ('EURODIS/113850/DNP', 'EU-01/EURODIS/DNP')
                     AND da_omschrijving = 'EURODIS GB' THEN 'Eurodis - GB'
                 WHEN p.da_downnetwpartnercontractid IN
                      ('EURODIS/160562/DNP', 'EURODIS/160562/DNP/TOC', 'EU-01/EURODIS/DNP/TOC', 'EU-01/EURODIS/DNP')
                     AND da_omschrijving = 'EURODIS HU' THEN 'Eurodis - HU'
                 WHEN p.da_downnetwpartnercontractid IN
                      ('EURODIS/160535/DNP', 'EURODIS/160535/DNP/TOC', 'EU-01/EURODIS/DNP', 'EU-01/EURODIS/DNP/TOC')
                     AND da_omschrijving = 'EURODIS IT' THEN 'Eurodis - IT'
                 WHEN p.da_downnetwpartnercontractid = 'Eurodis/PT/DNP'
                     AND da_omschrijving = 'EURODIS PT' THEN 'Eurodis - PT'
                 WHEN p.da_downnetwpartnercontractid = 'Eurodis/RO/DNP'
                     AND da_omschrijving = 'EURODIS RO' THEN 'Eurodis - RO'
                 WHEN p.da_downnetwpartnercontractid IN
                      ('EURODIS/160548/DNP', 'EURODIS/160548/DNP/TOC', 'EU-01/EURODIS/DNP', 'EU-01/EURODIS/DNP/TOC',
                       'G-01/UPU')
                     AND da_omschrijving = 'EURODIS SK' THEN 'Eurodis - SK'
                 WHEN p.da_downnetwpartnercontractid IN
                      ('H-02/UK/NEXTDAY', 'H-02/UK/Nextday/SINGLE', 'HERMES/24/B2C', 'HERMES/24/B2C/CLS',
                       'HERMES/24/B2C/FLORA/2')
                     AND da_omschrijving = 'Hermes-GB-Verenigd Koninkrijk' THEN 'EVRi - GB'
                 WHEN p.da_downnetwpartnercontractid IN ('HERMES/24/B2C', 'HERMES/24/B2C/FLORA/2')
                     AND da_omschrijving = 'Hermes-GB-Verenigd Koninkrijk' THEN 'EVRi - GB (Flora)'
                 WHEN p.da_downnetwpartnercontractid IN
                      ('H-02/9652', 'AP-IMEC', 'H-02/DE/CUST1', 'EURODIS/113846/RTN', 'H-02/9652', 'H-02/DE/PU',
                       'H-02/DE/FLOWERS', 'H-02/DE/PU', 'INTERCONNECT/DE', 'MEDEANL/IMPORT')
                     AND da_omschrijving = 'HERMES-Duitsland' THEN 'Hermes - DE'
                 --        when p.da_downnetwpartnercontractid in ('H-02/9652'
                 --        , 'H-02/9652'
                 --        , 'H-02/DE/CUST1'
                 --        , 'H-02/DE/FLOWERS'
                 --        , 'H-02/DE/PU')
                 --        and da_omschrijving = 'HERMES-Duitsland' then 'Hermes - DE (XDL)'
                 --        when p.da_downnetwpartnercontractid in ('H-02/DE/CUST1')
                 --        and da_omschrijving = 'HERMES-Duitsland' then 'Hermes - DE (DI)'
                 WHEN p.da_downnetwpartnercontractid IN ('MRW/ES', 'EURODIS/113850/RTN', 'MRW-01/ES')
                     AND da_omschrijving = 'MRW-Spanje' THEN 'MRW - ES'
                 WHEN p.da_downnetwpartnercontractid IN ('MRW-01/PT')
                     AND da_omschrijving = 'MRW-Portugal' THEN 'MRW - PT'
                 WHEN p.da_downnetwpartnercontractid IN
                      ('IT-01/167128/ECON16', 'IT-01/167128/Econ16/OOA', 'IT-01/167128/EXPRESS',
                       'IT-01/167128/Express14', 'IT-01/167128/Express14/OOA')
                     OR da_omschrijving IN ('Posti Ltd -Finland', 'Posti Ltd-Finland/48') THEN 'Posti Ltd - FI'
                 WHEN p.da_downnetwpartnercontractid IN
                      ('UPS/US', 'UPS-01/SAVER', 'UPS-01/SAVER/DDU/POOW', 'UPS-01/SAVER/DDU/XBLL')
                     AND da_omschrijving = 'UPS-US' THEN 'UPS - US'
                 WHEN p.da_downnetwpartnercontractid IN
                      ('HOME24 POD B2C', 'HOME24 POD B2C/2', 'HOME24 POD C2C', 'HOME48 POD B2C', 'HOME48 POD C2C',
                       'HOME48 POD B2C', 'YODEL/HIGH', 'YODEL/HIGH/2', 'YODEL-02/996366/H24PODB2C',
                       'YODEL-02/996366/H48PODB2C')
                     AND da_omschrijving = 'YODEL-Verenigd Koninkrijk' THEN 'Yodel - GB'
                 WHEN p.da_downnetwpartnercontractid = 'COLISSIMO/FR/NONPOD' THEN 'Colissimo - FR'
                 END                                                                 AS network_partner
           , CASE
                 WHEN nwp.network_partner_code_lookupkey = p.da_downnetwpartnercontractid
                     AND nwp.network_partner_name LIKE '%Eurodis%' THEN CONCAT('Eurodis - ', da_landcode)
                 ELSE network_partner
                 END                                                                 AS network_partner2
           , CASE
                 WHEN nwp.network_partner_code_lookupkey = p.da_downnetwpartnercontractid
                     AND nwp.network_partner_name LIKE '%DPD%' THEN CONCAT('DPD - ', da_landcode)
                 ELSE network_partner2
                 END                                                                 AS network_partner3
           , CASE
                 WHEN da_omschrijving = namelook.network_partner_name_lookupkey THEN 'Unknown'
                 ELSE network_partner3
                 END                                                                 AS network_partner4
             --    ,
             --    case
             --        when nwp.network_partner_code_lookupkey = p.da_downnetwpartnercontractid
             --        and da_omschrijving = namelook.network_partner_name_lookupkey then nwp.network_partner_name 
             --    end as Network_Partner5
           , CASE
                 WHEN network_partner4 = 'Hermes - DE'
                     AND x02 IS NOT NULL
                     AND y05 IS NOT NULL
                     AND y55 IS NOT NULL
                     AND j64 IS NOT NULL
                     AND j06 IS NULL
                     AND j61 IS NULL
                     AND q12 IS NULL
                     AND q11 IS NULL
                     AND b01 IS NULL
                     THEN 'Hermes - DE (DI)'
                 WHEN network_partner4 = 'Hermes - DE'
                     AND q12 IS NOT NULL
                     AND q11 IS NOT NULL
                     AND j64 IS NOT NULL
                     AND b01 IS NULL
                     THEN 'Hermes - DE (XDL)'
                 WHEN network_partner4 = 'EVRi - GB'
                     AND x02 IS NOT NULL
                     AND y05 IS NOT NULL
                     AND y55 IS NOT NULL
                     AND j64 IS NOT NULL
                     AND j06 IS NULL
                     AND j61 IS NULL
                     AND q12 IS NULL
                     AND q11 IS NULL
                     AND b01 IS NULL
                     THEN 'EVRi - GB (Flora)'
                 ELSE network_partner4
                 END                                                                 AS network_partner5
           , sta.e2e
           , ooa.pc_combine                                                          AS ooa_pc
           , CONCAT(network_partner4, da_postcode)                                   AS eps_pc
           , CASE
                 WHEN eps_pc = ooa_pc THEN 'OOA'
                 ELSE
                     CASE
                         WHEN network_partner4 = 'Hermes - DE'
                             AND (ma_lengte > 1200
                                 OR ma_breedte > 600
                                 OR ma_hoogte > 600) THEN 'Bulky'
                         ELSE
                             CASE
                                 WHEN network_partner4 = 'EVRi - GB'
                                     AND ma_gewicht > 1500 THEN 'Bulky'
                                 ELSE
                                     CASE
                                         WHEN network_partner4 = 'Eurodis - AT'
                                             OR network_partner4 = 'Eurodis - GB'
                                                  AND omtrek > 3300
                                             OR ma_lengte > 2000 THEN 'Bulky'
                                         ELSE 'Regular'
                                         END
                                 END
                         END
                 END                                                                 AS format
           , CASE
                 WHEN network_partner IN ('Hermes - DE (DI)', 'EVRi - GB (Flora)', 'Hermes - DE (XDL)')
                     AND sta.e2e = 2 THEN 2
                 ELSE sta.e2e
                 END                                                                 AS standard_e2e
           , CASE
                 WHEN network_partner4 = 'EVRi - GB' THEN standard_e2e + 2
                 WHEN network_partner4 = 'Hermes - DE' THEN standard_e2e + 1
                 WHEN network_partner4 = 'DPD - DK'
                     OR network_partner4 = 'DPD - FR' THEN standard_e2e + 1
                 WHEN network_partner4 = 'Eurodis - DE'
                     OR network_partner4 = 'Eurodis - CZ' THEN standard_e2e + 1
                 WHEN network_partner4 = 'Eurodis - AT'
                     OR network_partner4 = 'Eurodis - IT' THEN standard_e2e + 1
                 WHEN network_partner4 = 'Colis Prive - FR'
                     OR network_partner4 = 'MRW - ES' THEN standard_e2e + 1
                 WHEN network_partner4 = 'Correos - ES' THEN standard_e2e + 1
                 END                                                                 AS standard_e2e_exceptions
         --    ,
         --    case
         --        when "processed date" is not null
         --        and "date_of_delivery" is not null
         --        -- and "date_of_delivery" >= "processed date"
         --        -- and da_landcode = nwd.country_code
         --        --then diff_process_delivery - (
         --then datediff(day
         --        , nwd."date"
         --        , "date_of_delivery") + datediff(day
         --        , nwd."date"
         --        , "processed date")
         --    end as nonewdays
         --    , (diff_process_delivery - nonewdays) as Transit_Time
         --,
         --case
         --when t1< 0 then 0
         -- else    
--,
--    case
--        when Transit_Time is null then null
--    else
--        case
--            when "date_of_delivery" is not null then
--            case
--                when "processed date" is null then 'Wrong Sequence'
--            else
--                case
--                    when Format = 'OOA'
--                or Format = 'Bulky' then
--                    case
--                        when Transit_Time <= Standard_E2E_Exceptions then 'Yes'
--                    else 'No'
--                end
--                else
--                    case
--                        when Transit_Time <= Standard_E2E then 'Yes'
--                    else 'No'
--                end
--            end
--        end
--    end
--end as on_time
         FROM
             pentahodb.collo.collo_eps_pivot p
                 LEFT JOIN analyst_datasets.dim_cbs_standards sta ON
                             p.da_landcode || '-Comm. Netw. Parcels NL Export' = sta.standard_composite_key
                     AND LEAST(b01, j61, j64, j06) >= sta."valid_from"
                     AND LEAST(b01, j61, j64, j06) <= sta."valid_to"
                 --left join ttint_dm.dim_calendar dc on dc.day_date = DATE(least(b01, j61, j64, j06))
--left join analyst_datasets.dim_non_working_days nwd on
--            nwd.country_code = p.da_landcode
-- and
--nwd."date" between DATE(least(b01, j61, j64, j06)) and DATE(least(x05, y05, y55, z01, z02, z03, z04, z05, z06, z07, z08, z80))
--and nwd.non_working_day is not null
--and nwd."date" >(current_date -10)
--left join ct.reference_collo_sta_networkpartner nwp2 on
--eps.da_downnetwpartnercontractid = nwp2.network_partner_lookupkey
                 LEFT JOIN mdm.mdm_nwp_partner_contract_lookup nwp ON
                 nwp.network_partner_code_lookupkey = p.da_downnetwpartnercontractid
                 --left join mdm.mdm_nwp_partner_name_lookup n on
--p.da_downnetwpartnercontractid = n.network_partner_name_lookupkey
                 LEFT JOIN mdm.mdm_nwp_partner_name_lookup namelook ON
                     namelook.network_partner_name_lookupkey = p.da_downnetwpartnercontractid
                 LEFT JOIN analyst_datasets.ooa_postal_codes_eps ooa ON
                 (nwp.network_partner_name || p.da_postcode = ooa.pc_combine)
                 LEFT JOIN ct.df_export_commercial_item ct ON
                 ct.barcode_bk = p.dn_barcode
         WHERE date("processed date") > (CURRENT_DATE - 100)
           AND "processed date" IS NOT NULL
           AND "date_of_delivery" IS NOT NULL
           AND p.dn_barcode LIKE '3S%'
           AND nwp.network_partner_name NOT LIKE 'EPG%'
--and p.dn_barcode = '3SAAWE251644278'
        )
  , ktv_nn_working_day AS
        (SELECT
             ktvs.dn_barcode
           , SUM(nwd.non_working_day) AS nn_w_days
         FROM
             ktv AS ktvs
                 LEFT JOIN analyst_datasets.dim_non_working_days nwd ON
                         nwd.country_code = ktvs.da_landcode
                     AND nwd."date" BETWEEN "processed date" AND "date_of_delivery"
         GROUP BY
             dn_barcode)
SELECT
    ktv.dn_barcode
    -- , nn
    -- , nn1
  , nwpb
  , nwpid
  , me2
  , network_partner4
    -- , des
  , zipcode
  , postal_code
  , da_omschrijving
  , location_j61
  , ma_lengte
  , ma_breedte
  , ma_hoogte
  , ma_gewicht
  , omtrek
  , "clientcode"
  , "processed date"
  , "date_of_delivery"
  , ooa_pc
  , eps_pc
  , format
  , standard_e2e
  , standard_e2e_exceptions
  , j64
  , q11
  , q12
  , x02
  , x07
  , x08
  , y05
  , y55
  , j06
  , j61
  , b01
  , nn_w_days AS nn1
  , CASE
        WHEN "processed date" IS NOT NULL
            AND "date_of_delivery" IS NOT NULL
            THEN (DATEDIFF(DAY
            , "processed date"
            , "date_of_delivery"))
        -- coalesce (nn_w_days,0) 
        -- then 1
        -- else 0
        END   AS diff_process_delivery
  , CASE
        WHEN nwd.nn_w_days IS NOT NULL THEN (diff_process_delivery - nn1)
        ELSE diff_process_delivery
        END   AS transit_time
  , CASE
        WHEN transit_time IS NULL THEN NULL
        ELSE
            CASE
                WHEN "date_of_delivery" IS NOT NULL THEN
                    CASE
                        WHEN "processed date" IS NULL THEN 'Wrong Sequence'
                        ELSE
                            CASE
                                WHEN format = 'OOA'
                                    OR format = 'Bulky' THEN
                                    CASE
                                        WHEN transit_time <= standard_e2e_exceptions THEN 'Yes'
                                        ELSE 'No'
                                        END
                                ELSE
                                    CASE
                                        WHEN transit_time <= standard_e2e THEN 'Yes'
                                        ELSE 'No'
                                        END
                                END
                        END
                END
        END   AS on_time
FROM
    ktv
        LEFT JOIN ktv_nn_working_day nwd ON nwd.dn_barcode = ktv.dn_barcode
WHERE rnk = 1 AND ktv.dn_barcode = '3SAAWE251644278'
GROUP BY
    ktv.dn_barcode
  , nwpb
  , nwpid
  , me2
  , network_partner4
    --, nwd_process
    --, nwd_delivery
    -- , nwd_p_d
    --, nwpname
    --, des
  , zipcode
  , postal_code
  , da_omschrijving
  , location_j61
  , ma_lengte
  , ma_breedte
  , ma_hoogte
  , ma_gewicht
  , omtrek
  , "clientcode"
  , "processed date"
  , "date_of_delivery"
  , diff_process_delivery
    --, "e2e_standard"
  , ooa_pc
  , eps_pc
  , format
  , standard_e2e
  , standard_e2e_exceptions
  , transit_time
  , on_time
  , j64
  , q11
  , q12
  , x02
  , x07
  , x08
  , y05
  , y55
  , j06
  , j61
  , b01
    -- , nn
  , nn1
WITH NO SCHEMA BINDING
;

ALTER TABLE commercial_parcels
    OWNER TO fanielmebrahtuhailemica;

GRANT SELECT ON commercial_parcels TO powerbi;

GRANT DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE ON commercial_parcels TO GROUP analyst;

