CREATE FUNCTION fn_weekday_sunday_calculation(start_date timestamp without time zone, end_date timestamp without time zone) RETURNS integer
    STABLE
    LANGUAGE plpythonu
AS
$$ 	 	
	from datetime import datetime as dt
	from datetime import timedelta as td
	import numpy as np
	if start_date:
	    if end_date:
	        diff = (end_date.date()-start_date.date()).days
	        counter = 0
	        for single_date in (start_date +td(n) for n in xrange(diff)):
	            print single_date, single_date.weekday()
	            if single_date.weekday() != 6:
	                counter+=1
	        return counter
	return None
  $$;

