CREATE PROCEDURE sp_dim_transport_order()
    SECURITY DEFINER
    LANGUAGE plpgsql
AS
$$





DECLARE
   _REC_duplicates 			record;
   _VAR_inserts 			int8;
   --_VAR_last_update_ts      timestamp := (SELECT MAX(s3_partition_ts) FROM prep_cbs_tom.root);
BEGIN
	    --IF _VAR_init = TRUE THEN
		TRUNCATE TABLE tom.dim_transport_order;
		RAISE WARNING 'WARNING: An Initiation has started and the table dim_transport_order has been TRUNCATED.';
	    --END IF;


	INSERT INTO tom.dim_transport_order
		SELECT
			FNV_HASH(documentid)  as dim_transport_order_id_hid
			,documentid as transport_order_id_bk
			,cancelledwithfee
			,cast(documentdatetime as timestamp)
			,cast(executiondate as timestamp)
			,fueltype
			,fueltypereferencecode
			,"handler"
			,isdayorder
			,istransportorder
			,orderline_alternatedocumentid
			,nullif(orderreference,'')
			,ordersort
			,ordertype
		FROM
		ingest_db.prep_cbs_tom.root
		WHERE len(documentid)=5 --or len(documentid)=6
		GROUP BY
		dim_transport_order_id_hid
		,transport_order_id_bk
		,cancelledwithfee
		,documentdatetime
		,executiondate
		,fueltype
		,fueltypereferencecode
		,"handler"
		,isdayorder
		,istransportorder
		,orderline_alternatedocumentid
		,orderreference
		,ordersort
		,ordertype
  ;

     GET DIAGNOSTICS _VAR_inserts := ROW_COUNT;
     RAISE INFO 'Update completed: % rows inserted in tom.sp_dim_transport_order', _VAR_inserts;

	CALL admin.sp_pk_check_table( PG_Last_Query_ID() );
   	SELECT * INTO _REC_duplicates FROM #sp_pk_check_table;
   	IF _REC_duplicates.dupes_amount > 0 THEN
   		RAISE EXCEPTION 'Duplicates found'; RAISE INFO 'No duplicates found';
   	END IF;

   	EXCEPTION WHEN OTHERS THEN
      	IF SQLERRM = 'Duplicates found' THEN
        		RAISE EXCEPTION '% Duplicates found in total, for key values: %',_REC_duplicates.dupes_amount,_REC_duplicates.Duplicates_Check_PK;
         ELSE RAISE EXCEPTION 'Error %, State %', SQLERRM, SQLSTATE;
     	END IF;

END;





$$;

