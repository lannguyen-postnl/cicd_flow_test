CREATE FUNCTION f_py_greater(enddate timestamp without time zone, startdate timestamp without time zone) RETURNS double precision
    STABLE
    LANGUAGE plpythonu
AS
$$
	from datetime import date
	f_date = date(2014, 7, 2)
	l_date = date(2014, 7, 11)
	delta = l_date - f_date
	print(delta.days)
$$;

