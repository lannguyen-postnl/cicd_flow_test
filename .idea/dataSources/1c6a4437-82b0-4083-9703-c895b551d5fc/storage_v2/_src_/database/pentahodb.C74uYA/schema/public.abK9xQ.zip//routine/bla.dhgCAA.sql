CREATE PROCEDURE bla()
    LANGUAGE plpgsql
AS
$$
DECLARE
  rec RECORD;
  query text;
BEGIN
  rec := ( Select top 2 blabla from (
   Select
        pg_get_constraintdef( con.oid )
      , conrelid                                                                                    as tableid
      , SUBSTRING( pg_get_constraintdef( con.oid ), 14, len( pg_get_constraintdef(con.oid) ) - 14 ) as PK_LIST
      , case when nspname ilike 'pg_temp_%' then '' else nspname || '.' end  || relname             as schema_table--temp tables don't use schema's nspname =schemaName. relName = table name
         , 'With dupes_table as 
            ( Select top 1000 ' 
               || PK_LIST  
               || ', count(*) as dupes' 
            || ' From ' 
               || schema_table 
            || ' Group by ' 
               || PK_LIST
            || ' Having dupes 
                  > 1 Order by dupes desc)' 
         ||' Select COALESCE( ''Duplicates found for ' || schema_table || '''||  listagg( '': Dupl_PK{'' ||' || PK_LIST || '|| ''}, #Dupl('' || dupes ||'')'', ''; ''), ''No Duplicates'') as Duplicates_Check_PK'
         ||' From dupes_table'
            as dyn_query_specific
      , 'Select count(*) as total, count(distinct ' || PK_LIST || ') as PK_value, total - PK_value as duplicates, ''' || nspname || ''' as schemaname, ''' || relname ||  ''' as tablename From ' || schema_table as blabla
   From
      pg_constraint CON 
      LEFT JOIN pg_class      AS tbl ON tbl.relnamespace = con.connamespace AND tbl.oid = con.conrelid
      LEFT JOIN pg_namespace  AS sch ON sch.oid          = tbl.relnamespace
   Where 1=1
       AND CON.contype  = 'p'
   ) );
  FOR REC IN EXECUTE REC.blabla
  LOOP
    RAISE INFO ' %', rec.blabla;
  END LOOP;
END;
$$;

