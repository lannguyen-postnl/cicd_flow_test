CREATE OR REPLACE VIEW public.pnp_sop_in_transit_leg0
AS
SELECT
    derived_table1.processed_items
  , date(derived_table1.event1233date) AS pre_alert_date
  , COUNT(derived_table1.barcode)      AS nr_of_items
  , COUNT(CASE
              WHEN derived_table1.product_code::text <> 'LXB'::character varying::text
                  AND derived_table1.product_code::text <> 'IXB'::character varying::text
                  AND derived_table1.product_code::text <> 'UBZ'::character varying::text
                  AND derived_table1.product_code::text <> 'UPZ'::character varying::text
                  AND derived_table1.client_code::text = 'SNT'::character varying::text THEN derived_table1.barcode
              ELSE NULL::character varying
    END)                               AS nr_of_items_filtered
  , COUNT(CASE
              WHEN derived_table1.client_code::text = 'SHI'::character varying::text THEN derived_table1.barcode
              ELSE NULL::character varying
    END)                               AS nr_of_items_shein
  , COUNT(CASE
              WHEN derived_table1.client_code::text IN ('SFP'::character varying::text, 'FPX'::character varying::text)
                  THEN derived_table1.barcode
              ELSE NULL::character varying
    END)                               AS nr_of_items_pdd
FROM
    (SELECT
         fact.barcode
       , client.client_code
       , pro.product_code
       , man.manifest_code
       , man.manifest_mawb_carrier
       , man.manifest_mawb_number
       , man.hawb
       , fact.item_manifest_weight_gram
       , cou.country_code
       , bag.mailbag_route
       , bag.mailbag_key
       , fact.event1233date
       , fact.event2010date
       , fact.event2011date
       , fact.event2012date
       , fact.event2013date
       , fact.event173datelocal
       , fact.event134date
       , fact.event3013date
       , fact.event8date
       , fact.event1241date
       , CONVERT_TIMEZONE('UTC'::character varying::text, 'Europe/Amsterdam'::character varying::text,
                          fact.event3116date) AS event3116datelocal
       , CASE
             WHEN fact.event173datelocal IS NULL AND fact.event3116date IS NULL AND fact.event8date IS NULL AND
                  fact.event1241date IS NULL THEN 'In_transit_leg0'::character varying
             ELSE 'arrived_@_PostNL'::character varying
             END                              AS processed_items
     FROM
         ttint_dm.fact_item_event_aggregated fact
             JOIN ttint_dm.dim_client client ON fact.dim_client_id = client.dim_client_id
             JOIN ttint_dm.dim_country cou ON fact.dim_country_id_destination = cou.dim_country_id
             JOIN ttint_dm.dim_manifest man ON fact.dim_manifest_id = man.dim_manifest_id
             JOIN ttint_dm.dim_product pro ON fact.dim_product_id = pro.dim_product_id
             JOIN ttint_dm.dim_mailbag bag ON fact.dim_mailbag_id = bag.dim_mailbag_id
     WHERE 0 = 0 AND fact.event1233date > date_add('day'::character varying::text, - 30::bigint, GETDATE())
       AND client.is_gateway::text = 'Y'::character varying::text
       AND cou.country_code::text = 'NL'::character varying::text) derived_table1
WHERE derived_table1.processed_items::text = 'In_transit_leg0'::character varying::text OR
        derived_table1.processed_items::text = 'arrived_@_PostNL'::character varying::text
GROUP BY
    derived_table1.processed_items, date(derived_table1.event1233date)
ORDER BY
    date(derived_table1.event1233date) DESC
WITH NO SCHEMA BINDING;

ALTER TABLE pnp_sop_in_transit_leg0
    OWNER TO ivotemmink;

