CREATE PROCEDURE sp_dim_trackingnumber_type(_var_init boolean)
    SECURITY DEFINER
    LANGUAGE plpgsql
AS
$$


DECLARE
   _REC_duplicates 			record;
   _VAR_inserts 			int8;
   --_VAR_last_update_ts      timestamp := (SELECT MAX(s3_partition_ts) FROM xbs.dim_trackingnumber_type);
BEGIN
	    --IF _VAR_init = TRUE THEN
		TRUNCATE TABLE xbs.dim_trackingnumber_type;
		RAISE WARNING 'WARNING: An Initiation has started and the table dim_trackingnumber_type has been TRUNCATED.';
	    --END IF;

INSERT INTO xbs.dim_trackingnumber_type
with tr_type as (
select
grouping_trackingnumber as trackingnumber
, grouping_aggregationleveltype as aggregationleveltype
, grouping_trackingnumbercreationtime_utc as trackingnumber_creationtime_utc
FROM
ingest_db.prep_xbs.grouping gr1

union

select
grouping_children_trackingnumber as trackingnumber
, grouping_children_aggregationleveltype as aggregationleveltype
, grouping_children_trackingnumbercreationtime_utc as trackingnumber_creationtime_utc
FROM
ingest_db.prep_xbs.grouping gr2

union

select
case when event_aggregationleveltype = 'Parcel' then event_trackingnumber
	 when event_scannedtrackingnumber is not null then event_scannedtrackingnumber
     else event_trackingnumber end as trackingnumber
, event_aggregationleveltype  as aggregationleveltype
, case when event_aggregationleveltype = 'Parcel' then event_trackingnumbercreationtime_utc
	 when event_scannedtrackingnumber is not null then event_scannedtrackingnumbercreationtime_utc
     else event_trackingnumbercreationtime_utc end as trackingnumber_creationtime_utc
FROM
ingest_db.cleanse_xbs.event_data ed

group by
trackingnumber
, aggregationleveltype
, trackingnumber_creationtime_utc
)

select
case when trackingnumber_creationtime_utc is null then FNV_HASH(trackingnumber || isnull(aggregationleveltype, '') || -1) else FNV_HASH(trackingnumber || isnull(aggregationleveltype, '') || trackingnumber_creationtime_utc) end as dim_trackingnumber_type_hid
, case when trackingnumber_creationtime_utc is null then FNV_HASH(trackingnumber || -1) else FNV_HASH(trackingnumber || trackingnumber_creationtime_utc) end as dim_trackingnumber_hid
, trackingnumber
, aggregationleveltype
, max(trackingnumber_creationtime_utc) as latest_trackingnumber_creationtime_utc
from tr_type
where aggregationleveltype is not null
group by
dim_trackingnumber_type_hid
, dim_trackingnumber_hid
, trackingnumber
, aggregationleveltype
, trackingnumber_creationtime_utc

;

     GET DIAGNOSTICS _VAR_inserts := ROW_COUNT;
     RAISE INFO 'Update completed: % rows inserted in xbs.dim_trackingnumber_type', _VAR_inserts;

--     CALL admin.sp_pk_check_table( PG_Last_Query_ID() );
--   		SELECT * INTO _REC_duplicates FROM #sp_pk_check_table;
--    	IF _REC_duplicates.dupes_amount > 0 THEN
--   		RAISE EXCEPTION 'Duplicates found'; RAISE INFO 'No duplicates found';
--    	END IF;
--
--    	EXCEPTION WHEN OTHERS THEN
--        	IF SQLERRM = 'Duplicates found' THEN
--         		RAISE EXCEPTION '% Duplicates found in total, for key values: %',_REC_duplicates.dupes_amount,_REC_duplicates.Duplicates_Check_PK;
--            ELSE RAISE EXCEPTION 'Error %, State %', SQLERRM, SQLSTATE;
--        	END IF;
--
END;


$$;

