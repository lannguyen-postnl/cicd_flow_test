CREATE OR REPLACE VIEW ips_staging.v_union_edi_l_recpt_and_recptevt AS
SELECT
    recpt_evt.recptcl_pid_hid
  , recpt_evt.recptcl_pid
  , COALESCE(recpt.recptcl_fid_hid, -1)                                AS recptcl_fid_hid
  , COALESCE(recpt.recptcl_fid, 'no_barcode')                          AS recptcl_fid
  , recpt.desptch_pid_hid
  , recpt.desptch_pid
  , recpt_evt.consgnt_pid
  , recpt_evt.contner_pid
  , recpt_evt.event_type_cd                                            AS dim_event_type_id
  , DATEADD('h', recpt_evt.event_local_offset, recpt_evt.event_gmt_dt) AS event_local_dt
  , recpt_evt.capture_gmt_dt
  , NULL                                                               AS carrier_event_code -- source of local does not contain carrier_event_code
  , 'l'::char(1)                                                       AS receptacle_event_source
  , recpt_evt.load_dt_utc
  , recpt_evt.s3_partition_ts
FROM
    ingest_db.prep_ips_nationals.l_recptcl_events recpt_evt
        LEFT JOIN ingest_db.cleanse_ips_nationals.l_recptcls recpt -- this table has been de-duplicated
                  ON recpt_evt.recptcl_pid_hid = recpt.recptcl_pid_hid
UNION
SELECT
    recpt_evt.recptcl_pid_hid
  , recpt_evt.recptcl_pid
  , COALESCE(fnv_hash(recpt.recptcl_fid), -1) AS recptcl_fid_hid
  , COALESCE(recpt.recptcl_fid, 'no_barcode') AS recptcl_fid
  , fnv_hash(recpt.desptch_pid)               AS desptch_pid_hid
  , recpt.desptch_pid
  , recpt.consgnt_pid
  , NULL                                      AS contner_pid -- source of n_edi does not contain contner_pid
  , recpt_evt.event_type_cd                   AS dim_event_type_id
  , recpt_evt.event_lcl_dt                    AS event_local_dt
  , recpt_evt.capture_gmt_dt
  , recpt_evt.carrier_event_cd                AS carrier_event_code
  , 'e'::char(1)                              AS receptacle_event_source
  , recpt_evt.load_dt_utc
  , recpt_evt.s3_partition_ts
FROM
    ingest_db.prep_ips_nationals.n_edi_recptcl_events recpt_evt
        LEFT JOIN ingest_db.cleanse_ips_nationals.n_edi_recptcls recpt -- this table has been de-duplicated
                  ON recpt_evt.recptcl_pid_hid = recpt.recptcl_pid_hid
WITH NO SCHEMA BINDING;

ALTER TABLE v_union_edi_l_recpt_and_recptevt
    OWNER TO lannguyen;

GRANT DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE ON v_union_edi_l_recpt_and_recptevt TO GROUP analyst;

