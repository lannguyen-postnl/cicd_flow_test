CREATE PROCEDURE sp_imec108(_var_init boolean)
    SECURITY DEFINER
    LANGUAGE plpgsql
AS
$$
DECLARE
   _REC_duplicates 			record;
   _VAR_inserts 			int8;
BEGIN
	IF _VAR_init = TRUE THEN	
		TRUNCATE TABLE ips.imec108;
		RAISE WARNING 'WARNING: An Initiation has started and the table ips.imec108 has been TRUNCATED.';
	END IF;
	
	-- delete newly found records from imec108
	DELETE FROM ips.imec108
	WHERE "item_id" IN (SELECT "item_id" FROM ips_staging.imec_108_staging);
	
	-- insert new found records from staging into imec108
	INSERT INTO ips.imec108
	SELECT * FROM ips_staging.imec_108_staging;

	GET DIAGNOSTICS _VAR_inserts := ROW_COUNT;
     RAISE INFO 'ips.imec108 update completed: % rows inserted.', _VAR_inserts;

--	CALL ct.sp_pk_check_table( PG_Last_Query_ID() ); 
--   	SELECT * INTO _REC_duplicates FROM #sp_pk_check_table;
--   	IF _REC_duplicates.dupes_amount > 0 THEN
--   		RAISE EXCEPTION 'Duplicates found'; RAISE INFO 'No duplicates found';
--   	END IF;
--   
--    	EXCEPTION WHEN OTHERS THEN
-- 	 IF SQLERRM = 'Duplicates found' THEN 
--         	RAISE EXCEPTION '% Duplicates found in total, for key values: %', _REC_duplicates.dupes_amount, _REC_duplicates.Duplicates_Check_PK;
--      ELSE 
--     	RAISE EXCEPTION 'Error %, State %', SQLERRM, SQLSTATE;
--      END IF;
     
--     CREATE TABLE IF NOT EXISTS ips.imec108(
--				item_id NOT NULL				varchar(64)
--			,	local_item_id					varchar(64)
--			,	letter_filter					varchar(64)
--			,	receptacle_id					varchar(30)
--			,	service_level					varchar(1)
--			,	item_weight					float8
--			,	item_state_indicator			varchar(64)
--			,	item_postal_state				varchar(10)
--			,	origin_oe						varchar(30)
--			,	destination_oe					varchar(24)
--			,	is_eu						bool
--			,	origin_country					varchar(64)
--			,	ema_scan						timestamp
--			,	exb_scan						timestamp
--			,	exc_scan						timestamp
--			,	exd_scan						timestamp
--			,	exx_scan						timestamp
--			,	emc_scan						timestamp
--			,	close_despatch_abroad			timestamp
--			,	close_consignment_abroad			timestamp
--			,	planned_arrival_by_predes		timestamp
--			,	planned_arrival_by_precon		timestamp
--			,	mrdpod						timestamp
--			,	resdit_21						timestamp
--			,	rescon						timestamp
--			,	resdes						timestamp
--			,	emd_scan						timestamp
--			,	processing_oe					char(6)
--			,	eda_scan						timestamp
--			,	eda_retention_code				int4
--			,	edb_scan						timestamp
--			,	edb_retention_code				int4
--			,	eme_scan						timestamp
--			,	eme_retention_code				int4
--			,	edc_scan						timestamp
--			,	emf_scan						timestamp
--			,	edd_scan						timestamp
--			,	ede_scan						timestamp
--			,	emg_scan						timestamp
--			,	edf_scan						timestamp
--			,	edf_non_delivery_reason_code		varchar(12)
--			,	edg_scan						timestamp
--			,	edh_scan						timestamp
--			,	edh_delivery_type_code			varchar(12)
--			,	edx_scan						timestamp
--			,	edx_non_delivery_reason_code		varchar(12)
--			,	emh_scan						timestamp
--			,	emh_non_delivery_reason_code		int4
--			,	emi_scan						timestamp
--			,	start_the_clock				date
--			,	start_the_clock_event			varchar(12)
--			,	customs_in					date
--			,	customs_out					date
--			,	customs_time					int8
--			,	stop_the_clock					date
--			,	transit_time					int8
--			,	on_time						varchar(3)
--			,	last_update_utc				timestamp
--			,	PRIMARY KEY (item_id)
--		);
END; 
$$;

