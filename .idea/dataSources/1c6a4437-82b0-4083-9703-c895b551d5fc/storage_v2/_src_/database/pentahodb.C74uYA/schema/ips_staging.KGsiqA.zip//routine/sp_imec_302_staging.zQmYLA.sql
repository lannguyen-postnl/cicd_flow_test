CREATE PROCEDURE sp_imec_302_staging(last_update_utc timestamp without time zone, end_ts_utc timestamp without time zone)
    LANGUAGE plpgsql
AS
$$

/**********************************************************************************************************************
  *
  * Purpose/Description     : This stored procedure updates its target staging table in which contains calculations of
                                different tracked EMSEVT events. This target staging table is on item level, which includes
                                foreign keys (e.g. receptacle_id, dispatch_id) and the items' relevent EMSEVT events. This imec_302_staging
                                table is used to update and insert into the ips.imec302 table later in the pipeline.
  * Documentation reference : https://postnl.atlassian.net/wiki/spaces/CB/pages/3674866047/IMEC+202+302
  * Input expected          : the input variable is given from the Pentaho ETL pipeline: IPS_EXPORT_MAIN>EXPORT_REPORTING>IMEC302_AND_202>'set variable' module
                                and are used to fetch the events in ips_dm.fact_mailitem_event
                                * last_update_utc timestamp
                                * end_ts_utc timestamp
  * Output expected         : Inserts into target tables
                                * ips_staging.imec_302_staging
  * Procedure called from   : Pentaho ETL pipeline: IPS_EXPORT_MAIN>EXPORT_REPORTING>IMEC302_AND_202>IMEC302_STAGING_NEW_FLOW
  * Procedure calls         : n/a
  *
**********************************************************************************************************************/
DECLARE
    _var_current_ts      varchar := getdate();
    _var_inserts         int     := 0;
    _end_ts                      varchar:= (select case when end_ts_utc is null then getdate() else end_ts_utc end as end_ts);
BEGIN
    TRUNCATE ips_staging.imec_302_staging;
    RAISE INFO '% - Truncated table ips_staging.imec_302_staging for initial load', _var_current_ts;

    DROP TABLE IF EXISTS #staging;
    CREATE TABLE #staging (like ips_staging.imec_302_staging);
    ALTER TABLE #staging ADD COLUMN hashed_key int8;

    _var_current_ts := getdate();
    raise info '% - before first insert', _var_current_ts;
	--insert statements into staging table
	INSERT INTO #staging
    WITH first_receptacle_code AS (SELECT
                                           me.dim_mailitem_id
                                         , me.dim_receptacle_id
                                         , r.receptacle_code
                                         , SUBSTRING(r.receptacle_code, 1, 2)  AS first_2_char_receptacle_code
                                         , SUBSTRING(r.receptacle_code, 1, 6)  AS first_6_char_receptacle_code
                                         , r.origin_impc_code
                                         , r.dim_consignment_id
                                         , r.dim_dispatch_id
                                       FROM
                                           ips_dm.fact_mailitem_event me
                                               LEFT JOIN ips_dm.v_receptacle_fids r ON me.dim_receptacle_id = r.dim_receptacle_id
                                       WHERE 1 = 1
                                         AND me.load_dt_utc >= dateadd(day, -100, last_update_utc)
                                         AND me.load_dt_utc <= _end_ts
                                         AND me.dim_event_type_id = 8
                                         AND (first_2_char_receptacle_code = 'NL'
                                           OR r.receptacle_code IS NULL
                                           OR first_6_char_receptacle_code IN ('ATWNFA', 'ATWNFZ'
                                                                                , 'AUMASC', 'BEBRUZ'
                                                                                , 'BELGGG', 'CHAARZ'
                                                                                , 'DEPULZ', 'DEDARZ'
                                                                                , 'DEFRAY', 'DEFRAZ'
                                                                                , 'ESCXQZ', 'FRROIY'
                                                                                , 'GBSLLU', 'GBBASI'
                                                                                , 'GBBASR', 'GBSLLV'
                                                                                , 'GBSLLY', 'GBSLLX'
                                                                                , 'GBSLLZ', 'IEDUBF'
                                                                                , 'ITMUCZ', 'SESTOF'
                                                                                , 'SGSINR', 'USCHIZ'
                                                                                , 'USITSY', 'USLTDY'
                                                                                , 'USMIAG', 'USRDOY'
                                                                                , 'USSBKX', 'USUAKZ'
                                                                                , 'USXFRX')
                                             )
                                       GROUP BY me.dim_mailitem_id
                                              , me.dim_receptacle_id
                                              , r.receptacle_code
                                              , r.origin_impc_code
                                              , r.dim_consignment_id
                                              , r.dim_dispatch_id
                                              , me.event_local_datetime
                                       QUALIFY
                                            ROW_NUMBER() OVER (PARTITION BY me.dim_mailitem_id ORDER BY r.receptacle_code asc, me.event_local_datetime asc) = 1 )
      , tracked_mailitem_events AS (SELECT DISTINCT
                   dim_mailitem_id
                   , load_dt_utc AS s3_partition_ts_itm_evt
               FROM
                   ips_dm.fact_mailitem_event me
               INNER JOIN ips_staging.config_ips_export_302_staging config on me.dim_event_type_id = config.dim_event_type_id
               WHERE 1 = 1
                 AND load_dt_utc >= last_update_utc
                 AND load_dt_utc <= _end_ts
               QUALIFY 
                row_number() OVER (PARTITION BY dim_mailitem_id, load_dt_utc ORDER BY load_dt_utc desc)=1 )
      , deduplicated_dim_mail_item as (SELECT
                                          dim_mailitem_id
                                            ,mailitem_code
                                            ,mailitem_local_code
                                            ,mailitem_weight
                                            ,postal_status_code
                                            ,destination_country_code
                                      FROM ips_dm.dim_mailitem
                                      WHERE 1=1
                                      QUALIFY
                                        row_number() OVER (PARTITION BY dim_mailitem_id, dim_receptacle_id ORDER BY load_dt_utc desc)=1 )
      , delta_base AS (SELECT
                           m.dim_mailitem_id
                         , m.mailitem_code
                         , m.mailitem_local_code
                         , m.mailitem_weight
                         , m.postal_status_code
                         , m.destination_country_code
                         , first_receptacle_code.dim_receptacle_id
                         , first_receptacle_code.receptacle_code
                         , first_receptacle_code.origin_impc_code
                         , first_receptacle_code.dim_dispatch_id
                         , first_receptacle_code.dim_consignment_id
                         , tracked_mailitem_events.s3_partition_ts_itm_evt
                         , fnv_hash(m.mailitem_code) AS redshifthashed_dim_mailitem_id
                       FROM
                           deduplicated_dim_mail_item m
                               INNER JOIN tracked_mailitem_events
                                         ON m.dim_mailitem_id = tracked_mailitem_events.dim_mailitem_id
                               LEFT JOIN first_receptacle_code
                                         ON m.dim_mailitem_id = first_receptacle_code.dim_mailitem_id )
    SELECT
        delta_base.mailitem_code            AS "item_id"
      , delta_base.mailitem_local_code      AS "local_item_id"
      , d.dispatch_code                     AS "despatch_id"
      , delta_base.receptacle_code          AS "receptacle_id"
      , delta_base.mailitem_weight          AS "item_weight"
      , delta_base.postal_status_code       AS "item_state"
      , piv_302."ema_type_posting/collection"
      , piv_302.ema_origin_system
      , piv_302.emb_item_at_ooe
      , piv_302.emc_item_in_bag
      , delta_base.origin_impc_code                  AS emc_scan_office
      , piv_302.emd_recv_at_location_ab
      , piv_302.retention_code
      , piv_302.edb_presented_to_customs
      , piv_302.eme_to_customs
      , piv_302.edc_from_customs
      , piv_302.emf_sorteermelding
      , piv_302.edd_receive_so
      , piv_302.ede_send_from_so
      , piv_302.emg_item_at_do_abroad
      , piv_302.edg_send_for_delivery
      , piv_302.edh_receive_collection_point
      , piv_302.emh_del_attempt
      , piv_302.emi_delivery
      , c.consignment_code                  AS "consignment_id"
      , piv_302.edx_non_delivery
      , delta_base.destination_country_code AS "destination_country_item"
      , piv_302.eda_hold_item_at_ooe
      , delta_base.s3_partition_ts_itm_evt
      , fnv_hash(item_id,fnv_hash(local_item_id,fnv_hash(despatch_id,fnv_hash(receptacle_id,fnv_hash(consignment_id))))) as hashed_key
    FROM
        delta_base
            LEFT JOIN ips_dm.dim_consignment c ON c.dim_consignment_id = delta_base.dim_consignment_id
            LEFT JOIN ips_dm.dim_dispatch d ON d.dim_dispatch_id = delta_base.dim_dispatch_id

            --replacement of the 23 LEFT JOINS
            LEFT JOIN ips_staging.pivot_earliest_ems_302 as piv_302 ON piv_302.redshifthashed_dim_mailitem_id = delta_base.redshifthashed_dim_mailitem_id
    ;

    _var_current_ts := getdate();
    raise info '% - before second insert', _var_current_ts;
    --insert into target table the most aggregated rows to avoid duplication caused by row explosion
	INSERT INTO ips_staging.imec_302_staging
    SELECT
        item_id
      , local_item_id
      , despatch_id
      , receptacle_id
      , CAST(AVG(CASE WHEN item_weight = 0 THEN NULL ELSE item_weight END) AS DECIMAL(10, 2)) AS item_weight
      , LISTAGG(DISTINCT item_state, ' ')                                                     AS item_state
      , MIN("ema_type_posting/collection")                                                    AS "ema_type_posting/collection"
      , MIN(ema_origin_system)                                                                AS ema_origin_system
      , MIN(emb_item_at_ooe)                                                                  AS emb_item_at_ooe
      , MIN(emc_item_in_bag)                                                                  AS emc_item_in_bag
      , MIN(emc_scan_office)                                                                  AS emc_scan_office
      , MIN(emd_recv_at_location_ab)                                                          AS emd_recv_at_location_ab
      , MIN(retention_code)                                                                   AS retention_code
      , MIN(edb_presented_to_customs)                                                         AS edb_presented_to_customs
      , MIN(eme_to_customs)                                                                   AS eme_to_customs
      , MIN(edc_from_customs)                                                                 AS edc_from_customs
      , MIN(emf_sorteermelding)                                                               AS emf_sorteermelding
      , MIN(edd_receive_so)                                                                   AS edd_receive_so
      , MIN(ede_send_from_so)                                                                 AS ede_send_from_so
      , MIN(emg_item_at_do_abroad)                                                            AS emg_item_at_do_abroad
      , MIN(edg_send_for_delivery)                                                            AS edg_send_for_delivery
      , MIN(edh_receive_collection_point)                                                     AS edh_receive_collection_point
      , MIN(emh_del_attempt)                                                                  AS emh_del_attempt
      , MIN(emi_delivery)                                                                     AS emi_delivery
      , consignment_id
      , MIN(edx_non_delivery)                                                                 AS edx_non_delivery
      , MIN(destination_country_item)                                                         AS destination_country_item
      , MIN(eda_hold_item_at_ooe)                                                             AS eda_hold_item_at_ooe
      , s3_partition_ts_itm_evt
    FROM
        #staging
    GROUP BY item_id
      , local_item_id
      , despatch_id
      , receptacle_id
      , consignment_id
      , s3_partition_ts_itm_evt
    ;
    GET DIAGNOSTICS _VAR_inserts := ROW_COUNT; RAISE INFO '% rows inserted into ips_staging.imec_302_staging', _VAR_inserts;
    _var_current_ts := getdate();
    raise info '% - after second insert', _var_current_ts;

END;

$$;

