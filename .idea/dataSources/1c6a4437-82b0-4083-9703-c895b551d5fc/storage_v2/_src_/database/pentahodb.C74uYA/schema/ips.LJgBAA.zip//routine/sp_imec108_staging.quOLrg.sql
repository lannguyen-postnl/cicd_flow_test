CREATE PROCEDURE sp_imec108_staging(_var_init boolean)
    SECURITY DEFINER
    LANGUAGE plpgsql
AS
$$
	
	
	
	
	
DECLARE
   _VAR_inserts 			int8;
   _VAR_last_update_ts_utc 	timestamp := (DATEADD(hour,-2,(SELECT MAX(last_update_utc) FROM ips.imec108))); --changed INTERVAL TO two hours back TO make sure ALL events ARE included correctly.
   _VAR_end_ts_utc 			timestamp := GETDATE();
   _VAR_init_ts_utc			timestamp := CAST('2021-06-01' AS timestamp);
BEGIN
	------------------------------------------------------------------------------------------------------------------
	--	Routine:		ips.sp_imec108_staging(_VAR_init IN bool)
	--
	--	Version:		1.0
	--
	--	Description:	This procedure creates the staging table for imec108
	--
	--	Changelog:
	--		29-04-2022	Tim van Polen	:	Version 1.0	:	Initial creation
	------------------------------------------------------------------------------------------------------------------
	
	-- drop to be used temptables
	DROP TABLE IF EXISTS #temp_icp;
	DROP TABLE IF EXISTS #pivot_temp_table;
	DROP TABLE IF EXISTS #pivot_table;

	-------------------------------------------------------------------------------
	-- STEP 01 - BASE TABLE
	-------------------------------------------------------------------------------
	
	-- selection for the base table of the calculation for the imec108_staging table
	-- for init = 0 select last set based on v_last_update_ts_utc 
	-- for init = 1 select set based on last_update_date = '2021-06-01'
	WITH cte_mailitemcode_selection AS (
		SELECT 	m.mailitem_code
		FROM		ips_dm.dim_mailitem 		AS m
		LEFT JOIN ips_dm.fact_mailitem_event 	AS me 	ON 	me.dim_mailitem_id 		= 	m.dim_mailitem_id		AND me.dim_event_type_id IN 
		(1, 6, 7, 8, 13, 15, 30, 31, 32, 34, 36, 37, 38, 42, 43, 44, 69, 70, 71, 72
		, 73, 74, 75, 76, 1102, 1200, 1203, 1204, 1206, 1207, 1211, 1230, 1234, 1235, 1243, 1247, 1253, 1254, 1255, 1260, 1261, 1264)
		LEFT JOIN ips_dm.dim_receptacle 		AS r 	ON 	r.dim_receptacle_id 	= 	m.dim_receptacle_id
		WHERE
			(
				(
					-- For initialisation the starting value of me.load_dt_utc needs to be 2021-06-01
					_VAR_init = TRUE
					AND me.load_dt_utc >= _VAR_init_ts_utc	
					AND me.event_local_datetime > dateadd(month, -12, _VAR_init_ts_utc) --to limit set but also if barcode is reused this should not happen within six months
				)
				OR (
					_VAR_init = FALSE
					AND me.load_dt_utc >= _VAR_last_update_ts_utc
				)
			)
			AND me.load_dt_utc <= _VAR_end_ts_utc
			AND SUBSTRING(r.receptacle_code, 14, 2) IN ('EY', 'CX')
			AND SUBSTRING(m.mailitem_code, 12, 2) != 'NL' --to filter only items with origin not NL
			AND m.destination_country_code = 'NL' --to filter only items with destination NL
			AND	(	m.postal_status_code != 'MIRT'
				OR 	m.postal_status_code IS NULL
				) --to filter returned items
		GROUP BY 	m.mailitem_code
	)
	SELECT 	  m.dim_mailitem_id
			, m.origin_country_code 
			, m.mailitem_code
			, m.mailitem_local_code
			, m.mailitem_weight
			, m.state_indicator_name
			, m.postal_status_code
			, r.dim_receptacle_id
			, r.receptacle_code
			, r.dim_dispatch_id
			, r.origin_impc_code
			, re.dim_event_type_id		AS re_dim_event_type_id	
			, re.event_local_datetime	AS re_event_local_datetime
			, d.dispatch_code
			, de.dim_event_type_id		AS de_dim_event_type_id
			, de.event_local_datetime   	AS de_event_local_datetime
			, r.dim_consignment_id
			, c.consignment_code
			, ce.dim_event_type_id		AS ce_dim_event_type_id
			, ce.event_local_datetime	AS ce_event_local_datetime
			, me.dim_own_office_id 
			, me.dim_event_type_id		AS me_dim_event_type_id
			, me.event_local_datetime	AS me_event_local_datetime
			, me.retention_reason_code
			, me.non_delivery_reason_code
			, me.non_delivery_measure_code
			, me.delivery_type_code
			, re.carrier_event_code
			, ia.event_date
			, me.load_dt_utc
	INTO #temp_icp
	FROM ips_dm.dim_mailitem 				AS m
		LEFT JOIN cte_mailitemcode_selection	AS cms 	ON 	cms.mailitem_code		=	m.mailitem_code 
		LEFT JOIN ips_dm.fact_mailitem_event 	AS me 	ON 	me.dim_mailitem_id 		= 	m.dim_mailitem_id		AND me.dim_event_type_id IN
(1, 6, 7, 8, 13, 15, 30, 31, 32, 34, 36, 37, 38, 42, 43, 44, 69, 70, 71, 72
		, 73, 74, 75, 76, 1102, 1200, 1203, 1204, 1206, 1207, 1211, 1230, 1234, 1235, 1243, 1247, 1253, 1254, 1255, 1260, 1261, 1264)
		LEFT JOIN ips_dm.dim_receptacle 		AS r 	ON 	r.dim_receptacle_id 	= 	m.dim_receptacle_id
		LEFT JOIN ips_dm.fact_receptacle_event 	AS re 	ON 	re.dim_receptacle_id 	= 	r.dim_receptacle_id 	AND re.dim_event_type_id IN (130, 131, 133, 161)
		LEFT JOIN ips_dm.dim_dispatch 		AS d 	ON 	d.dim_dispatch_id 		= 	r.dim_dispatch_id
		LEFT JOIN ips_dm.fact_dispatch_event 	AS de 	ON 	de.dim_dispatch_id 		= 	d.dim_dispatch_id 		AND de.dim_event_type_id IN (201, 204)
		LEFT JOIN ips_dm.dim_consignment 		AS c 	ON 	c.dim_consignment_id 	= 	r.dim_consignment_id
		LEFT JOIN ips_dm.fact_consignment_event AS ce 	ON 	ce.dim_consignment_id 	= 	c.dim_consignment_id 	AND ce.dim_event_type_id IN (301, 303)
		LEFT JOIN ipc.ipc_archive 			AS ia 	ON 	ia.rcpt_id 			= 	r.receptacle_code 		AND ia.event_type 		 = 	'POD'
	WHERE 1 = 1
--		(
--			(
--				-- For initialisation the starting value of me.load_dt_utc needs to be 2021-06-01
--				_VAR_init = TRUE
--				AND me.load_dt_utc >= _VAR_init_ts_utc	
--				AND me.event_local_datetime > dateadd(month, -6, getdate()) --to limit set but also if barcode is reused this should not happen within six months
--			)
--			OR (
--				_VAR_init = FALSE
--				AND me.load_dt_utc >= _VAR_last_update_ts_utc
--			)
--		)
		AND cms.mailitem_code IS NOT NULL
		AND me.load_dt_utc <= _VAR_end_ts_utc
		AND SUBSTRING(r.receptacle_code, 14, 2) IN ('EY', 'CX')
		AND SUBSTRING(m.mailitem_code, 12, 2) != 'NL' --to filter only items with origin not NL
		AND m.destination_country_code = 'NL' --to filter only items with destination NL
		AND	(	m.postal_status_code != 'MIRT'
			OR 	m.postal_status_code IS NULL
			) --to filter returned items
	GROUP BY  m.dim_mailitem_id
			, m.origin_country_code 
			, m.mailitem_code
			, m.mailitem_local_code
			, m.mailitem_weight
			, m.state_indicator_name
			, m.postal_status_code
			, r.dim_receptacle_id
			, r.receptacle_code
			, r.dim_dispatch_id
			, r.origin_impc_code 
			, re.dim_event_type_id
			, re.event_local_datetime
			, d.dispatch_code
			, de.dim_event_type_id
			, de.event_local_datetime
			, r.dim_consignment_id
			, c.consignment_code
			, ce.dim_event_type_id
			, ce.event_local_datetime
			, me.dim_own_office_id 
			, me.dim_event_type_id
			, me.event_local_datetime
			, me.retention_reason_code
			, me.non_delivery_reason_code
			, me.non_delivery_measure_code
			, me.delivery_type_code
			, re.carrier_event_code
			, ia.event_date
			, me.load_dt_utc
	ORDER BY  m.dim_mailitem_id
			, m.origin_country_code
			, m.mailitem_code
			, m.mailitem_local_code
			, m.mailitem_weight
			, m.state_indicator_name
			, m.postal_status_code
			, r.dim_receptacle_id
			, r.receptacle_code
			, r.dim_dispatch_id
			, r.origin_impc_code
			, re.dim_event_type_id
			, re.event_local_datetime
			, d.dispatch_code
			, de.dim_event_type_id
			, de.event_local_datetime
			, r.dim_consignment_id
			, c.consignment_code
			, ce.dim_event_type_id
			, ce.event_local_datetime
			, me.dim_own_office_id 
			, me.dim_event_type_id
			, me.event_local_datetime
			, me.retention_reason_code
			, me.non_delivery_reason_code
			, me.non_delivery_measure_code
			, me.delivery_type_code
			, re.carrier_event_code
			, ia.event_date
			, me.load_dt_utc;
	
	-------------------------------------------------------------------------------
	-- STEP 02 - PIVOT TEMP TABLE
	-------------------------------------------------------------------------------
    WITH cte_country AS (
    	SELECT  ti.mailitem_code 
        ,    CASE    WHEN ti.origin_impc_code IN     ('BEBRUG', 'DEFRAB', 'EETLLJ', 'NLSRKY', 'NLSRKZ', 'ESMADD', 'ESBCND', 'HUBUDC', 'EELOOY', 'LTVNOB', 'NLHFDY', 'SEMMAH', 'SEMMAQ') THEN FALSE
                    WHEN ti.origin_impc_code IN     ('GBCVTN') THEN TRUE --exception for volume going via Northern_Ireland
                    WHEN ti.origin_impc_code NOT IN ('BEBRUG', 'DEFRAB', 'EETLLJ', 'NLSRKY', 'NLSRKZ', 'ESMADD', 'ESBCND', 'HUBUDC', 'EELOOY', 'LTVNOB', 'NLHFDY', 'SEMMAH', 'SEMMAQ') THEN
                        CASE WHEN cou.is_eu = FALSE THEN FALSE
                             WHEN cou.is_eu != FALSE AND cou.is_eu IS NOT NULL THEN TRUE
                             ELSE NULL END
                    END AS is_eu
		, ti.origin_impc_code
		, cou.country_combo 								AS origin_country
		, cou.country_code_bk 								AS country_code
	FROM #temp_icp AS ti
	LEFT JOIN mdm.dim_country AS cou ON cou.country_code_bk = LEFT(ti.receptacle_code,2)
	GROUP BY ti.mailitem_code, ti.origin_impc_code, origin_country, country_code, cou.is_eu
    )
	-- create first pivot selection with simple events
	SELECT 	  ti.mailitem_code 																	AS item_id
			, ti.mailitem_local_code 															AS local_item_id
			, LEFT(ti.mailitem_code,1) 															AS letter_filter
			, ti.receptacle_code 																AS receptacle_id
			, ti.mailitem_weight 																AS item_weight
			, ti.state_indicator_name 															AS item_state_indicator
			, ti.postal_status_code 																AS item_postal_state
			, LEFT(ti.receptacle_code,6) 															AS origin_oe
			, SUBSTRING(ti.receptacle_code,7,6) 													AS destination_oe
			, MIN(CASE WHEN ti.me_dim_event_type_id = 1 THEN me_event_local_datetime END) 					AS ema_scan
			, MIN(CASE WHEN ti.me_dim_event_type_id = 6 THEN me_event_local_datetime END) 					AS exb_scan
			, MIN(CASE WHEN ti.me_dim_event_type_id = 7 THEN me_event_local_datetime END) 					AS exc_scan
			, MIN(CASE WHEN ti.me_dim_event_type_id = 69 THEN me_event_local_datetime END) 					AS exd_scan
			, MIN(CASE WHEN ti.me_dim_event_type_id = 15 THEN me_event_local_datetime END) 					AS exx_scan
			, MIN(CASE WHEN ti.me_dim_event_type_id = 8 THEN me_event_local_datetime END) 					AS emc_scan
			, MIN(CASE WHEN ti.de_dim_event_type_id = 201 THEN de_event_local_datetime END) 				AS close_despatch_abroad
			, MIN(CASE WHEN ti.ce_dim_event_type_id = 301 THEN ce_event_local_datetime END) 				AS close_consignment_abroad
			, MIN(CASE WHEN ti.de_dim_event_type_id = 204 THEN de_event_local_datetime END) 				AS planned_arrival_by_predes
			, MIN(CASE WHEN ti.ce_dim_event_type_id = 303 THEN ce_event_local_datetime END) 				AS planned_arrival_by_precon
			, CAST(MIN(ti.event_date) AS timestamp) 												AS mrdpod --NOTE (excluded the event_type = POD as this was included in the base statement)
			, MIN(CASE WHEN ti.re_dim_event_type_id = 161 AND ti.carrier_event_code = 21 THEN re_event_local_datetime END) 	AS resdit_21
			, MIN(CASE WHEN ti.re_dim_event_type_id = 130 THEN re_event_local_datetime END) 				AS rescon
			, MIN(CASE WHEN ti.re_dim_event_type_id IN (131, 133) THEN re_event_local_datetime END) 			AS resdes
			, MIN(CASE WHEN ti.me_dim_event_type_id IN (13, 38, 1203, 1234, 1235, 1243, 1253, 1264) THEN me_event_local_datetime END) AS edc_scan
			, MIN(CASE WHEN ti.me_dim_event_type_id IN (1211) THEN me_event_local_datetime END) 			AS emf_scan
			, MIN(CASE WHEN ti.me_dim_event_type_id = 71 THEN me_event_local_datetime END) 					AS edd_scan
			, MIN(CASE WHEN ti.me_dim_event_type_id = 72 THEN me_event_local_datetime END) 					AS ede_scan
			, MIN(CASE WHEN ti.me_dim_event_type_id = 32 THEN me_event_local_datetime END) 					AS emg_scan
			, MIN(CASE WHEN ti.me_dim_event_type_id = 74 THEN me_event_local_datetime END) 					AS edg_scan
			, MIN(CASE WHEN ti.me_dim_event_type_id IN (37, 1261)  THEN me_event_local_datetime END) 			AS emi_scan		
			, MIN(CASE WHEN ti.me_dim_event_type_id = 108  THEN me_event_local_datetime END) 				AS precon_scan			
			, cc.is_eu
			, cc.origin_country
			, cc.country_code
			, _VAR_end_ts_utc 																	AS last_update_utc
	INTO #pivot_temp_table
	FROM #temp_icp AS ti
		LEFT JOIN cte_country cc ON cc.mailitem_code = ti.mailitem_code
	GROUP BY  ti.mailitem_code
			, ti.mailitem_local_code
			, LEFT(ti.mailitem_code,1)
			, ti.receptacle_code
			, ti.mailitem_weight
			, ti.state_indicator_name
			, ti.postal_status_code
			, LEFT(ti.receptacle_code,6)
			, SUBSTRING(ti.receptacle_code,7,6)
			, cc.is_eu
			, cc.origin_country
			, cc.country_code
	ORDER BY  ti.mailitem_code
			, ti.mailitem_local_code
			, LEFT(ti.mailitem_code,1)
			, ti.receptacle_code
			, ti.mailitem_weight
			, ti.state_indicator_name
			, ti.postal_status_code
			, LEFT(ti.receptacle_code,6)
			, SUBSTRING(ti.receptacle_code,7,6)
			, cc.is_eu
			, cc.origin_country
			, cc.country_code;
		
	-------------------------------------------------------------------------------
	-- STEP 03 - PIVOT TABLE
	-------------------------------------------------------------------------------
		
	-- each cte stands for a certain scan and its datetime and coupled fields
	WITH cte_emd_scan AS (
		SELECT 	mailitem_code
			,	me_event_local_datetime  AS emd_scan
			,	doo.office_code  		AS processing_oe
		FROM (
			SELECT 	mailitem_code
				, 	me_event_local_datetime
				,	dim_own_office_id
				,   row_number() OVER (PARTITION BY mailitem_code ORDER BY me_event_local_datetime asc) AS ROW
			FROM #temp_icp
			WHERE me_dim_event_type_id IN (30, 42, 43, 44)
		) rp
		LEFT JOIN ips_dm.dim_own_office doo
		ON rp.dim_own_office_id = doo.dim_own_office_id
		WHERE ROW = 1
		ORDER BY mailitem_code
	), cte_eda_scan as (
		SELECT 	mailitem_code
			,	me_event_local_datetime AS eda_scan
			,	retention_reason_code 	AS eda_retention_code
		FROM (
			SELECT 	mailitem_code
				, 	me_event_local_datetime
				,	retention_reason_code
				,   row_number() OVER (PARTITION BY mailitem_code ORDER BY me_event_local_datetime asc) AS ROW
			FROM #temp_icp
			WHERE me_dim_event_type_id IN (70)
		) rp
		WHERE ROW = 1
		ORDER BY mailitem_code
	), cte_edb_scan as (
		SELECT 	mailitem_code
			,	me_event_local_datetime AS edb_scan
			,	retention_reason_code 	AS edb_retention_code
		FROM (
			SELECT 	mailitem_code
				, 	me_event_local_datetime
				,	retention_reason_code
				,   row_number() OVER (PARTITION BY mailitem_code ORDER BY me_event_local_datetime asc) AS ROW
			FROM #temp_icp
			WHERE me_dim_event_type_id IN (31, 1200)
		) rp
		WHERE ROW = 1
		ORDER BY mailitem_code
	), cte_eme_scan as (
		SELECT 	mailitem_code
			,	me_event_local_datetime AS eme_scan
			,	retention_reason_code 	AS eme_retention_code
		FROM (
			SELECT 	mailitem_code
				, 	me_event_local_datetime
				,	retention_reason_code
				,   row_number() OVER (PARTITION BY mailitem_code ORDER BY me_event_local_datetime asc) AS ROW
			FROM #temp_icp
			WHERE 	me_dim_event_type_id IN (34, 1102, 1206, 1207)
			AND 	retention_reason_code IN (19, 20, 21, 50, 52, 54, 57, 58, 62, 63, 64, 73)
		) rp
		WHERE ROW = 1
		ORDER BY mailitem_code
	), cte_edf_scan as (
		SELECT 	mailitem_code
			,	me_event_local_datetime 	 AS edf_scan
			,	edf_non_delivery_reason_code AS edf_non_delivery_reason_code
		FROM (
			SELECT 	mailitem_code
				, 	me_event_local_datetime
				,	non_delivery_measure_code || non_delivery_reason_code AS edf_non_delivery_reason_code
				,   row_number() OVER (PARTITION BY mailitem_code ORDER BY me_event_local_datetime asc) AS ROW
			FROM #temp_icp
			WHERE 	me_dim_event_type_id IN (73, 1254, 1255)
			AND 	non_delivery_measure_code || non_delivery_reason_code IN ('A10', 'A12', 'A18', 'A24', 'B10', 'B12', 'B14', 'B24', 'B59', 'C10', 'C12', 'C18', 'C21', 'C24', 'C29', 'C45', 'C50', 'C59', 'F10', 'F28', 'F29', 'F58', 'F59', 'G18', 'I10', 'I18', 'I50', 'I53', 'M10', 'M28', 'M29', 'N18', 'O10', 'O12', 'O21', 'O24', 'O28', 'O45', 'O59')
		) rp
		WHERE ROW = 1
		ORDER BY mailitem_code
	), cte_edh_scan as (
		SELECT 	mailitem_code
			,	me_event_local_datetime AS edh_scan
			,	delivery_type_code 		AS edh_delivery_type_code
		FROM (
			SELECT 	mailitem_code
				, 	me_event_local_datetime
				,	delivery_type_code
				,   row_number() OVER (PARTITION BY mailitem_code ORDER BY me_event_local_datetime asc) AS ROW
			FROM #temp_icp
			WHERE me_dim_event_type_id IN (74,75)
		) rp
		WHERE ROW = 1
		ORDER BY mailitem_code
	), cte_edx_scan as (
		SELECT 	mailitem_code
			,	me_event_local_datetime 	 AS edx_scan
			,	edx_non_delivery_reason_code AS edx_non_delivery_reason_code
		FROM (
			SELECT 	mailitem_code
				, 	me_event_local_datetime
				,	non_delivery_measure_code || non_delivery_reason_code AS edx_non_delivery_reason_code
				,   row_number() OVER (PARTITION BY mailitem_code ORDER BY me_event_local_datetime asc) AS ROW
			FROM #temp_icp
			WHERE me_dim_event_type_id IN (76, 1204, 1230, 1247)
		) rp
		WHERE ROW = 1
		ORDER BY mailitem_code
	), cte_emh_scan as (
		SELECT 	mailitem_code
			,	me_event_local_datetime  AS emh_scan
			,	non_delivery_reason_code AS emh_non_delivery_reason_code
		FROM (
			SELECT 	mailitem_code
				, 	me_event_local_datetime
				,	non_delivery_reason_code
				,   row_number() OVER (PARTITION BY mailitem_code ORDER BY me_event_local_datetime asc) AS ROW
			FROM #temp_icp
			WHERE me_dim_event_type_id IN (36, 1260)
		) rp
		WHERE ROW = 1
		ORDER BY mailitem_code
	)
	-- pivot including all needed scans for imec108
	SELECT 	  ptt.item_id
			, ptt.local_item_id
			, ptt.letter_filter
			, ptt.receptacle_id
			, ptt.item_weight
			, ptt.item_state_indicator
			, ptt.item_postal_state
			, ptt.origin_oe
			, ptt.destination_oe
			, ptt.ema_scan
			, ptt.exb_scan
			, ptt.exc_scan
			, ptt.exd_scan
			, ptt.exx_scan
			, ptt.emc_scan
			, ptt.close_despatch_abroad
			, ptt.close_consignment_abroad
			, ptt.planned_arrival_by_predes
			, ptt.planned_arrival_by_precon
			, ptt.mrdpod --NOTE (excluded the event_type = POD as this was included in the base statement)
			, ptt.resdit_21
			, ptt.rescon
			, ptt.resdes
			, emd.emd_scan
			, emd.processing_oe
			, eda.eda_scan
			, eda.eda_retention_code
			, edb.edb_scan
			, edb.edb_retention_code
			, eme.eme_scan
			, eme.eme_retention_code
			, ptt.edc_scan
			, ptt.emf_scan
			, ptt.edd_scan
			, ptt.ede_scan
			, ptt.emg_scan
			, edf.edf_scan 
			, edf.edf_non_delivery_reason_code
			, ptt.edg_scan
			, edh.edh_scan
			, edh.edh_delivery_type_code
			, edx.edx_scan
			, edx.edx_non_delivery_reason_code
			, emh.emh_scan
			, emh.emh_non_delivery_reason_code
			, ptt.emi_scan	
			, ptt.is_eu
			, ptt.origin_country
			, ptt.country_code
			, ptt.last_update_utc
			, ptt.precon_scan
	INTO #pivot_table
	FROM #pivot_temp_table 		AS ptt
		LEFT JOIN cte_emd_scan  AS emd ON emd.mailitem_code = ptt.item_id
		LEFT JOIN cte_eda_scan  AS eda ON eda.mailitem_code = ptt.item_id
		LEFT JOIN cte_edb_scan  AS edb ON edb.mailitem_code = ptt.item_id
		LEFT JOIN cte_eme_scan  AS eme ON eme.mailitem_code = ptt.item_id
		LEFT JOIN cte_edf_scan  AS edf ON edf.mailitem_code = ptt.item_id
		LEFT JOIN cte_edh_scan  AS edh ON edh.mailitem_code = ptt.item_id
		LEFT JOIN cte_edx_scan  AS edx ON edx.mailitem_code = ptt.item_id
		LEFT JOIN cte_emh_scan  AS emh ON emh.mailitem_code = ptt.item_id;
	
	-------------------------------------------------------------------------------
	-- STEP 04 - ADDED CALCULATIONS
	-------------------------------------------------------------------------------
	-- makes sure the staging table is empty before adding the new values
	TRUNCATE TABLE ips_staging.imec_108_staging;
	
	-- each cte is used for the calculation of a certain event (see the names)
     INSERT INTO ips_staging.imec_108_staging
	WITH cte_start_the_clock AS (
		SELECT 	third_step.item_id AS item_id
			,	MIN(dwdc."date") AS start_the_clock
			,	third_step.start_the_clock_event
		FROM (
			SELECT 	start_the_clock_non_final
				,	second_step.start_the_clock_event
				,	second_step.item_id
				,	CASE 	--WHEN dwdc."date" = '2022-04-15'::date THEN country_default_increment --TEMPORARY SOLUTION!
							WHEN dwdc.date_is_not_workingday = 0 THEN country_default_increment
							WHEN dwdc.date_is_not_workingday = 1 THEN (country_default_increment + 1) END AS country_default_increment_new
			FROM (
				SELECT 	COALESCE(mrdpod_new, resdit_21_new, (CASE WHEN precon_scan IS NOT NULL THEN rescon_new END), resdes_new, emd_scan_new)::date AS start_the_clock_non_final
					,	CASE 	WHEN mrdpod_new 	IS NOT NULL THEN 'mrdpod'
								WHEN resdit_21_new 	IS NOT NULL THEN 'resdit_21'
								WHEN rescon_new 	IS NOT NULL AND precon_scan IS NOT NULL THEN 'rescon'
								WHEN resdes_new 	IS NOT NULL THEN 'resdes'
								WHEN emd_scan_new 	IS NOT NULL THEN 'emd_scan'
								ELSE NULL END AS start_the_clock_event
					,	item_id
				FROM (
					SELECT  CASE WHEN is_eu IS TRUE THEN 
									CASE WHEN to_char(mrdpod, 'HH24:MI') > '17:00' THEN DATEADD(d,1,mrdpod) ELSE mrdpod END
								 WHEN is_eu IS FALSE THEN
								 	CASE WHEN to_char(mrdpod, 'HH24:MI') > '08:00' THEN DATEADD(d,1,mrdpod) ELSE mrdpod END
								 ELSE NULL END AS mrdpod_new
						,	CASE WHEN is_eu IS TRUE THEN 
									CASE WHEN to_char(resdit_21, 'HH24:MI') > '17:00' THEN DATEADD(d,1,resdit_21) ELSE resdit_21 END
								 WHEN is_eu IS FALSE THEN
								 	CASE WHEN to_char(resdit_21, 'HH24:MI') > '08:00' THEN DATEADD(d,1,resdit_21) ELSE resdit_21 END
								 ELSE NULL END AS resdit_21_new
						,	CASE WHEN is_eu IS TRUE THEN 
									CASE WHEN to_char(rescon, 'HH24:MI') > '17:00' THEN DATEADD(d,1,rescon) ELSE rescon END
								 WHEN is_eu IS FALSE THEN
								 	CASE WHEN to_char(rescon, 'HH24:MI') > '08:00' THEN DATEADD(d,1,rescon) ELSE rescon END
								 ELSE NULL END AS rescon_new
						,	CASE WHEN is_eu IS TRUE THEN 
									CASE WHEN to_char(resdes, 'HH24:MI') > '17:00' THEN DATEADD(d,1,resdes) ELSE resdes END
								 WHEN is_eu IS FALSE THEN
								 	CASE WHEN to_char(resdes, 'HH24:MI') > '08:00' THEN DATEADD(d,1,resdes) ELSE resdes END
								 ELSE NULL END AS resdes_new
						,	CASE WHEN is_eu IS TRUE THEN 
									CASE WHEN to_char(emd_scan, 'HH24:MI') > '21:00' OR (EXTRACT(h FROM emd_scan) = 20 AND EXTRACT(m FROM emd_scan) >= 30) THEN DATEADD(d,1,emd_scan) ELSE emd_scan END
								 WHEN is_eu IS FALSE THEN
								 	CASE WHEN to_char(emd_scan, 'HH24:MI') > '10:00' THEN DATEADD(d,1,emd_scan) ELSE emd_scan END
								 ELSE NULL END AS emd_scan_new
						, 	precon_scan
						,	item_id
					FROM #pivot_table pt
					WHERE is_eu IS NOT NULL
				) first_step
			) second_step
				LEFT JOIN mdm.dim_working_day_calculation AS dwdc	ON dwdc."date" = second_step.start_the_clock_non_final	AND dwdc.country_code = 'NL'
		) third_step
			LEFT JOIN mdm.dim_working_day_calculation 	AS dwdc 	ON dwdc.country_default_increment = third_step.country_default_increment_new	AND dwdc.country_code = 'NL'
		GROUP BY 	third_step.start_the_clock_event
			,		third_step.item_id
	), cte_stop_the_clock AS (
		SELECT 	item_id
			,	LEAST(emh_scan, edh_scan, emi_scan, edf_scan, edx_scan)::date AS stop_the_clock
		FROM #pivot_table
	), cte_duration AS (
		SELECT pt.item_id
			, DATEDIFF(d,cstart.start_the_clock, cstop.stop_the_clock) AS duration
		FROM #pivot_table pt
			LEFT JOIN cte_start_the_clock 	AS 	cstart 	ON 	cstart.item_id 	= 	pt.item_id
			LEFT JOIN cte_stop_the_clock 	AS 	cstop 	ON 	cstop.item_id 	= 	pt.item_id
	), cte_customs_in AS (
		SELECT 	item_id
			,	MIN(dwdc."date") AS customs_in
		FROM(
			SELECT 	item_id
				,	customs_in_non_final
				,	CASE 	WHEN dwdc.date_is_not_workingday = 0 THEN country_default_increment
							WHEN dwdc.date_is_not_workingday = 1 THEN (country_default_increment + 1) END AS country_default_increment_new
			FROM (
				SELECT 	item_id
					,	edb_scan
					,   CASE WHEN EXTRACT(h FROM edb_scan) >= 15 THEN DATEADD(d,1,edb_scan) ELSE edb_scan END::date AS customs_in_non_final
				FROM #pivot_table
				WHERE edb_scan IS NOT NULL 
			) first_step
				LEFT JOIN mdm.dim_working_day_calculation AS dwdc 	ON dwdc."date" = first_step.customs_in_non_final	AND dwdc.country_code = 'NL'
		) second_step
			LEFT JOIN mdm.dim_working_day_calculation AS dwdc	ON dwdc.country_default_increment = second_step.country_default_increment_new AND dwdc.country_code = 'NL'
		GROUP BY item_id
	), cte_customs_out AS (
		SELECT 	item_id
			,	MIN(dwdc."date") AS customs_out
		FROM(
			SELECT 	item_id
				,	customs_out_non_final
				,	CASE 	WHEN dwdc.date_is_not_workingday = 0 THEN country_default_increment
							WHEN dwdc.date_is_not_workingday = 1 THEN (country_default_increment + 1) END AS country_default_increment_new
			FROM (
				SELECT 	item_id
					,	edc_scan
					,   CASE WHEN EXTRACT(h FROM edc_scan) >= 18 THEN DATEADD(d,1,edc_scan) ELSE edc_scan END::date AS customs_out_non_final
				FROM #pivot_table
				WHERE edc_scan IS NOT NULL 
			) first_step
				LEFT JOIN mdm.dim_working_day_calculation 	AS dwdc 	ON 	dwdc."date" 	= 	first_step.customs_out_non_final	AND 	dwdc.country_code 	= 	'NL'
		) second_step
			LEFT JOIN mdm.dim_working_day_calculation 	AS dwdc		ON dwdc.country_default_increment = second_step.country_default_increment_new 	AND dwdc.country_code = 'NL'
		GROUP BY item_id
			,	 customs_out_non_final
	), cte_non_working_days_customs AS (
		SELECT  pt.item_id
			,	COUNT(CASE WHEN dwdc.date_is_not_workingday = 1 THEN 1 ELSE NULL END) AS non_working_days_customs
		FROM #pivot_table pt
			LEFT JOIN cte_customs_in 					AS cci		ON	cci.item_id 	= 	pt.item_id
			LEFT JOIN cte_customs_out 					AS cco 		ON 	cco.item_id 	= 	pt.item_id
			LEFT JOIN mdm.dim_working_day_calculation 	AS dwdc		ON 	dwdc."date" 	>= 	customs_in		AND 	dwdc."date" <= customs_out		AND 	dwdc.country_code = 'NL'
		WHERE 	customs_in IS NOT NULL 
		AND 	customs_out IS NOT NULL
		GROUP BY pt.item_id
	), cte_customs_duration AS (
		SELECT 	pt.item_id
			,	CASE WHEN (DATEDIFF(d, cci.customs_in, cco.customs_out) - cnwdc.non_working_days_customs - 1) < 0 THEN 0
					 ELSE (DATEDIFF(d, cci.customs_in, cco.customs_out) - cnwdc.non_working_days_customs - 1) 
					 END AS customs_duration
		FROM #pivot_table pt
			LEFT JOIN cte_customs_in 				AS cci		ON 	cci.item_id 	= 	pt.item_id
			LEFT JOIN cte_customs_out 				AS cco 		ON 	cco.item_id 	= 	pt.item_id
			LEFT JOIN cte_non_working_days_customs 	AS cnwdc	ON 	cnwdc.item_id 	= 	pt.item_id
		WHERE eme_scan IS NOT NULL
	), cte_non_working_days_e2e AS (
		SELECT  pt.item_id
--			,	COUNT(CASE WHEN dwdc.date_is_not_workingday = 1 THEN 1 ELSE NULL END) AS non_working_days_e2e
			,  COUNT(CASE WHEN dwdc.mon_to_sat = 0 THEN 1 ELSE NULL END) AS non_working_days_e2e
		FROM #pivot_table pt
			LEFT JOIN cte_start_the_clock 				AS cstart 	ON	cstart.item_id 	= 	pt.item_id
			LEFT JOIN cte_stop_the_clock 				AS cstop 	ON 	cstop.item_id 	= 	pt.item_id
			LEFT JOIN mdm.dim_working_day_calculation 	AS dwdc 	ON 	dwdc."date" 	>= 	cstart.start_the_clock 	AND 	dwdc."date" <= stop_the_clock 	AND 	dwdc.country_code = 'NL'
		WHERE 	start_the_clock IS NOT NULL 
		AND  	stop_the_clock IS NOT NULL
		GROUP BY pt.item_id
	), cte_transit_time AS (
		SELECT 	pt.item_id
			,	cd.duration - cnwde.non_working_days_e2e - ISNULL(ccd.customs_duration, 0) AS transit_time
		FROM #pivot_table pt
			LEFT JOIN cte_duration 				AS cd 		ON cd.item_id 		= 	pt.item_id
			LEFT JOIN cte_non_working_days_e2e 	AS cnwde 	ON cnwde.item_id 	= 	pt.item_id
			LEFT JOIN cte_customs_duration 		AS ccd 		ON ccd.item_id 		= 	pt.item_id
	), cte_on_time AS (
		SELECT 	pt.item_id
			,	CASE WHEN ctt.transit_time IS NOT NULL THEN
					CASE WHEN pt.is_eu = FALSE THEN
							CASE WHEN ctt.transit_time < 3 THEN 'Yes' ELSE 'No' END 
						 WHEN pt.is_eu = TRUE THEN
						 	CASE WHEN ctt.transit_time < 2 THEN 'Yes' ELSE 'No' END
						 ELSE NULL END
					ELSE NULL END AS on_time
		FROM #pivot_table pt
			LEFT JOIN cte_transit_time ctt ON ctt.item_id = pt.item_id
	)
	-- insert final selection into the staging table 
	SELECT 	pt.item_id
	,	local_item_id
	,	letter_filter
	,	receptacle_id
	,	SUBSTRING(receptacle_id, 13, 1) AS service_level
	,	item_weight
	,	item_state_indicator
	,	item_postal_state
	,	origin_oe
	,	destination_oe
	,	is_eu
	,	origin_country
	,	ema_scan
	,	exb_scan
	,	exc_scan
	,	exd_scan
	,	exx_scan
	,	emc_scan
	,	close_despatch_abroad
	,	close_consignment_abroad
	,	planned_arrival_by_predes
	,	planned_arrival_by_precon
	,	mrdpod
	,	resdit_21
	,	rescon
	,	resdes
	,	emd_scan
	,	processing_oe
	,	eda_scan
	,	eda_retention_code
	,	edb_scan
	,	edb_retention_code
	,	eme_scan
	,	eme_retention_code
	,	edc_scan
	,	emf_scan
	,	edd_scan
	,	ede_scan
	,	emg_scan
	,	edf_scan
	,	edf_non_delivery_reason_code
	,	edg_scan
	,	edh_scan
	,	edh_delivery_type_code
	,	edx_scan
	,	edx_non_delivery_reason_code
	,	emh_scan
	,	emh_non_delivery_reason_code
	,	emi_scan
	,	start_the_clock
	,	start_the_clock_event
	,	customs_in
	,	customs_out
	,	customs_duration 				AS customs_time
	,	stop_the_clock
	,	transit_time
	,	on_time
	,	last_update_utc
	FROM #pivot_table pt
		LEFT JOIN cte_start_the_clock 			AS cstart	ON cstart.item_id 	= 	pt.item_id
		LEFT JOIN cte_stop_the_clock 				AS cstop 	ON cstop.item_id 	= 	pt.item_id
		LEFT JOIN cte_duration 					AS cd 	ON cd.item_id 		= 	pt.item_id
		LEFT JOIN cte_customs_in 				AS cci 	ON cci.item_id 	= 	pt.item_id
		LEFT JOIN cte_customs_out 				AS cco 	ON cco.item_id 	= 	pt.item_id
		LEFT JOIN cte_non_working_days_customs 		AS cnwdc 	ON cnwdc.item_id 	= 	pt.item_id
		LEFT JOIN cte_customs_duration 			AS ccd 	ON ccd.item_id 	= 	pt.item_id
		LEFT JOIN cte_non_working_days_e2e 		AS cnwde 	ON cnwde.item_id 	= 	pt.item_id
		LEFT JOIN cte_transit_time 				AS ctt 	ON ctt.item_id 	= 	pt.item_id
		LEFT JOIN cte_on_time 					AS cteot	ON cteot.item_id 	= 	pt.item_id
	;

	GET DIAGNOSTICS _VAR_inserts := ROW_COUNT;
    	RAISE INFO 'ips_staging.imec_108_staging update completed: % rows inserted.', _VAR_inserts;
	
--     Creation and truncation of staging table
--	CREATE TABLE IF NOT EXISTS ips_staging.imec_108_staging(
--			item_id						varchar(64)
--		,	local_item_id					varchar(64)
--		,	letter_filter					varchar(64)
--		,	receptacle_id					varchar(30)
--		,	service_level					varchar(1)
--		,	item_weight					float8
--		,	item_state_indicator			varchar(64)
--		,	item_postal_state				varchar(10)
--		,	origin_oe						varchar(30)
--		,	destination_oe					varchar(24)
--		,	is_eu						bool
--		,	origin_country					varchar(64)
--		,	ema_scan						timestamp
--		,	exb_scan						timestamp
--		,	exc_scan						timestamp
--		,	exd_scan						timestamp
--		,	exx_scan						timestamp
--		,	emc_scan						timestamp
--		,	close_despatch_abroad			timestamp
--		,	close_consignment_abroad			timestamp
--		,	planned_arrival_by_predes		timestamp
--		,	planned_arrival_by_precon		timestamp
--		,	mrdpod						timestamp
--		,	resdit_21						timestamp
--		,	rescon						timestamp
--		,	resdes						timestamp
--		,	emd_scan						timestamp
--		,	processing_oe					char(6)
--		,	eda_scan						timestamp
--		,	eda_retention_code				int4
--		,	edb_scan						timestamp
--		,	edb_retention_code				int4
--		,	eme_scan						timestamp
--		,	eme_retention_code				int4
--		,	edc_scan						timestamp
--		,	emf_scan						timestamp
--		,	edd_scan						timestamp
--		,	ede_scan						timestamp
--		,	emg_scan						timestamp
--		,	edf_scan						timestamp
--		,	edf_non_delivery_reason_code		varchar(12)
--		,	edg_scan						timestamp
--		,	edh_scan						timestamp
--		,	edh_delivery_type_code			varchar(12)
--		,	edx_scan						timestamp
--		,	edx_non_delivery_reason_code		varchar(12)
--		,	emh_scan						timestamp
--		,	emh_non_delivery_reason_code		int4
--		,	emi_scan						timestamp
--		,	start_the_clock				date
--		,	start_the_clock_event			varchar(12)
--		,	customs_in					date
--		,	customs_out					date
--		,	customs_time					int8
--		,	stop_the_clock					date
--		,	transit_time					int8
--		,	on_time						varchar(3)
--		,	last_update_utc				timestamp
--	);
    
END; 





$$;

