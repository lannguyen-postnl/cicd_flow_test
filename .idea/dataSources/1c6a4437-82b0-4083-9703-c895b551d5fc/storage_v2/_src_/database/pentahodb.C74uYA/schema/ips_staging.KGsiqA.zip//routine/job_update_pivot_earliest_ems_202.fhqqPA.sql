CREATE PROCEDURE job_update_pivot_earliest_ems_202(_init_ts timestamp without time zone)
    LANGUAGE plpgsql
AS
$$
/**********************************************************************************************************************
  *
  * Purpose/Description     : This job calls stored procedures to update the calculations of
                                different tracked events (on receptacle, dispatch and consignment level) and transform
                                the output to the right format (pivot) as input for constructing the IMEC202_staging table.
  * Documentation reference : https://postnl.atlassian.net/wiki/spaces/CB/pages/3674866047/IMEC+202+302
  * Input expected          :
                                * _init_ts timestamp := '9999-12-31' then incremental data load for target tables
                                * _init_ts timestamp <> '9999-12-31' then flush & fill target tables
  * Output expected         : n/a
  * Procedure called from   : Pentaho ETL pipeline: IPS_EXPORT_MAIN>EXPORT_REPORTING>IMEC302_AND_202>IMEC202_STAGING_NEW_FLOW
  * Procedure calls         :
                                * ips_staging.sp_fact_earliest_ems_evt_202(_init_ts:=timestamp)
                                * ips_staging.sp_pivot_ems_202(_init_ts:=timestamp)
  *
**********************************************************************************************************************/
BEGIN
    RAISE INFO 'Update ips_staging.fact_earliest_ems_evt_202';
    CALL ips_staging.sp_fact_earliest_ems_evt_202(_init_ts);

    RAISE INFO 'Update ips_staging.pivot_ems_evt_202';
    CALL ips_staging.sp_pivot_ems_202(_init_ts);

   	-- RAISE exception when duplicates found
    EXCEPTION WHEN OTHERS THEN RAISE EXCEPTION 'Error %, State %', SQLERRM, SQLSTATE;
END;
$$;

