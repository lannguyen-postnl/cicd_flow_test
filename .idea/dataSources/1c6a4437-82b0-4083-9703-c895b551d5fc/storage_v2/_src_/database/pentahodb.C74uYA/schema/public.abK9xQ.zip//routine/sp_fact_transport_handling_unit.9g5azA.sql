CREATE PROCEDURE sp_fact_transport_handling_unit()
    SECURITY DEFINER
    LANGUAGE plpgsql
AS
$$














DECLARE
   _REC_duplicates 			record;
   _VAR_inserts 			int8;
 --  _VAR_last_update_ts      timestamp := (SELECT MAX(s3_partition_ts) FROM tom.fact_transport_handling_unit);
BEGIN
	   -- IF _VAR_init = TRUE THEN
		TRUNCATE TABLE tom.fact_transport_handling_unit;
		RAISE WARNING 'WARNING: An Initiation has started and the table tom.fact_transport_handling_unit has been TRUNCATED.';
	--END IF;


	INSERT INTO tom.fact_transport_handling_unit
		SELECT
			 t.id_index_orderline_transporthandlingunittotal_transporthandlingunit_hid as fact_transport_handling_unit_id
			,dt.dim_transport_handling_unit_id_hid
			,t.id_orderline_transporthandlingunittotal_transporthandlingunit as orderline_transporthandlingunittotal_transporthandlingunit_bk
			,t.orderline_transporthandlingunittotal_transporthandlingunit_grossvolumemeasure -- root table has the sum total of this column
			,t.orderline_transporthandlingunittotal_transporthandlingunit_grossweightmeasure -- root table has the sum total of this column
			,t.orderline_transporthandlingunittotal_transporthandlingunit_name
			,t.orderline_transporthandlingunittotal_transporthandlingunit_quantity -- root table has the sum total of this column
			,t.orderline_transporthandlingunittotal_transporthandlingunit_referencecode
			,r.documentid as transport_order_id
		  --,row_number() over(partition by  t.id_index_orderline_transporthandlingunittotal_transporthandlingunit_hid order by t.s3_partition_ts  desc) as rnk
			,t.s3_partition_ts
    	FROM
       	ingest_db.prep_cbs_tom.orderline_transporthandlingunittotal_transporthandlingunit t
       	LEFT JOIN tom.dim_transport_handling_unit dt on t.orderline_transporthandlingunittotal_transporthandlingunit_referencecode =dt.transporthandlingunit_referencecode_bk
       	left join ingest_db.prep_cbs_tom.root r on t.id_orderline_transporthandlingunittotal_transporthandlingunit=r.orderline_transporthandlingunittotal_transporthandlingunit
        WHERE 1=1
		--incremental load filter (comment out for initial load and don't forget to truncate the table :)):
		--AND t.s3_partition_ts  >_VAR_last_update_ts
		  ;

    GET DIAGNOSTICS _VAR_inserts := ROW_COUNT;
     RAISE INFO 'Update completed: % rows inserted in tom.fact_transport_handling_unit', _VAR_inserts;

     CALL admin.sp_pk_check_table( PG_Last_Query_ID() );
   		SELECT * INTO _REC_duplicates FROM #sp_pk_check_table;
    	IF _REC_duplicates.dupes_amount > 0 THEN
   		RAISE EXCEPTION 'Duplicates found'; RAISE INFO 'No duplicates found';
    	END IF;

    	EXCEPTION WHEN OTHERS THEN
        	IF SQLERRM = 'Duplicates found' THEN
         		RAISE EXCEPTION '% Duplicates found in total, for key values: %',_REC_duplicates.dupes_amount,_REC_duplicates.Duplicates_Check_PK;
            ELSE RAISE EXCEPTION 'Error %, State %', SQLERRM, SQLSTATE;
        	END IF;
END;














$$;

