CREATE PROCEDURE sp_get_workdays(startdate character varying, enddate character varying, country character varying, inout tmp_name character varying)
    LANGUAGE plpgsql
AS
$$
	
	 	
BEGIN
	EXECUTE 'drop table if exists ' || public.tmp_name;
	EXECUTE 'create temp table ' || public.tmp_name ||
	EXECUTE
	'SELECT
	count(nw.workday) 
	from ips.non_working_day_table as nw
	where 0=0
	and nw."datetime" >= date(StartDate) and nw."datetime" < date(EndDate)
	And nw.country_code = Country
	And nw.workday = 0
	and nw.reason != ''Weekend''
	';
END;

$$;

