CREATE FUNCTION diff_days(date_begin date, date_end date) RETURNS integer
    IMMUTABLE
    LANGUAGE plpythonu
AS
$$
	def difference_days(date_begin, date_end):
		import datetime
		diff = (date_end-date_begin).days
		return diff
		
	return difference_days(date_begin, date_end)
$$;

