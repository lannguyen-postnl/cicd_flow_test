CREATE OR REPLACE VIEW ips.imu_064
AS
SELECT
    start_leg_segment
  , route_origin_office
  , leg_operator
  , start_leg_orig_location
  , start_leg_dest_location
  , route_destination_office
  , dest_operator
  , mailcategory
  , subclass
  , route_departure
  , receptacle_code
  , receptacle_weight
  , last_update_utc
FROM
    ips.imu_064_table
WHERE 0 = 0
  AND route_departure >= '2022-01-01'
UNION ALL
SELECT
    start_leg_segment
  , route_origin_office
  , leg_operator
  , start_leg_orig_location
  , start_leg_dest_location
  , route_destination_office
  , dest_operator
  , mailcategory
  , subclass
  , route_departure
  , CAST(receptacle_aantal AS varchar)
  , total_receptacle_weight
  , TO_TIMESTAMP(last_update_utc, 'YYYY-MM-DD HH24:MI:SS') AS last_update_utc
FROM
    ips.imu_064_archive
WHERE 0 = 0
  AND route_departure < '2022-01-01'
WITH NO SCHEMA BINDING;

ALTER TABLE imu_064
    OWNER TO bramroeland;

GRANT SELECT ON imu_064 TO PUBLIC;

GRANT DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE ON imu_064 TO powerbi;

GRANT SELECT ON imu_064 TO GROUP bdm;

GRANT DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE ON imu_064 TO GROUP analyst;

GRANT SELECT ON imu_064 TO GROUP cbs_reporting;

