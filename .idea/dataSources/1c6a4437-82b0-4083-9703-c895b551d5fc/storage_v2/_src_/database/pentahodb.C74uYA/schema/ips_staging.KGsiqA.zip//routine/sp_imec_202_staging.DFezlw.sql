CREATE PROCEDURE sp_imec_202_staging(last_update_utc timestamp without time zone, end_ts_utc timestamp without time zone)
    LANGUAGE plpgsql
AS
$$
/**********************************************************************************************************************
  *
  * Purpose/Description     : This stored procedure updates its target staging table in which contains calculations of
                                different tracked events (on receptacle, dispatch and consignment level). This target staging table is on receptacle level, which includes
                                foreign keys (e.g. receptacle_id, dispatch_id). This imec_202_staging
                                table is used to update and insert into the ips.imec202 table later in the pipeline.
  * Documentation reference : https://postnl.atlassian.net/wiki/spaces/CB/pages/3674866047/IMEC+202+302
  * Input expected          : the input variable is given from the Pentaho ETL pipeline: IPS_EXPORT_MAIN>EXPORT_REPORTING>IMEC302_AND_202>'set variable' module
                                and are used to fetch the events in ips_dm.fact_mailitem_event
                                * last_update_utc timestamp
                                * end_ts_utc timestamp
  * Output expected         : Inserts into target tables
                                * ips_staging.imec_202_staging
  * Procedure called from   : Pentaho ETL pipeline: IPS_EXPORT_MAIN>EXPORT_REPORTING>IMEC302_AND_202>IMEC202_STAGING_NEW_FLOW
  * Procedure calls         : n/a
  *
**********************************************************************************************************************/
DECLARE
    _var_current_ts                 varchar := getdate();
    _var_inserts                    int     := 0;
    _var_lookback_last_update_utc   varchar:= (cast(last_update_utc as timestamp) - interval '12 months')::varchar;
    _end_ts                      varchar:= (select case when end_ts_utc is null then getdate() else end_ts_utc end as end_ts);
BEGIN
    TRUNCATE ips_staging.imec_202_staging;
    RAISE INFO '% - Truncated table ips_staging.imec_202_staging for initial load', _var_current_ts;

    DROP TABLE if EXISTS #staging;
    CREATE TABLE #staging (like ips_staging.imec_202_staging);

    _var_current_ts := getdate();
    raise info 'before first insert: %', _var_current_ts;

	--insert statements into staging table
	INSERT INTO #staging
    WITH receptacle_base as (
        SELECT
            dim_receptacle_id
            , receptacle_fid_hid
            , receptacle_id
            , ROW_NUMBER() OVER (PARTITION BY dim_receptacle_id, receptacle_fid_hid, dim_event_type_id, carrier_event_code) AS dups
        FROM
            (/*get relevant receptacles ids and receptacle events*/
            -- 1st UNION group dim_event_type_id IN (101, 105, 134, 135, 161)
            SELECT
                re.dim_receptacle_id
                , fnv_hash(re.receptacle_code) as receptacle_fid_hid
                , re.receptacle_code as receptacle_id
                , re.dim_event_type_id
                , re.carrier_event_code
            FROM
                ips_dm.fact_receptacle_event re
            INNER JOIN ips_staging.config_ips_export_202_staging config
                ON re.dim_event_type_id = config.dim_event_type_id
                AND config.source_constrain_dim_event_type_id = 'ips_dm.fact_receptacle_event'
            WHERE 0 = 0
              AND re.load_dt_utc >= last_update_utc
              AND re.load_dt_utc <= _end_ts

            UNION ALL
            -- 2st UNION group dim_event_type_id IN (200, 201)
            SELECT
                r.dim_receptacle_id
                , fnv_hash(r.receptacle_code) as receptacle_fid_hid
                , r.receptacle_code as receptacle_id
                , de.dim_event_type_id
                , null as carrier_event_code
            FROM
                ips_dm.dim_receptacle r
                    INNER JOIN ips_dm.fact_dispatch_event de
                        ON r.dim_dispatch_id = de.dim_dispatch_id
                    INNER JOIN ips_staging.config_ips_export_202_staging config
                        ON de.dim_event_type_id = config.dim_event_type_id
                        AND config.source_constrain_dim_event_type_id = 'ips_dm.fact_dispatch_event'
            WHERE 0 = 0
              AND de.load_dt_utc >= last_update_utc
              AND de.load_dt_utc <= _end_ts

            UNION ALL
            -- 3st UNION group dim_event_type_id IN (301)
            SELECT
                r.dim_receptacle_id
                , fnv_hash(r.receptacle_code) as receptacle_fid_hid
                , r.receptacle_code as receptacle_id
                , ce.dim_event_type_id
                , null as carrier_event_code
            FROM
                ips_dm.dim_receptacle r
                    INNER JOIN ips_dm.fact_consignment_event ce
                        ON r.dim_consignment_id = ce.dim_consignment_id
                    INNER JOIN ips_staging.config_ips_export_202_staging config
                        ON ce.dim_event_type_id = config.dim_event_type_id
                        AND config.source_constrain_dim_event_type_id = 'ips_dm.fact_consignment_event'
            WHERE 0 = 0
              AND ce.load_dt_utc >= last_update_utc
              AND ce.load_dt_utc <= _end_ts) as base
        )
    , deduplicated_receptacle_base as (SELECT *
                                       FROM receptacle_base
                                       WHERE dups = 1)
    SELECT
        d.dispatch_code                                                     AS "despatch_id"
      , rb.receptacle_id
      , c.consignment_code                                                  AS "consignment_id"
      , cd.first_create_dispatch                                            AS "create_dispatch"
      , route_info_dispatch.transport_despatch_flight_nr
      , route_info_dispatch.transport_despatch_2nd_leg_flight_nr
      , route_info_dispatch.transport_despatch_departure
      , route_info_dispatch.transport_despatch_arrival
      , dpha.despatch_planned_handover_abroad                               AS "despatch_planned_handover_abroad"
      , r.gross_weight                                                      AS "receptacle_weight"
      , ems_202.close_receptacle
      , pacd.first_pacd                                                     AS "predes_actual_close_despatch"
      , d.dispatch_departure_datetime                                       AS "predes_planned_close_despatch"
      , ems_202.receptacle_in_consignment
      , route_info_consignment.transport_consignment_flight_nr
      , route_info_consignment.transport_consignment_2nd_leg_flight_nr
      , route_info_consignment.transport_consignment_departure
      , route_info_consignment.transport_consignment_arrival
      , cpha.consignment_planned_handover_abroad                            AS "consignment_planned_handover_abroad"
      , pacc.first_pacc                                                     AS "precon_actual_close_consignment"
      , c.consignment_departure_datetime                                    AS "precon_planned_close_consignment"
      , ems_202.resdit74_received
      , ems_202.resdit41_handover
      , ems_202.resdit24_uplift
      , ems_202.resdit14_transport_leg_completed
      , ems_202.resdit21_delivered
      , ems_202.rescon_abroad
      , ems_202.resdes_abroad
      , first_emd_event.first_emd                                           AS emd
      , r.total_mailitems                                                   AS "receptacle_number_of_items"
      , r.receptacle_sending_customer_code                                  AS "receptacle_sending_customer"
      , ct.journey_id                                                       AS "container_journey_id"
      , ems_202.resdit6
    FROM
        deduplicated_receptacle_base AS rb
        /*LEFT JOINS ON DIMS TO GET DATA BUT TO KEEP TRACK OF ALL REQUIRED RECEPTACLES*/
        LEFT JOIN ips_dm.dim_receptacle r ON rb.dim_receptacle_id = r.dim_receptacle_id --TODO: check if this is redundant because receptacle_base already had an INNER JOIN with ips_dm.dim_receptacle
        LEFT JOIN ips_dm.dim_consignment c ON r.dim_consignment_id = c.dim_consignment_id
        LEFT JOIN ips_dm.dim_dispatch d ON r.dim_dispatch_id = d.dim_dispatch_id
        LEFT JOIN ips_dm.dim_container ct ON r.dim_container_id = ct.dim_container_id

        -- Left join with ips_dm.fact_receptacle_event table only
        -- join with the replaced/refactored query to fetch the receptacle ems events
        LEFT JOIN ips_staging.pivot_earliest_ems_202 ems_202 on rb.receptacle_fid_hid = ems_202.recptcl_fid_hid

        -- Left join with (ips_dm.fact_dispatch_event table JOIN ips_dm.dim_receptacle)
        LEFT JOIN (SELECT
                       dim_receptacle_id
                     , MIN(event_local_datetime) AS first_create_dispatch
                   FROM
                       ips_dm.fact_dispatch_event de
                           JOIN ips_dm.dim_receptacle r ON de.dim_dispatch_id = r.dim_dispatch_id
                   WHERE 1=1
                     AND   de.dim_event_type_id = 200
                     AND r.load_dt_utc >= _var_lookback_last_update_utc
                     and r.load_dt_utc <= _end_ts
                   GROUP BY dim_receptacle_id) cd ON rb.dim_receptacle_id = cd.dim_receptacle_id
        LEFT JOIN (SELECT
                       r.dim_receptacle_id
                     , MIN(de.event_local_datetime) AS first_pacd
                   FROM
                       ips_dm.fact_dispatch_event de
                           JOIN ips_dm.dim_receptacle r ON de.dim_dispatch_id = r.dim_dispatch_id
                   WHERE 1=1
                     AND   de.dim_event_type_id = 201
                     AND r.load_dt_utc >= _var_lookback_last_update_utc
                     and r.load_dt_utc <= _end_ts
                   GROUP BY dim_receptacle_id) pacd ON rb.dim_receptacle_id = pacd.dim_receptacle_id

        -- Left join with (ips_dm.fact_consignment_event table JOIN ips_dm.fact_receptacle_event)
        LEFT JOIN (SELECT
                       dim_receptacle_id
                     , MIN(ce.event_local_datetime) AS first_pacc
                   FROM
                       ips_dm.fact_consignment_event ce
                           JOIN ips_dm.fact_receptacle_event re ON ce.dim_consignment_id = re.dim_consignment_id
                   WHERE 1=1
                     AND   ce.dim_event_type_id = 301
                     AND re.load_dt_utc >= _var_lookback_last_update_utc
                     and re.load_dt_utc <= _end_ts
                   GROUP BY dim_receptacle_id) pacc ON rb.dim_receptacle_id = pacc.dim_receptacle_id
        -- Left join with (ips_dm.fact_mailitem_event table JOIN ips_dm.fact_receptacle_event)
        LEFT JOIN (SELECT
                        re.dim_receptacle_id
                      , MIN(mi.event_local_datetime) AS first_emd
                    FROM
                        ips_dm.fact_mailitem_event mi
                            JOIN ips_dm.fact_receptacle_event re ON mi.dim_receptacle_id = re.dim_receptacle_id
                    WHERE 1=1
                      AND mi.dim_event_type_id = 30
                      AND re.load_dt_utc >= _var_lookback_last_update_utc
                      and re.load_dt_utc <= _end_ts
                GROUP BY re.dim_receptacle_id) first_emd_event ON rb.dim_receptacle_id = first_emd_event.dim_receptacle_id

        /* JOINING ROUTE INFORMATION FOR DISPATCH*/ --TODO: The subqueries contains multiple JOINs and LEFT JOINs -- Constructed similar like the route_info_consignment, candidate for staging table with UNION
        LEFT JOIN (SELECT
                           r.dim_receptacle_id
                         , route.dim_route_id --TODO: only used in the subquery joins but not in the main output > can be excluded
                         , dl0.carrier_code || dl0.carrier_no AS "transport_despatch_flight_nr"
                         , dl0.departure_datetime             AS "transport_despatch_departure"
                         , dl1.arrival_datetime               AS "transport_despatch_arrival"
                         , dl2.carrier_code || dl2.carrier_no AS "transport_despatch_2nd_leg_flight_nr"
                       FROM
                           ips_dm.dim_receptacle r
                               JOIN ips_dm.dim_dispatch d ON r.dim_dispatch_id = d.dim_dispatch_id
                               JOIN ips_dm.dim_route route ON d.dim_route_id = route.dim_route_id
                               LEFT JOIN ips_dm.dim_route_leg rtlg ON d.dim_route_id = rtlg.dim_route_id AND rtlg.leg_order_no = 0
                               LEFT JOIN ips_dm.dim_route_leg drt2 ON d.dim_route_id = drt2.dim_route_id AND drt2.leg_order_no = 1
                               LEFT JOIN ips_dm.dim_leg dl1 ON route.dim_cn_leg_id = dl1.dim_leg_id
                               LEFT JOIN ips_dm.dim_leg dl0 ON rtlg.dim_leg_id = dl0.dim_leg_id
                               LEFT JOIN ips_dm.dim_leg dl2 ON drt2.dim_leg_id = dl2.dim_leg_id) route_info_dispatch ON route_info_dispatch.dim_receptacle_id = r.dim_receptacle_id
        /* JOINING ROUTE INFORMATION FOR CONSIGNMENT*/ --TODO: The subqueries contains multiple JOINs and LEFT JOINs -- Constructed similar like the route_info_dispatch, candidate for staging table with UNION
        LEFT JOIN (SELECT
                       r.dim_receptacle_id
                     , route.dim_route_id --TODO: only used in the subquery joins but not in the main output > can be excluded
                     , cl0.carrier_code || cl0.carrier_no AS "transport_consignment_flight_nr"
                     , cl0.departure_datetime             AS "transport_consignment_departure"
                     , cl1.arrival_datetime               AS "transport_consignment_arrival"
                     , cl2.carrier_code || cl2.carrier_no AS "transport_consignment_2nd_leg_flight_nr"
                   FROM
                       ips_dm.dim_receptacle r
                           JOIN ips_dm.dim_consignment c ON r.dim_consignment_id = c.dim_consignment_id
                           JOIN ips_dm.dim_route route ON c.dim_route_id = route.dim_route_id
                           LEFT JOIN ips_dm.dim_route_leg rtlg ON c.dim_route_id = rtlg.dim_route_id AND rtlg.leg_order_no = 0
                           LEFT JOIN ips_dm.dim_route_leg crt2 ON c.dim_route_id = crt2.dim_route_id AND crt2.leg_order_no = 1
                           LEFT JOIN ips_dm.dim_leg cl1 ON route.dim_cn_leg_id = cl1.dim_leg_id
                           LEFT JOIN ips_dm.dim_leg cl0 ON rtlg.dim_leg_id = cl0.dim_leg_id
                           LEFT JOIN ips_dm.dim_leg cl2 ON crt2.dim_leg_id = cl2.dim_leg_id) route_info_consignment ON route_info_consignment.dim_receptacle_id = r.dim_receptacle_id
        -- TODO: Constructed similar like the cpha, candidate for staging table with UNION
        LEFT JOIN (SELECT
                       r.dim_receptacle_id
                     , DATEADD(M, CAST(leg.cutoff_destination AS integer), leg.arrival_datetime) AS despatch_planned_handover_abroad -- Dispatch planned handover abroad is the arrival time of the last leg (CN_leg_id) plus the offset to determine cutoff
                   FROM
                       ips_dm.dim_receptacle r
                           JOIN ips_dm.dim_dispatch d ON r.dim_dispatch_id = d.dim_dispatch_id
                           JOIN ips_dm.dim_route route ON d.dim_route_id = route.dim_route_id
                           LEFT JOIN ips_dm.dim_leg leg ON route.dim_cn_leg_id = leg.dim_leg_id) dpha ON dpha.dim_receptacle_id = r.dim_receptacle_id
        -- TODO: Constructed similar like the dpha, candidate for staging table with UNION
        LEFT JOIN (SELECT
                       r.dim_receptacle_id
                     , leg.cutoff_destination --TODO: only used in the subquery joins but not in the main output > can be excluded
                     , DATEADD(M, CASE
                                      WHEN leg.cutoff_destination IS NULL THEN 0
                                      ELSE CAST(leg.cutoff_destination AS integer) END,
                               leg.arrival_datetime) AS consignment_planned_handover_abroad -- Consignment planned handover abroad is the arrival time of the last leg (CN_leg_id) plus the offset to determine cutoff
                   FROM
                       ips_dm.dim_receptacle r
                           JOIN ips_dm.dim_consignment c ON r.dim_consignment_id = c.dim_consignment_id
                           JOIN ips_dm.dim_route route ON c.dim_route_id = route.dim_route_id
                           LEFT JOIN ips_dm.dim_leg leg ON route.dim_cn_leg_id = leg.dim_leg_id) cpha ON cpha.dim_receptacle_id = r.dim_receptacle_id
    ;

    _var_current_ts := getdate();
    raise info 'before second insert: %', _var_current_ts;
    --insert into target table the most aggregated rows to avoid duplication caused by row explosion
    INSERT INTO ips_staging.imec_202_staging
    SELECT
        despatch_id
      , receptacle_id
      , consignment_id
      , MIN(create_dispatch)                                           AS create_dispatch
      , LISTAGG(DISTINCT transport_despatch_flight_nr, ' ')            AS transport_despatch_flight_nr
      , LISTAGG(DISTINCT transport_despatch_2nd_leg_flight_nr, ' ')    AS transport_despatch_2nd_leg_flight_nr
      , MIN(transport_despatch_departure)                              AS transport_despatch_departure
      , MIN(transport_despatch_arrival)                                AS transport_despatch_arrival
      , MIN(despatch_planned_handover_abroad)                          AS despatch_planned_handover_abroad
      , AVG(receptacle_weight)                                         AS receptacle_weight
      , MIN(close_receptacle)                                          AS close_receptacle
      , MIN(predes_actual_close_despatch)                              AS predes_actual_close_despatch
      , MIN(predes_planned_close_despatch)                             AS predes_planned_close_despatch
      , MIN(receptacle_in_consignment)                                 AS receptacle_in_consignment
      , LISTAGG(DISTINCT transport_consignment_flight_nr, ' ')         AS transport_consignment_flight_nr
      , LISTAGG(DISTINCT transport_consignment_2nd_leg_flight_nr, ' ') AS transport_consignment_2nd_leg_flight_nr
      , MIN(transport_consignment_departure)                           AS transport_consignment_departure
      , MIN(transport_consignment_arrival)                             AS transport_consignment_arrival
      , MIN(consignment_planned_handover_abroad)                       AS consignment_planned_handover_abroad
      , MIN(precon_actual_close_consignment)                           AS precon_actual_close_consignment
      , MIN(precon_planned_close_consignment)                          AS precon_planned_close_consignment
      , MIN(resdit74_received)                                         AS resdit74_received
      , MIN(resdit41_handover)                                         AS resdit41_handover
      , MIN(resdit24_uplift)                                           AS resdit24_uplift
      , MIN(resdit14_transport_leg_completed)                          AS resdit14_transport_leg_completed
      , MIN(resdit21_delivered)                                        AS resdit21_delivered
      , MIN(rescon_abroad)                                             AS rescon_abroad
      , MIN(resdes_abroad)                                             AS resdes_abroad
      , MIN(emd)                                                       AS emd
      , AVG(receptacle_number_of_items)                                AS receptacle_number_of_items
      , LISTAGG(DISTINCT receptacle_sending_customer, ' ')             AS receptacle_sending_customer
      , LISTAGG(DISTINCT container_journey_id, ' ')                    AS container_journey_id
      , MIN(resdit6)                                                   AS resdit6
    FROM #staging
    GROUP BY
        despatch_id
      , receptacle_id
      , consignment_id
    ;
    GET DIAGNOSTICS _VAR_inserts := ROW_COUNT; RAISE INFO '% rows inserted into remodel_ips_nationals.ips_staging.imec_202_staging', _VAR_inserts;
    _var_current_ts := getdate();
    raise info 'after second insert: %', _var_current_ts;

END;
$$;

