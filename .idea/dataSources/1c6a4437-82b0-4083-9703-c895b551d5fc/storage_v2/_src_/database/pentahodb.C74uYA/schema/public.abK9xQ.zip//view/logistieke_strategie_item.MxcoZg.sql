CREATE VIEW logistieke_strategie_item AS
WITH
    barcode
        AS
        (SELECT
             it.item_id                                                               AS items
           , LEFT(it.item_id, 1)                                                      AS barcode_type
           , event8date                                                               AS event8date
           , DATE_PART(Y, event8date) || ' - ' || DATE_PART(W, event8date)            AS year_week
           , it.rec_id                                                                AS res
           , it.despatch_id                                                           AS desp
           , it.country_destination                                                   AS des
           , SUBSTRING(it.rec_id, 13, 1)                                              AS "service level"
           , it.origin_oe                                                             AS origin_office
           , it.destination_oe                                                        AS destiantion_office
           , it.mailsubclass                                                          AS mailsubclass
           , i.item_ips_weight                                                        AS weight
           , i.item_height                                                            AS "height"
           , i.item_width                                                             AS "width"
           , i.item_length                                                            AS "length"
           , CASE WHEN it.mailsubclass IN ('CB', 'CR', 'UV') THEN 'Yes' ELSE 'No' END AS "return"
         FROM
             ips.imec_leg_123 it
--left join analyst_datasets.ips_leg1_analysis_receptacles r on r.receptacle_id = it.rec_id 
                 LEFT JOIN ttint_dm.fact_item_event_aggregated fiea ON fiea.barcode = it.item_id
                 LEFT JOIN ttint_dm.dim_item i ON i.barcode = it.item_id
--left join ttint_dm.dim_calendar dc on dc.day_date = fiea.event8date 
         WHERE year_week >= '2022 - 30' AND year_week <= '2022 - 38')
SELECT
    year_week
  , event8date
  , des
  , "service level"
  , origin_office
  , destiantion_office
  , mailsubclass
  , res
  , desp
  , items
  , weight
  , "height"
  , "width"
  , "length"
  , "return"
  , barcode_type
FROM
    barcode
WITH NO SCHEMA BINDING;

ALTER TABLE logistieke_strategie_item
    OWNER TO fanielmebrahtuhailemica;

GRANT SELECT ON logistieke_strategie_item TO powerbi;

GRANT SELECT ON logistieke_strategie_item TO GROUP bdm;

GRANT DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE ON logistieke_strategie_item TO GROUP analyst;

