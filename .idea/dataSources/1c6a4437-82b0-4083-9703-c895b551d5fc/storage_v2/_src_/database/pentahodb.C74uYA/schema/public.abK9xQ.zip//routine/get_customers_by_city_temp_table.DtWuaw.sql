CREATE PROCEDURE get_customers_by_city_temp_table(inout temptable character varying)
    LANGUAGE plpgsql
AS
$$
BEGIN
  EXECUTE 'drop table if exists ' || temptable;
  EXECUTE 'create temp table ' || temptable || ' as  (   SELECT carrier_tracking_number, creation_time
    FROM pentahodb.xbs.xbs_scv
    WHERE creation_time >= DATEADD(day,-60, GETDATE()))';
END;
$$;

