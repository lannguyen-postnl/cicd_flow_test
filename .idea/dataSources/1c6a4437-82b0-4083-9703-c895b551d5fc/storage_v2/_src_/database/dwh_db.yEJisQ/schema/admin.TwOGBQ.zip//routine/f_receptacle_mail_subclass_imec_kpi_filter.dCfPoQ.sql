CREATE FUNCTION f_receptacle_mail_subclass_imec_kpi_filter(mail_subclass character) RETURNS character varying
    IMMUTABLE
    LANGUAGE sql
AS
$$
  SELECT
      CASE
            WHEN $1 IN ('CE', 'CN', 'CX', 'EN') THEN 'Parcels'
            WHEN $1 IN ('UA', 'UL', 'UN')       THEN 'TM'
            WHEN $1 IN ('UY', 'UX')             THEN 'TL&P'
                ELSE 'Not Used'
      END                                AS imec_kpi_filter
$$;

