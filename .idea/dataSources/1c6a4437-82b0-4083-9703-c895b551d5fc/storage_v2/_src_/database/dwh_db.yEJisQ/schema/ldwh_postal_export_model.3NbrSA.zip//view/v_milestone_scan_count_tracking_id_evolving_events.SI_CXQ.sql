CREATE VIEW ldwh_postal_export_model.v_milestone_scan_count_tracking_id_evolving_events AS

SELECT
    'start_leg_1_scan'                                                   AS milestone
  , COALESCE(ti.start_leg_1_scan, 'missing')                             AS scan_value_bk
    --aggregates:
  , SUM(CASE WHEN ti.barcode_is_untracked = FALSE THEN 1 ELSE 0 END)     AS "tracked_scan_#"
  , ROUND("tracked_scan_#" * 1.0 / SUM("tracked_scan_#") OVER (), 2)     AS tracked_scan_value_rate
  , SUM(CASE WHEN ti.barcode_is_untracked = TRUE THEN 1 ELSE 0 END)      AS "untracked_scan_#"
  , ROUND("untracked_scan_#" * 1.0 / SUM("untracked_scan_#") OVER (), 2) AS untracked_scan_value_rate
FROM
    ldwh_postal_export_model.pivoted_fact_tracking_id_evolving_events ti
GROUP BY
    1, 2

UNION ALL

SELECT
    'start_leg_2_scan'                                                   AS milestone
  , COALESCE(ti.start_leg_2_scan, 'missing')                             AS scan_value_bk
    --aggregates:
  , SUM(CASE WHEN ti.barcode_is_untracked = FALSE THEN 1 ELSE 0 END)     AS "tracked_scan_#"
  , ROUND("tracked_scan_#" * 1.0 / SUM("tracked_scan_#") OVER (), 2)     AS tracked_scan_value_rate
  , SUM(CASE WHEN ti.barcode_is_untracked = TRUE THEN 1 ELSE 0 END)      AS "untracked_scan_#"
  , ROUND("untracked_scan_#" * 1.0 / SUM("untracked_scan_#") OVER (), 2) AS untracked_scan_value_rate
FROM
    ldwh_postal_export_model.pivoted_fact_tracking_id_evolving_events ti
GROUP BY
    1, 2

UNION ALL

SELECT
    'start_leg_3_scan'                                                   AS milestone
  , COALESCE(ti.start_leg_3_scan, 'missing')                             AS scan_value_bk
    --aggregates:
  , SUM(CASE WHEN ti.barcode_is_untracked = FALSE THEN 1 ELSE 0 END)     AS "tracked_scan_#"
  , ROUND("tracked_scan_#" * 1.0 / SUM("tracked_scan_#") OVER (), 2)     AS tracked_scan_value_rate
  , SUM(CASE WHEN ti.barcode_is_untracked = TRUE THEN 1 ELSE 0 END)      AS "untracked_scan_#"
  , ROUND("untracked_scan_#" * 1.0 / SUM("untracked_scan_#") OVER (), 2) AS untracked_scan_value_rate
FROM
    ldwh_postal_export_model.pivoted_fact_tracking_id_evolving_events ti
GROUP BY
    1, 2

UNION ALL

SELECT
    'stop_leg_3_scan'                                                    AS milestone
  , COALESCE(ti.stop_leg_3_scan, 'missing')                              AS scan_value_bk
    --aggregates:
  , SUM(CASE WHEN ti.barcode_is_untracked = FALSE THEN 1 ELSE 0 END)     AS "tracked_scan_#"
  , ROUND("tracked_scan_#" * 1.0 / SUM("tracked_scan_#") OVER (), 2)     AS tracked_scan_value_rate
  , SUM(CASE WHEN ti.barcode_is_untracked = TRUE THEN 1 ELSE 0 END)      AS "untracked_scan_#"
  , ROUND("untracked_scan_#" * 1.0 / SUM("untracked_scan_#") OVER (), 2) AS untracked_scan_value_rate
FROM
    ldwh_postal_export_model.pivoted_fact_tracking_id_evolving_events ti
GROUP BY
    1, 2

ORDER BY
    1, 3

WITH NO SCHEMA BINDING;

ALTER TABLE v_milestone_scan_count_tracking_id_evolving_events
    OWNER TO lannguyen;

GRANT SELECT ON v_milestone_scan_count_tracking_id_evolving_events TO GROUP analyst;

