CREATE VIEW v_primary_key_table_info(pk_schema, pk_table, pk_columns, pk_number_of_columns) AS
SELECT
    table_constraints.constraint_schema          AS pk_schema
  , table_constraints.table_name                 AS pk_table
  , pg_catalog.LISTAGG(table_constraints.column_name::text, ', '::character varying::text) WITHIN GROUP (
    ORDER BY table_constraints.ordinal_position) AS pk_columns
  , "max"(table_constraints.ordinal_position)    AS pk_number_of_columns
FROM
    "admin".table_constraints
WHERE table_constraints.constraint_type::text = 'p'::character varying::text
GROUP BY
    table_constraints.constraint_schema, table_constraints.table_name;

ALTER TABLE v_primary_key_table_info
    OWNER TO lannguyen;

