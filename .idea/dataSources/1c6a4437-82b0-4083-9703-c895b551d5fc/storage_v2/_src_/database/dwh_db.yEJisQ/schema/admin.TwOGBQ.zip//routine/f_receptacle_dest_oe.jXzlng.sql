CREATE FUNCTION f_receptacle_dest_oe(receptacle_bk character varying) RETURNS character
    IMMUTABLE
    LANGUAGE sql
AS
$$
  select SUBSTRING($1, 7, 6)::char(6) as destination_oe
$$;

