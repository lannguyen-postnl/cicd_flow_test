CREATE PROCEDURE sp_sproc_ddl_analysis()
    LANGUAGE plpgsql
AS
$$
DECLARE
    r_sproc RECORD;
BEGIN
    -------------index:--------------
    -------- Metadata sprocs---------
    -------a. extract metadata-------
    -------b. regex flags------------

    --METADATA SPROCS:
    --a. extract metadata:
    DROP TABLE IF EXISTS #sproc_ddl_analysis;
    CREATE TABLE #sproc_ddl_analysis
    (
        pg_proc_oid  int,
        schema_name  varchar NOT NULL,
        sproc_name   varchar NOT NULL,
        sql_original varchar(max)
    );

    FOR r_sproc IN
        SELECT
            p.oid                   AS pg_proc_oid
          , n.nspname               AS schema_name
          , p.proname::varchar(255) AS sproc_name
            --ORIGINAL TEXT:
          , p.prosrc                AS sql_original
        FROM
            pg_catalog.pg_namespace n
            INNER JOIN pg_catalog.pg_proc p ON p.pronamespace = n.oid
        WHERE
            --variable:
            n.nspname NOT IN ('pg_tables', 'information_schema', 'pg_automv', 'pg_catalog', 'pg_internal')

        --Start of loop insert into admin.sproc_ddl_analysis
        LOOP
            EXECUTE
            ' INSERT INTO #sproc_ddl_analysis VALUES ('
                   || QUOTE_LITERAL(r_sproc.pg_proc_oid)
            || ',' || QUOTE_LITERAL(r_sproc.schema_name)
            || ',' || QUOTE_LITERAL(r_sproc.sproc_name)
            || ',' || QUOTE_LITERAL(r_sproc.sql_original)
            || ')';
        END LOOP;
    RAISE INFO 'Completed #sproc_ddl_analysis';

    --b. regex flags:
    TRUNCATE TABLE admin.sproc_ddl_analysis;

    INSERT INTO  admin.sproc_ddl_analysis
        WITH regex_sproc AS (
            SELECT
                pg_proc_oid
              , schema_name
              , sproc_name
              , sql_original
                --remove single line comments:
              , REGEXP_REPLACE(sql_original, '--[^\\n]+', ' REDACTED_COMMENT ', 0,
                               'p')                                                                    AS redacted_comments_2_minuses
                -- raise info messages can be extracted, however don't have a use case atm, redacted because of key words in raise info:
              , REGEXP_REPLACE(redacted_comments_2_minuses, '(?<=raise info\\s).*?(?=;)',
                               ' REDACTED_RAISE_INFO ', 0,
                               'p')                                                                    AS redacted_raise_info
                               --'regex\\w+\\s*\\(.*?\\)'
              , REGEXP_REPLACE(redacted_raise_info,'(regexp_count|regexp_instr|regexp_replace|regexp_substr).*?([cip]*\\s*''\\s*\\))' , ' REDACTED_REGEX ', 0,
                               'p')                                                                    AS redacted_regexp
                --REGEXP_\\w+\\s*\\(.*\\)
                --remove spaces:
              , REGEXP_REPLACE(redacted_regexp, '\\s+', ' ', 0, 'p')::varchar(max)                     AS spaces_to_space
              , REGEXP_REPLACE(LOWER(spaces_to_space::varchar(max)), '(s?)\\/\\*(.*?)\\*\\/',
                              ' REDACTED_COMMENT ', 0,
                              'p')                                                                     AS redacted_comments_asterisk
              , REGEXP_REPLACE(redacted_comments_asterisk, '''(.*?)'''
                            , ' REDACTED_HARDCODED_STRING ', 0
                            , 'p')::varchar(max)                                                       AS redacted_hardcoded_string
                --FLAGS:
              , REGEXP_REPLACE(redacted_hardcoded_string, ' drop ', ' DROP_FLAG ', 0, 'p')::varchar(max) AS drop_target_flag
              , REGEXP_REPLACE(drop_target_flag, ' copy ', ' TARGET_FLAG ', 0, 'p')::varchar(max)        AS copy_target_flag
              , REGEXP_REPLACE(copy_target_flag, ' unload ', ' TARGET_FLAG ', 0, 'p')::varchar(max)      AS unload_target_flag
              , REGEXP_REPLACE(unload_target_flag, ' insert into ', ' TARGET_FLAG ', 0,
                               'p')::varchar(max)                                                        AS insert_target_flag
              , REGEXP_REPLACE(insert_target_flag, '((\\s|\\v)from\\()|((\\s|\\v)from \\()',
                               ' SUBQUERY_FLAG ', 0,
                               'p')::varchar(max)                                                        AS subquery_flag
                --DEPENDENT ON SUBQUERY_FLAG:
              , REGEXP_REPLACE(subquery_flag, '(\\s|\\v)(from\\s|join\\s)', ' SOURCE_FLAG ', 0,
                               'p')::varchar(max)                                                        AS source_flag_from_or_join
              , REGEXP_REPLACE(source_flag_from_or_join,
                               '(create (temp\\s|temporary\\s)table|create table(?=\\s#)|into(?=\\s#))',
                               'CREATE_TEMP_TABLE_FLAG', 0, 'p')::varchar(max)
                                                                                                       AS temp_flag
              , REGEXP_REPLACE(temp_flag, 'create table', ' CREATE_TABLE_FLAG ', 0,
                               'p')::varchar(max)                                                      AS create_table_flag
                --DEPENDENT ON CTAS_FLAG:
              , REGEXP_REPLACE(create_table_flag, '(with|,)(?=\\s\\w+\\sas\\s*\\()', 'CTE_FLAG', 0,
                               'p')::varchar(max)                                                      AS cte_flag
                --should add temptable FLAG, create table as FLAG and create table FLAG
                --latest step to be replaced in FINAL TEXT:
                --Cleaning comments/hardcoded keywords like from:
--               , REGEXP_REPLACE(cte_flag, '(''.*?( SOURCE_FLAG ).*?'')?',' REDACTED_SOURCE_COMMENT ', 0,
--                                'p')::varchar(max)                                                      AS redacted_source_comment
                --FINAL TEXT TO PARSE:
              , LTRIM(cte_flag)                                                                        AS sql_to_analyze
                --ATTRIBUTES TO COUNT:
              , REGEXP_COUNT(sql_to_analyze, 'SOURCE_FLAG', 0, 'c')                                    AS source_count
              , REGEXP_COUNT(sql_to_analyze, 'TARGET_FLAG', 0, 'c')                                    AS target_count
              , REGEXP_COUNT(sql_to_analyze, 'DROP_FLAG', 0, 'c')                                      AS drop_count
              , REGEXP_COUNT(sql_to_analyze, 'CTE_FLAG', 0, 'c')                                       AS cte_count
              , REGEXP_COUNT(sql_to_analyze, 'CREATE_TEMP_TABLE_FLAG', 0, 'c')                         AS create_temp_table_count
              , REGEXP_COUNT(sql_to_analyze, 'CREATE_TABLE_FLAG', 0, 'c')                              AS create_table_count
            FROM
                #sproc_ddl_analysis
        )
        SELECT
            s.pg_proc_oid
          , s.schema_name
          , s.sproc_name
          , s.sql_original
          , s.source_count
          , s.target_count
          , s.drop_count
          , s.cte_count
          , s.create_temp_table_count
          , s.sql_to_analyze
        FROM
            regex_sproc s;
    RAISE INFO 'admin.sproc_ddl_analysis';
END
$$;

