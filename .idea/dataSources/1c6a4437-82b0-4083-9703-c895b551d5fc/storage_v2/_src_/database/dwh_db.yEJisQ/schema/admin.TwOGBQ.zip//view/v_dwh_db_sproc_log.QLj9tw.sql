CREATE VIEW v_dwh_db_sproc_log (querytxt, starttime, endtime, minutes, seconds, query, from_sp_call, message) AS
SELECT
    c.querytxt
  , c.starttime
  , c.endtime
  , date_diff('seconds'::character varying::text, c.starttime, c.endtime) / 60         AS minutes
  , date_diff('seconds'::character varying::text, c.starttime, c.endtime) % 60::bigint AS seconds
  , c.query
  , c.from_sp_call
  , e.message
FROM
    svl_stored_proc_call c
        LEFT JOIN (SELECT
                       svl_stored_proc_messages.query
                     , svl_stored_proc_messages.message
                   FROM
                       svl_stored_proc_messages
                   WHERE svl_stored_proc_messages.loglevel_text = 'EXCEPTION'::character varying::text
                   ORDER BY svl_stored_proc_messages.recordtime DESC) e ON c.query = e.query
WHERE c."database" = 'dwh_db'::bpchar AND c.querytxt <> 'CALL admin.sp_pk_check_table( $1 )'::bpchar
ORDER BY
    c.starttime DESC;

ALTER TABLE v_dwh_db_sproc_log
    OWNER TO lannguyen;

