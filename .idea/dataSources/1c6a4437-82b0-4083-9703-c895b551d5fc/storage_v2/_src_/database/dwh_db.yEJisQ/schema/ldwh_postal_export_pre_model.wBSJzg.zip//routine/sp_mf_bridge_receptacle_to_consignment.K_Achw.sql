CREATE PROCEDURE sp_mf_bridge_receptacle_to_consignment(_init_ts timestamp without time zone)
    LANGUAGE plpgsql
AS
$$
DECLARE
    _VAR_current_ts     varchar:= current_timestamp;
    _VAR_incremental_ts timestamp;
    _VAR_processed		INT:= 0;
BEGIN
    IF _init_ts = '9999-12-31' THEN
        _VAR_incremental_ts :=  (SELECT coalesce(MAX(last_modified_ts), '2022-01-01' )::date FROM dwh_db.ldwh_postal_export_pre_model.mf_bridge_receptacle_to_consignment);
    ELSE
        _VAR_incremental_ts := _init_ts;
        TRUNCATE dwh_db.ldwh_postal_export_pre_model.mf_bridge_receptacle_to_consignment;
        RAISE INFO '% - Truncated table ldwh_postal_export_pre_model.mf_bridge_receptacle_to_consignment for initial load', _var_current_ts;
    END IF;
    RAISE INFO '% - Max partition date of previous load of target table: %', _VAR_current_ts, _VAR_incremental_ts;

    RAISE INFO '% - Update target bridge table mf_bridge_receptacle_to_consignment', _VAR_current_ts;
    INSERT INTO dwh_db.ldwh_postal_export_pre_model.mf_bridge_receptacle_to_consignment
        SELECT
            -- receptacle grain
              r_evt.recptcl_pid_hid                                         AS receptacle_pid_hid
            , r_evt.recptcl_pid                                             AS receptacle_pid
            , r_evt.recptcl_fid_hid                                         AS receptacle_fid_hid
            , r_evt.recptcl_fid_bk                                          AS receptacle_bk
            -- consignment gr
            , fnv_hash(r_evt.consgnt_pid)                                   AS consignment_pid_hid
            , r_evt.consgnt_pid                                             AS consignment_pid
            , fnv_hash(cs.consgnt_fid)                                      AS consignment_bk_hid
            , cs.consgnt_fid                                                AS consignment_bk
            -- attributes
            , DATEADD(HOUR, r_evt.event_local_offset, r_evt.event_gmt_dt)   AS scan_bk_ts
            , cf.scan_value_bk
            -- metadata
            , r_evt.s3_evt_partition_ts                                     AS s3_partition_ts_receptacle
            , cs.s3_partition_ts                                            AS s3_partition_ts_consignment
            , GETDATE()                                                     AS last_modified_ts
        FROM
            ldwh_postal_export_pre_model.config_nesting_bridge_postal_export cf
            INNER JOIN ingest_db.cleanse_ips_nationals.l_recptcl_events_with_fid r_evt   ON cf.scan_value_bk = r_evt.event_type_cd
                AND cf.nesting_name_bk = 'start leg 2 local-ops mapping [receptacle-consignment]'
                AND cf.valid_from_dt <= DATEADD(HOUR, r_evt.event_local_offset, r_evt.event_gmt_dt)
                AND cf.valid_to_dt   >= DATEADD(HOUR, r_evt.event_local_offset, r_evt.event_gmt_dt)
            LEFT JOIN ingest_db.cleanse_ips_nationals.l_consgnts cs             ON fnv_hash(r_evt.consgnt_pid)  = cs.consgnt_pid_hid
        WHERE 1 = 1
            AND r_evt.last_modified_ts > _VAR_incremental_ts
            -- This is referential issue, will be fixed in the cleanse layer
            AND r_evt.recptcl_fid_found = True
        -- this should be fixed with cleans layer, need to check this
    ;
	GET DIAGNOSTICS _VAR_processed := ROW_COUNT; RAISE INFO '% rows with receptacle and consignment inserted', _VAR_processed;

END;

$$;

