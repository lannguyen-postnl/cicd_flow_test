CREATE VIEW v_user_group_access_to_schema(schemaobject, schemaname, overview_permissions) AS
SELECT
    c.relname                                                       AS schemaobject
  , nsp.nspname                                                     AS schemaname
  , "replace"(ARRAY_TO_STRING(c.relacl, ' AND '::character varying::text), '/'::character varying::text,
              ' <- permissions given by '::character varying::text) AS overview_permissions
FROM
    pg_class c
        LEFT JOIN pg_namespace nsp ON c.relnamespace = nsp.oid
        JOIN pg_group pu ON ARRAY_TO_STRING(c.relacl, '|'::character varying::text) ~~
                            (('%'::character varying::text || pu.groname::character varying::text) ||
                             '%'::character varying::text)
WHERE c.relacl IS NOT NULL
ORDER BY
    nsp.nspname;

ALTER TABLE v_user_group_access_to_schema
    OWNER TO lannguyen;

