CREATE PROCEDURE sp_lineage_parent_child()
    LANGUAGE plpgsql
AS
$$
BEGIN
    TRUNCATE TABLE admin.lineage_parent_child;
    INSERT INTO admin.lineage_parent_child
    SELECT
        src.obj_sid     as source_obj_sid
      , pc.source
      , src.is_root     as source_is_root
      , tar.obj_sid     as target_obj_sid
      , pc.target
      , tar.is_endpoint as target_is_endpoint
      , pc.proc
      , pc.source_is_self_reference
    FROM
        admin.v_lineage_parent_child pc
        LEFT JOIN admin.permanent_lineage_objects src ON pc.source = src.obj_name
        LEFT JOIN admin.permanent_lineage_objects tar ON pc.target = tar.obj_name
            ;
    END;
$$;

