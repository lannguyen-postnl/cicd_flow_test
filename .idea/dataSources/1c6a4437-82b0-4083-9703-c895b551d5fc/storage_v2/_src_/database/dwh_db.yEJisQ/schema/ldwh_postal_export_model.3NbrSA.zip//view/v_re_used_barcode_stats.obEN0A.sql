CREATE VIEW ldwh_postal_export_model.v_re_used_barcode_stats AS
WITH
    re_used_barcode_stats AS (SELECT
                                  COUNT(*) OVER (PARTITION BY barcode_bk) - 1 AS re_used
                                , 1                                           AS volume_
                              FROM
                                  ldwh_postal_export_model.pivoted_fact_tracking_id_evolving_events)
SELECT
    SUM(re_used)                                          AS re_used_barcode_amount
  , SUM(volume_)                                          AS volume
  , ROUND(re_used_barcode_amount * 1.0 / volume * 100, 2) AS re_used_perc
FROM
    re_used_barcode_stats
WITH NO SCHEMA BINDING;

ALTER TABLE v_re_used_barcode_stats
    OWNER TO lannguyen;

GRANT SELECT ON v_re_used_barcode_stats TO GROUP analyst;

