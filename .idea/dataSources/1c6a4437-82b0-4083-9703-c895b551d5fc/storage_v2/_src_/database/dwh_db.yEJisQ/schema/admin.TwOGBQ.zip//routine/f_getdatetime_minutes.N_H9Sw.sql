CREATE FUNCTION f_getdatetime_minutes() RETURNS character varying
    VOLATILE
    LANGUAGE sql
AS
$$
   SELECT to_char(getdate(), 'yyyy-MM-dd HH24:MI:SS')
$$;

