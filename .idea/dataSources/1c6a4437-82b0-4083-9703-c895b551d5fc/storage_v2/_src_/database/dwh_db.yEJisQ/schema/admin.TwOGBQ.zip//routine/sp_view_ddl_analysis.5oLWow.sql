CREATE PROCEDURE sp_view_ddl_analysis()
    LANGUAGE plpgsql
AS
$$
DECLARE
    r_view  RECORD;
BEGIN
    -------------index:--------------
    ---------Metadata views----------
    -----a. extract view metadata----
    -----b. regex flags--------------

    --METADATA VIEWS:
    --extract metadata:
    DROP TABLE IF EXISTS #view_ddl_analysis;
    CREATE TABLE         #view_ddl_analysis
    (
        pg_class_view_oid int,
        schema_name       varchar NOT NULL,
        view_name         varchar NOT NULL,
        sql_original      varchar(max)
    );

    FOR r_view IN
            SELECT
                c.oid                                            AS pg_class_view_oid
              , n.nspname                                        AS schema_name
              , c.relname                                        AS view_name
              , LTRIM(COALESCE(PG_GET_VIEWDEF(c.oid, TRUE), '')) AS sql_original
            FROM
                pg_catalog.pg_class c
                JOIN pg_catalog.pg_namespace n ON c.relnamespace = n.oid
            WHERE
                  1 = 1
              AND n.nspname NOT IN ('pg_tables', 'information_schema', 'pg_automv', 'pg_catalog', 'pg_internal')
                  -- relkind:
                  -- f = foreign table,  p = partitioned table, I = partitioned index, c = composite type
                  -- r = ordinary table, i = index, S = sequence, t = TOAST table, v = view, m = materialized view
              AND c.relkind = 'v'
            LOOP
                EXECUTE
                    ' INSERT INTO #view_ddl_analysis VALUES ('
                               || QUOTE_LITERAL(r_view.pg_class_view_oid)
                        || ',' || QUOTE_LITERAL(r_view.schema_name)
                        || ',' || QUOTE_LITERAL(r_view.view_name)
                        || ',' || QUOTE_LITERAL(r_view.sql_original)
                        || ')';
            END LOOP;
        RAISE INFO 'Completed #view_ddl_analysis';

    TRUNCATE TABLE admin.view_ddl_analysis;
    INSERT INTO    admin.view_ddl_analysis
        WITH
            regex_view AS (
                SELECT
                   pg_class_view_oid as pg_view_oid
                 , schema_name
                 , view_name
                 , sql_original
                 , REGEXP_REPLACE(sql_original, '--[^\\n]+', ' REDACTED COMMENT ', 0, 'p')::varchar(max) AS redacted_comments_2_minuses
                   --remove spaces:
                 , REGEXP_REPLACE(redacted_comments_2_minuses, '\\s+', ' ', 0, 'p')::varchar(max)       AS spaces_to_space
                 , REGEXP_REPLACE(LOWER(spaces_to_space::varchar(max)), '(s?)\\/\\*(.*?)\\*\\/',
                                  ' REDACTED_COMMENT ', 0,
                                  'p')                                                                  AS redacted_comments_asterisk
                 , REGEXP_REPLACE(redacted_comments_asterisk, '(regexp_count|regexp_instr|regexp_replace|regexp_substr).*?([cip]*\\s*''\\s*\\))', ' REDACTED_REGEX ', 0,
                                  'p')                                                                  AS redacted_regexp
                , REGEXP_REPLACE(redacted_regexp, '((\\s|\\v)(from|join)\\()|((\\s|\\v)(from|join) \\()',
                              ' SUBQUERY_FLAG ', 0,
                              'p')::varchar(max)                                                        AS subquery_flag
                 , REGEXP_REPLACE(subquery_flag, '(\\s|\\v)(from\\s|join\\s)', ' SOURCE_FLAG ', 0,
                                  'p')::varchar(max)                                                    AS source_flag_from_or_join
                 , REGEXP_REPLACE(source_flag_from_or_join, '(with|,)(?=\\s*\\w+\\sas\\s*\\()', ' CTE_FLAG ', 0,
                                  'p')::varchar(max)                                                    AS cte_flag
                   --should be a repeat of the latest analyze step:
                 , LTRIM(cte_flag)                                                                      AS sql_to_analyze
                   --counts:
                 , REGEXP_COUNT(sql_to_analyze, 'SOURCE_FLAG', 0, 'c')                                  AS source_count
                 , REGEXP_COUNT(sql_to_analyze, 'CTE_FLAG', 0, 'c')                                     AS cte_count
               FROM
                   #view_ddl_analysis
    )
    SELECT
        v.pg_view_oid
      , v.schema_name
      , v.view_name
      , v.sql_original
      , v.source_count
      , v.cte_count
      , v.sql_to_analyze
    FROM
        regex_view v;
    RAISE INFO 'Completed admin.view_ddl_analysis';
END;
$$;

