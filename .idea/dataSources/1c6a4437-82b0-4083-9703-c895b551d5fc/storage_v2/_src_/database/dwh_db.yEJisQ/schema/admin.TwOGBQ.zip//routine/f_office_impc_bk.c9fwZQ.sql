CREATE FUNCTION f_office_impc_bk(receptacle_bk character varying) RETURNS character
    IMMUTABLE
    LANGUAGE sql
AS
$$
  select left($1, 6)::char(6) as office_impc_bk
$$;

