CREATE FUNCTION f_receptacle_service_level(receptacle_bk character varying) RETURNS character
    IMMUTABLE
    LANGUAGE sql
AS
$$
  select SUBSTRING($1, 13, 1)::char(1) AS service_level
$$;

