CREATE VIEW v_user_access_db_objects(schemaobject, schemaname, username, groupname, overview_permissions) AS
SELECT
    c.relname                                                       AS schemaobject
  , nsp.nspname                                                     AS schemaname
  , use2.usename                                                    AS username
  , pu.groname                                                      AS groupname
  , "replace"(ARRAY_TO_STRING(c.relacl, ' AND '::character varying::text), '/'::character varying::text,
              ' <- permissions given by '::character varying::text) AS overview_permissions
FROM
    pg_class c
        LEFT JOIN pg_namespace nsp ON c.relnamespace = nsp.oid
        LEFT JOIN pg_user use2 ON c.relowner = use2.usesysid
        JOIN pg_group pu ON ARRAY_TO_STRING(c.relacl, '|'::character varying::text) ~~
                            (('%'::character varying::text || pu.groname::character varying::text) ||
                             '%'::character varying::text)
ORDER BY
    nsp.nspname;

ALTER TABLE v_user_access_db_objects
    OWNER TO lannguyen;

