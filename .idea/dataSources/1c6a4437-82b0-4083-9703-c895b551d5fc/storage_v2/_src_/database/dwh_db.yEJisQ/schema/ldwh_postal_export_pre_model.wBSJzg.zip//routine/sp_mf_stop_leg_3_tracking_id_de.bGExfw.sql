CREATE PROCEDURE sp_mf_stop_leg_3_tracking_id_de(_init_ts timestamp without time zone)
    LANGUAGE plpgsql
AS
$$

DECLARE
   _VAR_processed			INT:= 0;
   _VAR_incremental_ts      timestamp;
   _VAR_current_ts          varchar:=current_timestamp;
BEGIN
    --assign incremental_ts
    IF _init_ts = '9999-12-31' THEN
        _VAR_incremental_ts := (SELECT COALESCE(MAX(last_modified_ts), '2022-01-01') FROM dwh_db.ldwh_postal_export_pre_model.mf_stop_leg_3_tracking_id_de);
    ELSE
        _VAR_incremental_ts := _init_ts;
        TRUNCATE dwh_db.ldwh_postal_export_pre_model.mf_stop_leg_3_tracking_id_de;
        RAISE INFO '% - Truncated table dwh_db.ldwh_postal_export_pre_model.mf_stop_leg_3_tracking_id_de for initial load', _VAR_current_ts;

    END IF;
    RAISE INFO '% - Max partition date of previous load of target table: %', _VAR_current_ts, _VAR_incremental_ts;

   --insert statements
    INSERT INTO dwh_db.ldwh_postal_export_pre_model.mf_stop_leg_3_tracking_id_de
    SELECT
        --Keys
        ti.ti_tracking_hid
      , evt.mailitm_fid_bk               as barcode_bk
      , evt.mailitem_pid_hid             AS mailitem_pid_hid
      , cf.milestone_index_sequence_id
        --Tracked Properties
      , cf.scan_value_bk
      , evt.event_local_dt               AS scan_bk_ts
        --Metadata
      , evt.s3_evt_partition_ts          AS event_s3_partition_ts
      , GETDATE()                        AS last_modified_ts
    FROM
        --Milestone configuration file:
        dwh_db.ldwh_postal_export_pre_model.config_milestone_postal_export cf
        -- Match milestone on Source-list based on primary source and additional sources in the list:
        INNER JOIN ingest_db.cleanse_ips_nationals.n_edi_mailitm_events_with_fid evt ON cf.scan_value_bk = evt.event_type_cd
            AND cf.milestone_name_bk = 'stop leg 3 external-ops [barcode]'
            AND cf.source_name_list_bk = 'cleanse_ips_nationals.n_edi_mailitm_events'
            AND evt.event_local_dt >= cf.valid_from_dt
            AND evt.event_local_dt <= cf.valid_to_dt
        -- to fetch out the ti_tracking_hid
        INNER JOIN dwh_db.ldwh_postal_export_pre_model.dim_tracking_interval ti ON evt.mailitm_fid_hid = ti.ti_barcode_hid
        -- the event needs to be within the valid time interval range of an barcode
            AND evt.event_local_dt >= ti.ti_valid_from_dt
            AND evt.event_local_dt <= ti.ti_valid_to_dt
    WHERE 1 = 1
        -- This is referential issue
        AND evt.mailitm_fid_found is true
        AND evt.last_modified_ts > _VAR_incremental_ts
    ;

   -- After insert steps in procedure add block for count of inserts
   GET DIAGNOSTICS _VAR_processed := ROW_COUNT; RAISE INFO '% - % rows inserted into dwh_db.ldwh_postal_export_pre_model.mf_stop_leg_3_tracking_id_de', _VAR_current_ts, _VAR_processed;

END;

$$;

