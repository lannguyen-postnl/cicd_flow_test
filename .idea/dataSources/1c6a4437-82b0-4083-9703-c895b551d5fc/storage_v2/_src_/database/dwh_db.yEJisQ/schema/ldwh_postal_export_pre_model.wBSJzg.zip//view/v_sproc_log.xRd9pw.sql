CREATE VIEW v_sproc_log (job, proc, starttime, endtime, min, sec, query, from_sp_call, exception_message) AS
SELECT
    REVERSE("left"(REVERSE(qry."job"), CHARINDEX('.'::character varying::text, REVERSE(qry."job")) - 1)) AS "job"
  , CASE
        WHEN qry.from_sp_call = 0 THEN 'main job'::character varying::text
        ELSE REVERSE("left"(REVERSE(qry.proc), CHARINDEX('.'::character varying::text, REVERSE(qry.proc)) - 1))
        END                                                                                              AS proc
  , qry.starttime
  , qry.endtime
  , qry.min
  , qry.sec
  , qry.query
  , qry.from_sp_call
  , qry.exception_message
FROM
    (SELECT
         "replace"(REGEXP_REPLACE(COALESCE(h.query_text, c.querytxt::character varying)::text,
                                  ''::character varying::text), 'admin.f_incremental_load()'::character varying::text,
                   'incremental'::character varying::text) AS "job"
       , REGEXP_REPLACE(c.querytxt::character varying::text, '\\s*'::character varying::text,
                        ''::character varying::text) AS proc
       , TO_CHAR(CONVERT_TIMEZONE('CET'::character varying::text, c.starttime),
                 'YYYY-MM-DD HH24:MI:SS'::character varying::text) AS starttime
       , TO_CHAR(CONVERT_TIMEZONE('CET'::character varying::text, c.endtime),
                 'YYYY-MM-DD HH24:MI:SS'::character varying::text) AS endtime
       , date_diff('seconds'::character varying::text, c.starttime, c.endtime) / 60 AS min
       , date_diff('seconds'::character varying::text, c.starttime, c.endtime) % 60::bigint AS sec
       , c.query
       , COALESCE(c.from_sp_call, 0) AS from_sp_call
       , COALESCE(e.message,
                  'n/a                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             '::bpchar) AS exception_message
     FROM
         svl_stored_proc_call c
             LEFT JOIN sys_query_history h
                       ON h.query_id = (c.from_sp_call - 1) AND h.query_type::text = 'UTILITY'::character varying::text
             LEFT JOIN (SELECT
                            s.query
                          , s.message
                        FROM
                            svl_stored_proc_messages s
                        WHERE s.loglevel_text = 'EXCEPTION'::character varying::text
                        ORDER BY s.recordtime DESC) e ON c.query = e.query
     WHERE 1 = 1 AND c."database" = 'dwh_db'::bpchar AND
             c.querytxt !~~* 'CALL%sp_pk_check_table_name%'::character varying::text
     ORDER BY c.starttime DESC
     LIMIT 100) qry;

ALTER TABLE v_sproc_log
    OWNER TO lannguyen;

