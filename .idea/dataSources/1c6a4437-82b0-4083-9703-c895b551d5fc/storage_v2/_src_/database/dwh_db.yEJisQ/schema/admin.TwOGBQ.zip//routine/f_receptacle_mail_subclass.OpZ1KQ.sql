CREATE FUNCTION f_receptacle_mail_subclass(receptacle_bk character varying) RETURNS character
    IMMUTABLE
    LANGUAGE sql
AS
$$
  select SUBSTRING($1, 14, 2)::char(2) AS mail_subclass
$$;

