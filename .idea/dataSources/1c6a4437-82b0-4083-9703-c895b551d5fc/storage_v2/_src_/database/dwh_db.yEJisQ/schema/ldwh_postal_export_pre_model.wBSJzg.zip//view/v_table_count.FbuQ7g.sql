CREATE VIEW ldwh_postal_export_pre_model.v_table_count AS
SELECT
    TO_CHAR(COUNT(*), '9,999,999,999') "count"
  , MAX(last_modified_ts)              last_mod
  , 'bridge_receptacle_to_consignment' "table"
FROM
    ldwh_postal_export_pre_model.bridge_receptacle_to_consignment
UNION ALL
SELECT
    TO_CHAR(COUNT(*), '9,999,999,999') "count"
  , MAX(last_modified_ts)
  , 'bridge_tracking_id_to_receptacle'
FROM
    ldwh_postal_export_pre_model.bridge_tracking_id_to_receptacle
UNION ALL
SELECT
    TO_CHAR(COUNT(*), '9,999,999,999') "count"
  , MAX(last_modified_ts)
  , 'dim_datasource'
FROM
    ldwh_postal_export_pre_model.dim_datasource
UNION ALL
SELECT
    TO_CHAR(COUNT(*), '9,999,999,999') "count"
  , MAX(last_modified_ts)
  , 'dim_scan'
FROM
    ldwh_postal_export_pre_model.dim_scan
UNION ALL
SELECT
    TO_CHAR(COUNT(*), '9,999,999,999') "count"
  , MAX(record_last_modified_ts)
  , 'dim_tracking_interval'
FROM
    ldwh_postal_export_pre_model.dim_tracking_interval
UNION ALL
SELECT
    TO_CHAR(COUNT(*), '9,999,999,999') "count"
  , MAX(ti_record_last_modified_ts)
  , 'dim_tracking_interval_staging'
FROM
    ldwh_postal_export_pre_model.dim_tracking_interval_staging
UNION ALL
SELECT
    TO_CHAR(COUNT(*), '9,999,999,999') "count"
  , MAX(last_modified_ts)
  , 'integration_bridge'
FROM
    ldwh_postal_export_pre_model.integration_bridge
UNION ALL
SELECT
    TO_CHAR(COUNT(*), '9,999,999,999') "count"
  , MAX(last_modified_ts)
  , 'mf_bridge_receptacle_to_consignment'
FROM
    ldwh_postal_export_pre_model.mf_bridge_receptacle_to_consignment
UNION ALL
SELECT
    TO_CHAR(COUNT(*), '9,999,999,999') "count"
  , MAX(last_modified_ts)
  , 'mf_bridge_tracking_id_to_receptacle'
FROM
    ldwh_postal_export_pre_model.mf_bridge_tracking_id_to_receptacle
UNION ALL
SELECT
    TO_CHAR(COUNT(*), '9,999,999,999') "count"
  , MAX(last_modified_ts)
  , 'mf_postal_domain_qualifier'
FROM
    ldwh_postal_export_pre_model.mf_postal_domain_qualifier
UNION ALL
SELECT
    TO_CHAR(COUNT(*), '9,999,999,999') "count"
  , MAX(last_modified_ts)
  , 'mf_start_leg_1_tracking_id_de'
FROM
    ldwh_postal_export_pre_model.mf_start_leg_1_tracking_id_de
UNION ALL
SELECT
    TO_CHAR(COUNT(*), '9,999,999,999') "count"
  , MAX(last_modified_ts)
  , 'mf_start_leg_2_consignment_de'
FROM
    ldwh_postal_export_pre_model.mf_start_leg_2_consignment_de
UNION ALL
SELECT
    TO_CHAR(COUNT(*), '9,999,999,999') "count"
  , MAX(last_modified_ts)
  , 'mf_start_leg_3_receptacle_de'
FROM
    ldwh_postal_export_pre_model.mf_start_leg_3_receptacle_de
UNION ALL
SELECT
    TO_CHAR(COUNT(*), '9,999,999,999') "count"
  , MAX(last_modified_ts)
  , 'mf_start_leg_3_tracking_id_de'
FROM
    ldwh_postal_export_pre_model.mf_start_leg_3_tracking_id_de
UNION ALL
SELECT
    TO_CHAR(COUNT(*), '9,999,999,999') "count"
  , MAX(last_modified_ts)
  , 'mf_stop_leg_3_tracking_id_de'
FROM
    ldwh_postal_export_pre_model.mf_stop_leg_3_tracking_id_de
UNION ALL
SELECT
    TO_CHAR(COUNT(*), '9,999,999,999') "count"
  , MAX(last_modified_ts)
  , 'pf_start_leg_1_tracking_id_ee'
FROM
    ldwh_postal_export_pre_model.pf_start_leg_1_tracking_id_ee
UNION ALL
SELECT
    TO_CHAR(COUNT(*), '9,999,999,999') "count"
  , MAX(last_modified_ts)
  , 'pf_start_leg_2_consignment_ee'
FROM
    ldwh_postal_export_pre_model.pf_start_leg_2_consignment_ee
UNION ALL
SELECT
    TO_CHAR(COUNT(*), '9,999,999,999') "count"
  , MAX(last_modified_ts)
  , 'pf_start_leg_3_receptacle_ee'
FROM
    ldwh_postal_export_pre_model.pf_start_leg_3_receptacle_ee
UNION ALL
SELECT
    TO_CHAR(COUNT(*), '9,999,999,999') "count"
  , MAX(last_modified_ts)
  , 'pf_start_leg_3_tracking_id_ee'
FROM
    ldwh_postal_export_pre_model.pf_start_leg_3_tracking_id_ee
UNION ALL
SELECT
    TO_CHAR(COUNT(*), '9,999,999,999') "count"
  , MAX(last_modified_ts)
  , 'pf_stop_leg_3_tracking_id_ee'
FROM
    ldwh_postal_export_pre_model.pf_stop_leg_3_tracking_id_ee
UNION ALL
SELECT
    TO_CHAR(COUNT(*), '9,999,999,999') "count"
  , MAX(last_modified_ts)
  , 'pivoted_fact_tracking_id_evolving_events'
FROM
    ldwh_postal_export_model.pivoted_fact_tracking_id_evolving_events
WITH NO SCHEMA BINDING;

ALTER TABLE v_table_count
    OWNER TO lannguyen;

