CREATE VIEW v_get_tbl_priv_by_user(schemaname, tablename, usename, sel, ins, upd, del, ref) AS
SELECT
    derived_table1.schemaname
  , derived_table1.tablename
  , derived_table1.usename
  , derived_table1.sel
  , derived_table1.ins
  , derived_table1.upd
  , derived_table1.del
  , derived_table1.ref
FROM
    (SELECT
         objs.schemaname
       , objs.tablename
       , usrs.usename
       , HAS_TABLE_PRIVILEGE(usrs.usename, objs.obj, 'select'::character varying::text)     AS sel
       , HAS_TABLE_PRIVILEGE(usrs.usename, objs.obj, 'insert'::character varying::text)     AS ins
       , HAS_TABLE_PRIVILEGE(usrs.usename, objs.obj, 'update'::character varying::text)     AS upd
       , HAS_TABLE_PRIVILEGE(usrs.usename, objs.obj, 'delete'::character varying::text)     AS del
       , HAS_TABLE_PRIVILEGE(usrs.usename, objs.obj, 'references'::character varying::text) AS ref
     FROM
         (SELECT
              pg_tables.schemaname
            , pg_tables.tablename
            , '"'::character varying::text + pg_tables.schemaname::character varying::text +
              '"'::character varying::text + '.'::character varying::text + '"'::character varying::text +
              pg_tables.tablename::character varying::text + '"'::character varying::text AS obj
          FROM
              pg_tables
          WHERE pg_tables.schemaname !~ '^information_schema|catalog_history|pg_'::character varying::text) objs
       , (SELECT
              pg_user.usename
            , pg_user.usesysid
            , pg_user.usecreatedb
            , pg_user.usesuper
            , pg_user.usecatupd
            , pg_user.passwd
            , pg_user.valuntil
            , pg_user.useconfig
          FROM
              pg_user) usrs
     ORDER BY objs.obj) derived_table1
WHERE derived_table1.sel = TRUE OR derived_table1.ins = TRUE OR derived_table1.upd = TRUE OR derived_table1.del = TRUE
   OR derived_table1.ref = TRUE;

ALTER TABLE v_get_tbl_priv_by_user
    OWNER TO lannguyen;

