CREATE PROCEDURE sp_unique_tracking_exception()
    LANGUAGE plpgsql
AS
$$
   DECLARE
        _VAR_inserts    int;      --For RAISE INFO of amount of inserted rows
        _VAR_deletes    int;      --For RAISE INFO of amount of deleted rows
        _VAR_TS         varchar;  --For RAISE INFO of current datatime
    BEGIN
        --Create staging table for invalidation, exact copy of target table: ldwh_postal_export_pre_model.dim_tracking_interval.
        DROP TABLE IF EXISTS   #invalidation_correction;
        CREATE TEMPORARY TABLE #invalidation_correction ( LIKE ldwh_postal_export_pre_model.dim_tracking_interval );

        INSERT INTO #invalidation_correction
        SELECT
            --/* sanity check source (ev) info: */ ev.ti_barcode_hid, ev.ti_scan_ts AS earlier_scan_with_overlapping_barcode,
            --WARNING aftr.* NEEDS TO BE EXACT COPY OF TABLE, GETDATE()'s MARK INVALIDATION INFO:
            aftr.ti_tracking_hid
          , aftr.ti_barcode_hid
          , aftr.ti_barcode_bk
          , aftr.ti_scan_ts
          , aftr.ti_valid_from_dt
          , aftr.ti_valid_to_dt
          , aftr.source_last_modified
          , getdate()                   AS record_last_modified_ts
          , getdate()                   AS invalidation_ts
        FROM
            ldwh_postal_export_pre_model.dim_tracking_interval_staging  AS ev
            --Find all tracking ids after the overlapping earlier scan:
            INNER JOIN ldwh_postal_export_pre_model.dim_tracking_interval      AS aftr ON
                    aftr.ti_barcode_hid   = ev.ti_barcode_hid   --match staging to target on barcode.
                AND ev.ti_dml_action      = 'u'                 --status u contains only barcodes to be updated (corrected) per interval and have to look for a match in the target
                AND aftr.invalidation_ts  IS NULL               --invalidated tracking id's don't need to be re-invalidated.
                AND aftr.ti_valid_from_dt > ev.ti_valid_from_dt --time criteria, targets to be invalidated should have their start (ti_valid_from_dt) later than the interval that needs to be inserted
        ;

        GET DIAGNOSTICS _VAR_inserts := ROW_COUNT; _VAR_TS := ( SELECT admin.f_getdatetime_minutes() ||':' );
        RAISE INFO '% % rows inserted in #invalidation_correction', _VAR_TS, _VAR_inserts;

        --BULK UPDATE (separate DELETE and INSERT) to mark for invalidation:
        DELETE FROM ldwh_postal_export_pre_model.dim_tracking_interval
        WHERE
            ti_tracking_hid IN ( select ti_tracking_hid from #invalidation_correction );

        _VAR_deletes := ( SELECT sum(rows) FROM STL_DELETE WHERE query = pg_last_query_id() ); _VAR_TS := ( SELECT admin.f_getdatetime_minutes() ||':' );
        RAISE INFO '% % rows deleted from ldwh_postal_export_pre_model.dim_tracking_interval', _VAR_TS, _VAR_deletes;

        --INSERT the invalidated tracking ids, that now contain an invalidated timestamp:
        INSERT INTO ldwh_postal_export_pre_model.dim_tracking_interval ( SELECT * FROM #invalidation_correction );

        GET DIAGNOSTICS _VAR_inserts := ROW_COUNT; _VAR_TS := ( SELECT admin.f_getdatetime_minutes() ||':' );
        RAISE INFO '% % rows inserted in ldwh_postal_export_pre_model.dim_tracking_interval', _VAR_TS, _VAR_inserts;

        --Placeholder table from dml action SPROC, used in the same UIM SESSION:
        DROP TABLE IF EXISTS   #tracking_id_events;
        CREATE TEMPORARY TABLE #tracking_id_events
        (
            barcode_hid            BIGINT         ENCODE RAW
           --barcode_bk can be removed for performance. Kept it to make troubleshooting easier.
           ,barcode_bk             VARCHAR(256)   ENCODE lzo
           ,scan_ts                TIMESTAMP      ENCODE AZ64
           ,tracking_hid           BIGINT         ENCODE RAW
           ,source_last_modified timestamp      ENCODE AZ64
        );

        --Determine all events after delta.end and re-use them in the #tracking_id_events table.
        --Directly into temp table.
        INSERT INTO #tracking_id_events
            WITH reprocess AS (
                SELECT
                    ti_barcode_hid
                  , MIN(ti_valid_to_dt) as evt_reeval_ts--take earliest end date and recalculate all intervals after this date.
                FROM
                    ldwh_postal_export_pre_model.dim_tracking_interval_staging a
                WHERE
                    a.ti_dml_action = 'u'
                GROUP BY
                    ti_barcode_hid
            )
            SELECT
                --  r.evt_reeval_ts,
                  ev.barcode_hid
                , ev.barcode_bk
                , ev.scan_bk_ts                                          AS scan_ts
                , fnv_hash( ev.scan_bk_ts , fnv_hash( ev.barcode_hid ) ) AS tracking_hid
                , ev.cleansed_incremental_ts                             AS source_last_modified
            FROM
                reprocess r
                INNER JOIN ldwh_postal_export_pre_model.mf_postal_domain_qualifier ev ON
                        r.ti_barcode_hid  = ev.barcode_hid
                    AND ev.scan_bk_ts    > r.evt_reeval_ts;

        GET DIAGNOSTICS _VAR_inserts := ROW_COUNT; _VAR_TS := ( SELECT admin.f_getdatetime_minutes() ||':' );
        RAISE INFO '%  % rows inserted in #tracking_id_events for CORRECTION', _VAR_TS, _VAR_inserts;


    EXCEPTION WHEN OTHERS THEN RAISE EXCEPTION 'Error %, State %', SQLERRM, SQLSTATE;
END
$$;

