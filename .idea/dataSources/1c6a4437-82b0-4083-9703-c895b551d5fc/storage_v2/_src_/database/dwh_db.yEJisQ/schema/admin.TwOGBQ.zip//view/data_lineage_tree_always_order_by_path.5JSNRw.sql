CREATE VIEW admin.data_lineage_tree_always_order_by_path AS
WITH
    lineage AS (SELECT DISTINCT
                    --ro.endpoint_obj_id
                    REPLICATE(' | ', lvl) || o.obj_name AS lineage_tree_leaf
                  , ep.obj_name                         AS endpoint_table
                  , o.obj_name
                  , ro.lvl
                  , ro.path
                  , ro.cycle
                FROM
                    admin.data_lineage_tree_raw ro
                        INNER JOIN admin.permanent_lineage_objects o ON ro.obj_sid = o.obj_sid
                        INNER JOIN admin.permanent_lineage_objects ep ON ro.endpoint_obj_id = ep.obj_sid
                WHERE 1 = 1
                --AND endpoint_table = 'admin.data_lineage_tree_raw (table)'
                --AND lvl < 5
                ORDER BY path
        --and endpoint_table ilike '%lineage%'
    )
--SELECT DISTINCT endpoint_table FROM lineage ORDER BY path
SELECT *
FROM
    lineage
--where endpoint_table = 'ldwh_postal_export.fact_edi_postal_qualifier (table)'
ORDER BY
    path
WITH NO SCHEMA BINDING;

ALTER TABLE data_lineage_tree_always_order_by_path
    OWNER TO lannguyen;

