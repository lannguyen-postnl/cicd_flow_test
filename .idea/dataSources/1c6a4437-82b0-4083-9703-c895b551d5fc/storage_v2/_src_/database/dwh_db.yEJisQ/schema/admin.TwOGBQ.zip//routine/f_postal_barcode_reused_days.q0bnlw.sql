CREATE FUNCTION f_postal_barcode_reused_days() RETURNS smallint
    IMMUTABLE
    LANGUAGE sql
AS
$$ select 300::int2 $$;

