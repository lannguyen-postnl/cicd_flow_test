CREATE FUNCTION f_barcode_is_untracked(barcode_bk character varying) RETURNS boolean
    IMMUTABLE
    LANGUAGE sql
AS
$$
  select case when upper(left($1, 1)::char(1)) in ('U','A') then true else false end as is_untracked
$$;

