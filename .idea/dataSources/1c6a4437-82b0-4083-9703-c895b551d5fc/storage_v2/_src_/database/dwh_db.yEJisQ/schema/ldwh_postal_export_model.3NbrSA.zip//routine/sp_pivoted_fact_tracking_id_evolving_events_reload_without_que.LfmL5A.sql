CREATE PROCEDURE sp_pivoted_fact_tracking_id_evolving_events_reload_without_que(_init_ts timestamp without time zone)
    LANGUAGE plpgsql
AS
$$
DECLARE
   _REC_duplicates 			RECORD;
   _VAR_inserts				INT:= 0;
   _VAR_query_id            INT;
BEGIN
	--insert statements
	--make sure que is refilled for fact table:
    insert into ldwh_postal_export_pre_model.integration_pivot_que_tracking_hid select tracking_hid from ldwh_postal_export_model.pivoted_fact_tracking_id_evolving_events;
    raise info 'refill que for current state';

    --truncate fact table/target
    truncate ldwh_postal_export_model.pivoted_fact_tracking_id_evolving_events;
    raise info 'truncate ldwh_postal_export_model.pivoted_fact_tracking_id_evolving_events';

    --call to formally recalculate without reloading dependencies:
    raise info 'start flush and fill: ldwh_postal_export_model.pivoted_fact_tracking_id_evolving_events';
    call ldwh_postal_export_model.sp_pivoted_fact_tracking_id_evolving_events(_init_ts);

END;
$$;

