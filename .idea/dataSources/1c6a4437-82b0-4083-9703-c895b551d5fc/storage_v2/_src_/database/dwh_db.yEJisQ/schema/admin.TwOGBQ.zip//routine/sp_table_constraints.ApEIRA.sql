CREATE PROCEDURE sp_table_constraints()
    LANGUAGE plpgsql
AS
$$
DECLARE
    r_constraint RECORD;
BEGIN
    TRUNCATE TABLE admin.table_constraints;

    FOR r_constraint IN
        select
              constraint_schema
            , table_name
            , constraint_name
            , constraint_type
            , column_name
            , ordinal_position
        from
            admin.v_key_column_usage
        where
            constraint_catalog = 'dwh_db'

            --Start of loop insert into admin.sproc_ddl_analysis
        LOOP
            EXECUTE
            ' INSERT INTO admin.table_constraints VALUES ('
                   || QUOTE_LITERAL(r_constraint.constraint_schema)
            || ',' || QUOTE_LITERAL(r_constraint.table_name)
            || ',' || QUOTE_LITERAL(r_constraint.constraint_name)
            || ',' || QUOTE_LITERAL(r_constraint.constraint_type)
            || ',' || QUOTE_LITERAL(r_constraint.column_name)
            || ',' || QUOTE_LITERAL(r_constraint.ordinal_position)
            || ')';
        END LOOP;
    RAISE INFO 'Completed constraint extraction to worker-node';

END
$$;

