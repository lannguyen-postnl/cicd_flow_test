CREATE VIEW v_table_list
            (table_catalog, table_schema, table_name, table_type, self_referencing_column_name, reference_generation,
             user_defined_type_catalog, user_defined_type_schema, user_defined_name)
AS
SELECT
    CURRENT_DATABASE()::information_schema.sql_identifier                      AS table_catalog
  , nc.nspname::information_schema.sql_identifier                              AS table_schema
  , c.relname::information_schema.sql_identifier                               AS table_name
  , CASE
        WHEN nc.nspname ~~ like_escape('pg!_temp!_%'::character varying::text, '!'::character varying::text)
            THEN 'LOCAL TEMPORARY'::character varying
        WHEN c.relkind = 'r'::"char" THEN 'BASE TABLE'::character varying
        WHEN c.relkind = 'v'::"char" THEN 'VIEW'::character varying
        ELSE NULL::character varying
        END::information_schema.character_data                                 AS table_type
  , NULL::information_schema.sql_identifier::information_schema.sql_identifier AS self_referencing_column_name
  , NULL::information_schema.character_data::information_schema.character_data AS reference_generation
  , NULL::information_schema.sql_identifier::information_schema.sql_identifier AS user_defined_type_catalog
  , NULL::information_schema.sql_identifier::information_schema.sql_identifier AS user_defined_type_schema
  , NULL::information_schema.sql_identifier::information_schema.sql_identifier AS user_defined_name
FROM
    pg_namespace nc
  , pg_class c
  , pg_user u
WHERE c.relnamespace = nc.oid AND u.usesysid = c.relowner AND (c.relkind = 'r'::"char" OR c.relkind = 'v'::"char");

ALTER TABLE v_table_list
    OWNER TO lannguyen;

