CREATE PROCEDURE sp_sproc_ddl_declared_variables()
    LANGUAGE plpgsql
AS
$$
BEGIN

    TRUNCATE admin.sproc_ddl_declared_variables;

    INSERT INTO admin.sproc_ddl_declared_variables
        WITH regex AS (
            SELECT
                  pg_proc_oid
                , schema_name
                , sproc_name
                , REGEXP_REPLACE(sql_to_analyze, ' REDACTED_COMMENT ', '')                   AS remove_comment_txt
                , REGEXP_REPLACE(
                    remove_comment_txt
                    , '^(?s)(.*?)declare'
                    , 'REDACTED_BEFORE_DECLARE '
                    , 0, 'p'
                )                                                                            AS redacted_before_declare
                , REGEXP_REPLACE(
                    redacted_before_declare
                    , '(begin)(?s)(.*$)'
                    , 'REDACTED_AFTER_BEGIN '
                    , 0, 'p'
                )                                                                            AS redacted_after_begin
                , REGEXP_REPLACE(redacted_after_begin, '\\s+', ' ', 0, 'p')::varchar(max)    AS spaces_to_space
                --last_step:
                , spaces_to_space as last_regexp
                --counts:
                , REGEXP_COUNT(last_regexp, ';') AS var_count
                , REGEXP_COUNT(last_regexp, 'declare', 1, 'i')                               AS number_of_declares
                , sql_original
          FROM
              admin.sproc_ddl_analysis
          WHERE
              1 = 1
        )
        SELECT
            r.pg_proc_oid
          , r.schema_name || '.' || r.sproc_name                        AS proc_qualified_name
          , i.number                                                    AS var_order
          , r.var_count                                                 AS var_count
          , REGEXP_SUBSTR(
                   last_regexp
                , '((?<=REDACTED_BEFORE_DECLARE\\s)(.*?)(?=;))|((?<=;\\s)(.*?)(?=;))'
                , /* position: */  1, /* occurrence: */ i.number,/*parameter*/ 'p'
            )::varchar                                                  AS full_var_declaration
          , SPLIT_PART(full_var_declaration, ' ', 1)                    AS var_name
          , replace(SPLIT_PART(full_var_declaration, ' ', 2),':=','')   AS var_datatype
          , r.last_regexp                                               AS sql_to_analyze

        FROM
            regex r
            LEFT JOIN admin.integer i ON i.number <= r.var_count and i.number > 0
        WHERE 1=1
            -- small unit test: case when number_of_declares = 1 and var_count = 0 then true else false end AS empty_declare_found
            AND var_count >= 1
    ;
    RAISE INFO 'refreshed: admin.sproc_ddl_declared_variables';

    --https://stackoverflow.com/questions/44611824/regex-to-return-the-word-before-the-match

--word before match:
--regexp: word (\w+) before (?=) 1 or more spaces (\s+) and the match: \w(?=\s+MATCH
--regexp: (redshift language adjustment): \\w(?=\\s+MATCH

--word after match (would assume < is smaller than, however regexp works mysteriously after (?<=) MATCH> is ):
--the after match needs to take qualified table names with a dot.
--(?<=Match\s)([\w\.]+)

--cte/irrelevant objects split:

--(1) Gather all non table objects and flag them
--   (a) temptable, cte
--   (b) views should be considered tables with their own sources, but should be marked as a view.
--(2) Gather source info and determine target remove inserts from temp tables (non-table object).
--   (a) sprocs:
--      (1) source name : name of table or view used in from clause or joins (Exlcuding CTE aliases, but NOT excluding tables in the FROM clause from the CTE).
--      (2) sproc name  : stored-procedure name
--      (3) target name : after insert name (Exlcuding inserts in temp tables).
--      unit test naming convention: insert that matches the stored-procedure name except for the sp_ part or the '_barcodeless' part.
--   (b) views:
--(3) Gather all non table objects.
END;
$$;

