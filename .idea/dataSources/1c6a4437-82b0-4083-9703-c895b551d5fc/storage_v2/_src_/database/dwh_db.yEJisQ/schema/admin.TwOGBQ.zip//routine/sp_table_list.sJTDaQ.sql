CREATE PROCEDURE sp_table_list()
    LANGUAGE plpgsql
AS
$$
DECLARE
    r_table RECORD;
BEGIN
    TRUNCATE TABLE admin.table_list;

    FOR r_table IN
        SELECT
             table_catalog as table_database
            , table_schema
            , table_name
            , table_type
        FROM
            admin.v_table_list t
        WHERE
              t.table_type = 'BASE TABLE'
          AND t.table_schema NOT IN ('pg_catalog', 'information_schema')

            --Start of loop insert into admin.sproc_ddl_analysis
        LOOP
            EXECUTE
            ' INSERT INTO admin.table_list VALUES ('
                   || QUOTE_LITERAL(r_table.table_database)
            || ',' || QUOTE_LITERAL(r_table.table_schema)
            || ',' || QUOTE_LITERAL(r_table.table_name)
            || ',' || QUOTE_LITERAL(r_table.table_type)
            || ')';
        END LOOP;
    RAISE INFO 'Completed table extraction to worker-node';

END
$$;

