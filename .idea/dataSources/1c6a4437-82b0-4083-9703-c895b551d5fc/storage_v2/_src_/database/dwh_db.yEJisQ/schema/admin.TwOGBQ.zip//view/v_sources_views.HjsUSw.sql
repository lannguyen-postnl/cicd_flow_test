CREATE VIEW admin.v_sources_views AS
WITH
    cte_in_view_ddl AS (SELECT
                            v.pg_view_oid
                          , LTRIM(REGEXP_SUBSTR(v.sql_to_analyze, '(?<=CTE_FLAG\\s)\\s*\\w+', 1, i.number,
                                                'cp')) AS cte_name
                          , cte_count
                          , sql_to_analyze
                        -- ,sql_original
                        FROM
                            admin.view_ddl_analysis v
                                INNER JOIN admin.integer i ON i.number <= v.cte_count AND i.number > 0)

  , view_sources AS (SELECT
                         v.pg_view_oid
                       , v.schema_name
                       , v.schema_name || '.' || v.view_name AS view_qualified_name
                       , i.number                            AS source_order
                       , v.source_count
                       , LTRIM(REGEXP_SUBSTR(v.sql_to_analyze,
                                             '((?<=SOURCE_FLAG\\s)([#*\\w\\.]+)|(?<=SOURCE_FLAG\\s''\\s\\|\\|\\s)([#*\\w\\.]+))|(?<=SOURCE_FLAG)\\s[\\w]+."[\\s\\w]+"' --''((?<=SOURCE_FLAG\\s)([#*\\w\\.]+)|(?<=SOURCE_FLAG\\s''''\\s\\|\\|\\s)([#*\\w\\.]+))''
        , /* position: */ 1
        , /* occurrence: */ i.number
        ,/*parameter*/ 'p'
        ))                                                   AS source
                       , v.sql_to_analyze
                       , v.sql_original
                     FROM
                         admin.view_ddl_analysis v
                             LEFT JOIN admin.integer i ON i.number <= v.source_count AND i.number > 0)
--counting the sources sometimes they are called multiple times. Especially in system/admin views:
SELECT
    v.pg_view_oid
  , v.view_qualified_name
    --, v.source
  , CASE
        WHEN REGEXP_COUNT(source, '\\.') < 1 AND source LIKE 'pg_%' THEN 'pg_catalog.' || source
        WHEN REGEXP_COUNT(source, '\\.') < 1 AND cte.cte_name IS NULL --when a match is found for CTE no  qualified name with schema is needed.
            THEN v.schema_name || '.' || source
        ELSE source
        END                                                AS source_name
  , CASE
        WHEN cte.cte_name IS NOT NULL THEN 'CTE'
        WHEN a.view_name IS NOT NULL THEN 'VIEW'
        ELSE 'TABLE'
        END                                                AS source_type
  , CASE WHEN source_type = 'CTE' THEN TRUE ELSE FALSE END AS is_impermanent_obj
  , COUNT(*)                                               AS times_called
    --metadata parsed:
  , v.sql_to_analyze
  , v.sql_original
FROM
    view_sources v
        LEFT JOIN cte_in_view_ddl cte ON v.pg_view_oid = cte.pg_view_oid AND cte.cte_name = source
        LEFT JOIN admin.view_ddl_analysis a ON v.source = a.schema_name || '.' || a.view_name
GROUP BY
    v.pg_view_oid
  , v.view_qualified_name
  , v.schema_name
  , v.source
  , cte.cte_name
  , source_type
    --metadata parsed:
  , v.sql_to_analyze
  , v.sql_original
WITH NO SCHEMA BINDING;

ALTER TABLE v_sources_views
    OWNER TO lannguyen;

