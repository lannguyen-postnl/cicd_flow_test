CREATE PROCEDURE sp_mf_start_leg_2_consignment_de(_init_ts timestamp without time zone)
    LANGUAGE plpgsql
AS
$$

DECLARE
   _VAR_processed			INT:= 0;
   _VAR_incremental_ts      timestamp;
   _VAR_current_ts          varchar:=current_timestamp;
BEGIN
    --assign incremental_ts
    IF _init_ts = '9999-12-31' THEN
        _VAR_incremental_ts := (SELECT COALESCE(MAX(last_modified_ts), '2022-01-01') FROM dwh_db.ldwh_postal_export_pre_model.mf_start_leg_2_consignment_de);
    ELSE
        _VAR_incremental_ts := _init_ts;
        TRUNCATE dwh_db.ldwh_postal_export_pre_model.mf_start_leg_2_consignment_de;
        RAISE INFO '% - Truncated table dwh_db.ldwh_postal_export_pre_model.mf_start_leg_2_consignment_de for initial load', _VAR_current_ts;

    END IF;
    RAISE INFO '% - Max partition date of previous load of target table: %', _VAR_current_ts, _VAR_incremental_ts;

    --insert statements
    INSERT INTO dwh_db.ldwh_postal_export_pre_model.mf_start_leg_2_consignment_de
    SELECT
        --Keys
        cse.consgnt_pid_hid
        , cs.consgnt_fid_hid
        , cs.consgnt_fid                                            AS consgnt_bk
        , cf.milestone_index_sequence_id
        --Tracked Properties
        , cf.scan_value_bk
        , DATEADD(HOUR, cse.event_local_offset, cse.event_gmt_dt)   AS scan_bk_ts
        , LEFT(cs.dest_location_fcd, 2)                             AS dest_country_code_bk
        --Metadata
        , cse.s3_evt_partition_ts                                   AS event_s3_partition_ts
        , GETDATE()                                                 AS last_modified_ts
    FROM
        --Milestone configuration file:
        dwh_db.ldwh_postal_export_pre_model.config_milestone_postal_export cf
--         dwh_db.ldwh_postal_export_pre_model.config_milestone cf
        -- Match milestone on Source-list based on primary source and additional sources in the list:
        INNER JOIN ingest_db.cleanse_ips_nationals.l_consgnt_events_with_fid cse    ON cf.scan_value_bk = cse.event_type_cd
            AND cf.milestone_name_bk = 'start leg 2 local-ops [consignment]'
            AND cf.source_name_list_bk = 'cleanse_ips_nationals.l_consignment_events'
            AND DATEADD(HOUR, cse.event_local_offset, cse.event_gmt_dt) >= cf.valid_from_dt
            AND DATEADD(HOUR, cse.event_local_offset, cse.event_gmt_dt) <= cf.valid_to_dt
        LEFT JOIN ingest_db.cleanse_ips_nationals.l_consgnts cs ON cse.consgnt_pid_hid = cs.consgnt_pid_hid
    WHERE 1 = 1
        --Incremental variable:
        --Here the variable is valid since to incorporate logic to either run incremental or flush and fill.
        AND cse.last_modified_ts > _var_incremental_ts
--         AND coalesce(cs.consignment_fid_found_ts, cse.s3_partition_ts) > _VAR_incremental_ts -- TODO: Add future adjustment regards the cleanse layer. cs.consignment_fid_found_ts needs to implemented first
        --Filter expression:
        AND cs.dest_location_fcd NOT IN ('NLSPL', 'NLRTM', 'NLMST', 'NLAMS') -- Destination_country <> NL
    ;

   -- After insert steps in procedure add block for count of inserts
   GET DIAGNOSTICS _VAR_processed := ROW_COUNT; RAISE INFO '% - % rows inserted into dwh_db.ldwh_postal_export_pre_model.mf_start_leg_2_consignment_de', _VAR_current_ts, _VAR_processed;

END;

$$;

