CREATE FUNCTION f_country_of_origin_collo(barcode character varying) RETURNS character
    IMMUTABLE
    LANGUAGE sql
AS
$$
  select substring($1, 12, 2)::char(2) as country_code_origin
$$;

