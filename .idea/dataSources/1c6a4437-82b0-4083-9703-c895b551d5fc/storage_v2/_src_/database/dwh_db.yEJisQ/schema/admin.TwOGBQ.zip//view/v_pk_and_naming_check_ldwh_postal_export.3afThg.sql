CREATE VIEW v_pk_and_naming_check_ldwh_postal_export
            (table_schema, table_name, pk_found, pk_check_found_in_sproc, sproc_name, pk_number_of_columns,
             pk_columns) AS
SELECT
    t.table_schema
  , t.table_name
  , CASE
        WHEN c.pk_number_of_columns IS NOT NULL THEN TRUE
        ELSE FALSE
        END                                                                                      AS pk_found
  , s.is_found_in_sproc_sp_check_table_name                                                      AS pk_check_found_in_sproc
  , COALESCE(s.sproc_name, 'naming conventions sp_<$table-name> not correct'::character varying) AS sproc_name
  , c.pk_number_of_columns
  , c.pk_columns
FROM
    "admin".table_list t
        LEFT JOIN "admin".v_primary_key_table_info c
                  ON t.table_schema::text = c.pk_schema::text AND t.table_name::text = c.pk_table::text
        LEFT JOIN (SELECT
                       "right"(sproc_ddl_analysis.sproc_name::text,
                               LEN(sproc_ddl_analysis.sproc_name::text) - 3) AS table_name_derived_from_sproc
                     , sproc_ddl_analysis.schema_name                        AS sproc_schema_name
                     , sproc_ddl_analysis.sproc_name
                     , CASE
                           WHEN sproc_ddl_analysis.sql_original::text ~~*
                                '%admin.sp_check_table_name%'::character varying::text THEN TRUE
                           ELSE FALSE
                           END                                               AS is_found_in_sproc_sp_check_table_name
                   FROM
                       "admin".sproc_ddl_analysis
                   WHERE sproc_ddl_analysis.sproc_name::text ~~* 'sp_%'::character varying::text) s
                  ON t.table_schema::text = s.sproc_schema_name::text AND
                     t.table_name::text = s.table_name_derived_from_sproc
WHERE t.table_type::text = 'BASE TABLE'::character varying::text
  AND t.table_schema::text <> 'pg_catalog'::character varying::text
  AND t.table_schema::text <> 'information_schema'::character varying::text AND
        t.table_schema::text = 'ldwh_postal_export_pre_model'::character varying::text;

ALTER TABLE v_pk_and_naming_check_ldwh_postal_export
    OWNER TO lannguyen;

