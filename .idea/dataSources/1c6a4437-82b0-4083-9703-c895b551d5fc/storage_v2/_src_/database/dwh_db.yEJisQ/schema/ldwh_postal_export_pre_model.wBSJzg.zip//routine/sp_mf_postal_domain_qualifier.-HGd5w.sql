CREATE PROCEDURE sp_mf_postal_domain_qualifier(_init_ts timestamp without time zone)
    LANGUAGE plpgsql
AS
$$

DECLARE
    _VAR_current_ts                 varchar:= current_timestamp;
    _VAR_incremental_ts_local       timestamp;
    _VAR_incremental_ts_external    timestamp;
    _VAR_inserts		            INT:= 0;
BEGIN
    IF _init_ts = '9999-12-31' THEN
        _VAR_incremental_ts_local   := (SELECT coalesce( MAX(cleansed_incremental_ts),'2021-01-01' )::timestamp
                                    FROM ldwh_postal_export_pre_model.mf_postal_domain_qualifier
                                    WHERE source_name_list_sid = (select distinct source_name_list_sid from ldwh_postal_export_pre_model.config_domain_qualifier_postal_export
                                                                    where source_name_list_bk = '{cleanse_ips_nationals.l_mailitm_events; cleanse_ips_nationals.l_mailitms}'));

        _VAR_incremental_ts_external := (SELECT coalesce( MAX(cleansed_incremental_ts),'2021-01-01' )::timestamp
                                      FROM ldwh_postal_export_pre_model.mf_postal_domain_qualifier
                                      WHERE source_name_list_sid = (select distinct source_name_list_sid from ldwh_postal_export_pre_model.config_domain_qualifier_postal_export
                                                                    where source_name_list_bk = '{cleanse_ips_nationals.n_edi_mailitm_events; cleanse_ips_nationals.n_edi_mailitms}'));
        --todo: create two cols for incremental load s3_source_n_edi and s3_source_l, or find a way to write the above better.......
    ELSE
        _VAR_incremental_ts_local := _init_ts;
        _VAR_incremental_ts_external := _init_ts;

        TRUNCATE ldwh_postal_export_pre_model.mf_postal_domain_qualifier;

            -- tracking interval should be truncated if the input is truncated because it uses the last modified ts:
            TRUNCATE ldwh_postal_export_pre_model.dim_tracking_interval;

        RAISE INFO '% - Truncated table ldwh_postal_export_pre_model.mf_postal_domain_qualifier for initial load', _var_current_ts;
    END IF;

    RAISE INFO '% - Max partition date of previous load of target table. Local %; External %', _VAR_current_ts, _VAR_incremental_ts_local, _VAR_incremental_ts_external;

    INSERT INTO dwh_db.ldwh_postal_export_pre_model.mf_postal_domain_qualifier
        WITH local_domain_qualifier as (
            SELECT
                -- grain
                 evt.mailitm_fid_bk                                       AS barcode_bk
                , COALESCE(evt.mailitm_fid_hid, -1)                       AS barcode_hid
                -- hashed keys
                , evt.mailitm_pid_hid                                     AS barcode_pid_hid
                -- attributes
                , evt.dest_country_cd
                , cf.scan_value_bk
                , DATEADD(HOUR, evt.event_local_offset, evt.event_gmt_dt) AS scan_bk_ts
                , cf.domain_qualifier_mapping_sid
                , cf.domain_qualifier_index_sequence_id
                -- partition date
                , evt.last_modified_ts                                    AS cleansed_incremental_ts
                -- meta data
                , cf.source_name_list_sid
                , GETDATE()                                               AS last_modified_ts
            FROM
                ldwh_postal_export_pre_model.config_domain_qualifier_postal_export cf
                INNER JOIN ingest_db.cleanse_ips_nationals.l_mailitm_events_with_fid evt ON cf.scan_value_bk::int2 = evt.event_type_cd
                        AND cf.domain_qualifier_name_bk = 'internal postal qualifier (ips) [barcode]'
                        --valid from logic for config:
                        AND DATEADD(HOUR, evt.event_local_offset, evt.event_gmt_dt) >= cf.valid_from_dt
                        AND DATEADD(HOUR, evt.event_local_offset, evt.event_gmt_dt) <= cf.valid_to_dt
            WHERE 1=1
                --incremental load column, this is referential issue
                AND evt.mailitm_fid_found is true
                AND evt.last_modified_ts > _VAR_incremental_ts_local
        )

        , external_domain_qualifier as (
            SELECT
                -- grain
                 evt.mailitm_fid_bk                       AS barcode_bk
                , COALESCE(evt.mailitm_fid_hid, -1)       AS barcode_hid
                -- hashed keys
                , evt.mailitem_pid_hid                    AS barcode_pid_hid
                -- attributes
                , evt.dest_country_cd
                , cf.scan_value_bk
                , evt.event_local_dt                      AS scan_bk_ts
                , cf.domain_qualifier_mapping_sid
                , cf.domain_qualifier_index_sequence_id
                -- partition date
                , evt.last_modified_ts                    AS cleansed_incremental_ts
                -- meta data
                , cf.source_name_list_sid
                , GETDATE()                               AS last_modified_ts
            FROM
                ldwh_postal_export_pre_model.config_domain_qualifier_postal_export cf
                INNER JOIN ingest_db.cleanse_ips_nationals.n_edi_mailitm_events_with_fid evt ON cf.scan_value_bk::int2 = evt.event_type_cd
                    AND cf.domain_qualifier_name_bk = 'external postal qualifier (ips) [barcode]'
                    AND evt.event_local_dt >= cf.valid_from_dt
                    AND evt.event_local_dt <= cf.valid_to_dt
            WHERE 1=1
                --incremental load column, this is referential issue
                AND evt.mailitm_fid_found is true
                AND evt.last_modified_ts > _VAR_incremental_ts_external
    )
    SELECT * FROM local_domain_qualifier

    UNION ALL

    SELECT * FROM external_domain_qualifier
    ;

    GET DIAGNOSTICS _VAR_inserts := ROW_COUNT;

    RAISE INFO '% - Total % rows inserted into dwh_db.ldwh_postal_export_pre_model.mf_postal_domain_qualifier', _VAR_current_ts, _VAR_inserts;


END

$$;

