CREATE PROCEDURE sp_dim_scan()
    LANGUAGE plpgsql
AS
$$
BEGIN
    CREATE TABLE #dim_scan ( LIKE ldwh_postal_export_pre_model.dim_scan );

    INSERT INTO #dim_scan
        WITH sid_and_dml_calculation AS (
                SELECT
                    --bk:
                         src.scan_value_bk
                    --properties to check for deltas:
                        ,src.scan_description
                        ,src.scan_datatype
                        ,src.scan_source_application_name
                    --metadata:
                        ,getdate() as last_modified_ts
                    --dml_action:
                        ,case
                            when tar.scan_value_bk is null                          then 'i' --insert
                            when src.scan_value_bk is null and tar.last_dml_action <> 'd' then 'd' --delete
                            when tar.scan_value_bk = src.scan_value_bk AND (
                                 --Tracked columns (that should update while keeping SID):
                                    src.scan_description <> tar.scan_description
                                 OR src.scan_datatype    <> tar.scan_datatype
                                 OR src.scan_source_application_name <> tar.scan_source_application_name
                                 --soft delete update:
                                 OR tar.last_dml_action  = 'd'
                            )
                                then 'u' --update
                                else 'n' --nothing
                        end as last_dml_action
                    --sid generation based on calculated aliases:
                   ,case
                        --Check if the mapping exists. If answer is yes then you don't want to generate a new SID. If the answer is no you do and it needs to be higher than the maximum value of the target set:
                        --dummy value
                        when src.scan_value_bk = 'N/A' then -1
                        when src.scan_value_bk = tar.scan_value_bk then tar.scan_sid
                            --group for inserts only so ranking keeps making sense.
                            else dense_rank() OVER ( partition by case when last_dml_action in ('i','u') then 1 else 0 end::int2 order by src.scan_value_bk ) + ( select coalesce( max( tar.scan_sid ), 0) from ldwh_postal_export_pre_model.dim_scan tar )
                   end as scan_sid
                FROM
                    configuration.mdm_scan src
                    FULL OUTER JOIN ldwh_postal_export_pre_model.dim_scan tar ON src.scan_value_bk = tar.scan_value_bk
                )
        SELECT
            scan_sid
          , scan_value_bk
          , scan_description
          , scan_datatype
          , scan_source_application_name
          , last_modified_ts
          , last_dml_action
        FROM
            sid_and_dml_calculation
        WHERE
            last_dml_action in ('i','u','d')
    ;

    --Delete from target everything that is going to be updated or deleted:
    DELETE FROM ldwh_postal_export_pre_model.dim_scan WHERE scan_value_bk IN ( SELECT scan_value_bk FROM #dim_scan WHERE last_dml_action in ('u','d') );

    --Insert Remainder that should be inserted:
    INSERT INTO ldwh_postal_export_pre_model.dim_scan ( SELECT * FROM #dim_scan WHERE last_dml_action in ('i','u','d') );

    --Drop the temp table:
    DROP TABLE #dim_scan;

END;
$$;

