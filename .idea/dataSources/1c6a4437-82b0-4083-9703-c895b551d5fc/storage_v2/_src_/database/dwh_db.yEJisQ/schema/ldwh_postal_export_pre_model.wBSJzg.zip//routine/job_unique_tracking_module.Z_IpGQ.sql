CREATE PROCEDURE job_unique_tracking_module()
    LANGUAGE plpgsql
AS
$$
    DECLARE
        _VAR_inserts    int;      --For RAISE INFO of amount of inserted rows
        _VAR_TS         varchar;  --For RAISE INFO of current datatime
    BEGIN
        --Create staging tables/table vars:
        DROP TABLE IF EXISTS                 #tracking_id_events;
        CREATE TEMPORARY TABLE IF NOT EXISTS #tracking_id_events
        (
            barcode_hid            BIGINT         ENCODE RAW
           ,barcode_bk             VARCHAR(256)   ENCODE lzo --barcode_bk can be removed for performance. Kept it to make troubleshooting easier.
           ,scan_ts                TIMESTAMP      ENCODE AZ64
           ,tracking_hid           BIGINT         ENCODE RAW
           ,source_last_modified   TIMESTAMP      ENCODE AZ64
        );

        _VAR_TS := ( SELECT admin.f_getdatetime_minutes() ||':' );
        RAISE INFO '% Created Staging tables', _VAR_TS;

        --FETCH DELTA'S:
        INSERT INTO #tracking_id_events
            SELECT
                barcode_hid
              , barcode_bk
              , scan_bk_ts                                     AS scan_ts
              , fnv_hash( scan_bk_ts, fnv_hash( barcode_hid) ) AS tracking_hid
              , last_modified_ts
            FROM
                ldwh_postal_export_pre_model.mf_postal_domain_qualifier
            WHERE
                last_modified_ts > ( SELECT coalesce( max( source_last_modified ),'2021-01-01' ) as source_last_modified FROM ldwh_postal_export_pre_model.dim_tracking_interval )
        ;
        IF FOUND = FALSE THEN RAISE INFO 'No deltas found'; EXIT; END IF; -- @derek: Does the above INSERT statement always set FOUND to TRUE, because the source table should never be empty?

        GET DIAGNOSTICS _VAR_inserts := ROW_COUNT; _VAR_TS := ( SELECT admin.f_getdatetime_minutes() ||':' );
        RAISE INFO '% Staging deltas completed:\n% rows inserted in #tracking_id_events', _VAR_TS, _VAR_inserts;

        --DETERMINE DML ACTIONS AND PRE-CALCULATE INTERVALS:
        CALL ldwh_postal_export_pre_model.sp_sta_dim_tracking_interval_dml_action();
        RAISE INFO 'completed staging for tracking interval and dml action';

    COMMIT;

        --RUN CORRECTION FLOW:
        IF ( SELECT CASE WHEN COUNT(*) IS NULL THEN 0 ELSE COUNT(*) END AS c FROM ldwh_postal_export_pre_model.dim_tracking_interval_staging WHERE ti_dml_action = 'u' ) > 0
                THEN
                    --mark exceptions as invalidated, add to be recalculated events to #tracking_id_events:
                    CALL ldwh_postal_export_pre_model.sp_unique_tracking_exception(); RAISE INFO 'Finished unique tracking exception';
                        --recalculate remaining intervals based on new info in #tracking_id_events:
                        CALL ldwh_postal_export_pre_model.sp_sta_dim_tracking_interval_dml_action();

                _VAR_TS := ( SELECT admin.f_getdatetime_minutes() ||':' ); RAISE INFO '% Completed Correction flow', _VAR_TS;
                COMMIT;
            ELSE
                _VAR_TS := ( SELECT admin.f_getdatetime_minutes() ||':' ); RAISE INFO '% No corrections needed'    , _VAR_TS;
        END IF;

        INSERT INTO ldwh_postal_export_pre_model.dim_tracking_interval
            SELECT
               ti_tracking_hid, ti_barcode_hid, ti_barcode_bk, ti_scan_ts, ti_valid_from_dt, ti_valid_to_dt, ti_record_last_modified_ts, ti_record_last_modified_ts, null as invalidation_ts
            FROM
               ldwh_postal_export_pre_model.dim_tracking_interval_staging
            WHERE
               ti_dml_action = 'i'
            ;

        GET DIAGNOSTICS _VAR_inserts := ROW_COUNT; _VAR_TS := ( SELECT admin.f_getdatetime_minutes() ||':' );
        RAISE INFO '% Insert intervals: % rows inserted in #tracking_id_events', _VAR_TS, _VAR_inserts;

        --CLEAN STAGING TABLE:
        TRUNCATE TABLE ldwh_postal_export_pre_model.dim_tracking_interval_staging;

    --EXCEPTION WHEN OTHERS THEN RAISE EXCEPTION 'Error %, State %', SQLERRM, SQLSTATE;
END
$$;

