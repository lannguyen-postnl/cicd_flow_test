CREATE PROCEDURE sp_mf_start_leg_1_tracking_id_de(_init_ts timestamp without time zone)
    LANGUAGE plpgsql
AS
$$

DECLARE
   _VAR_processed			INT:= 0;
   _VAR_incremental_ts      timestamp;
   _VAR_current_ts          varchar:=current_timestamp;
BEGIN
    --assign incremental_ts
    IF _init_ts = '9999-12-31' THEN
        _VAR_incremental_ts := (SELECT COALESCE(MAX(last_modified_ts), '2022-01-01') FROM dwh_db.ldwh_postal_export_pre_model.mf_start_leg_1_tracking_id_de);
    ELSE
        _VAR_incremental_ts := _init_ts;
        TRUNCATE dwh_db.ldwh_postal_export_pre_model.mf_start_leg_1_tracking_id_de;
        RAISE INFO '% - Truncated table dwh_db.ldwh_postal_export_pre_model.mf_start_leg_1_tracking_id_de for initial load', _VAR_current_ts;

    END IF;
    RAISE INFO '% - Max partition date of previous load of target table: %', _VAR_current_ts, _VAR_incremental_ts;

   --insert statements
    INSERT INTO dwh_db.ldwh_postal_export_pre_model.mf_start_leg_1_tracking_id_de
        SELECT
            --Keys
            coalesce(ti.ti_tracking_hid, -1 )                               AS ti_tracking_hid
          , evt.mailitm_fid_bk                                              AS barcode_bk
          , evt.mailitm_pid_hid                                             AS mailitem_pid_hid
          , cf.milestone_index_sequence_id
            --Tracked Properties
          , cf.scan_value_bk
          , DATEADD(HOUR, evt.event_local_offset, evt.event_gmt_dt)         AS scan_bk_ts
          , evt.dest_country_cd                                             AS dest_country_code_bk
            --Metadata
          , evt.s3_evt_partition_ts                                         AS event_s3_partition_ts
          , GETDATE()                                                       AS last_modified_ts
        FROM
            --Milestone configuration file:
            dwh_db.ldwh_postal_export_pre_model.config_milestone_postal_export cf
            INNER JOIN ingest_db.cleanse_ips_nationals.l_mailitm_events_with_fid evt ON cf.scan_value_bk         = evt.event_type_cd
                AND cf.milestone_name_bk   = 'start leg 1 [barcode]'
                AND cf.source_name_list_bk = '{cleanse_ips_nationals.l_mailitm_events; cleanse_ips_nationals.l_mailitms}'
                AND cf.valid_from_dt <= DATEADD(HOUR, evt.event_local_offset, evt.event_gmt_dt)
                AND cf.valid_to_dt   >= DATEADD(HOUR, evt.event_local_offset, evt.event_gmt_dt)
            -- to fetch out the ti_tracking_hid
            INNER JOIN dwh_db.ldwh_postal_export_pre_model.dim_tracking_interval ti    ON evt.mailitm_fid_hid = ti.ti_barcode_hid
            -- the event needs to be within the valid time interval range of an barcode
                AND ti.ti_valid_from_dt <= DATEADD(HOUR, evt.event_local_offset, evt.event_gmt_dt)
                AND ti.ti_valid_to_dt   >= DATEADD(HOUR, evt.event_local_offset, evt.event_gmt_dt)
        WHERE 1=1
            -- This is referential issue
            AND evt.mailitm_fid_found is true
            AND evt.last_modified_ts > _VAR_incremental_ts
            --Filter expression:
            AND evt.dest_country_cd not in ('NL', 'None'); --TODO: None str value in this field, need to see if this have to be fixed in the cleanse layer

   -- After insert steps in procedure add block for count of inserts
   GET DIAGNOSTICS _VAR_processed := ROW_COUNT; RAISE INFO '% - % rows inserted into dwh_db.ldwh_postal_export_pre_model.mf_start_leg_1_tracking_id_de', _VAR_current_ts, _VAR_processed;

END;

$$;

