CREATE FUNCTION f_overlapping_interval(interval_1_start timestamp without time zone, interval_1_end timestamp without time zone, interval_2_start timestamp without time zone, interval_2_end timestamp without time zone) RETURNS boolean
    IMMUTABLE
    LANGUAGE sql
AS
$$
  select
    case
        when $1 <= $4 and $2 >= $3 then TRUE
        else false
  end
$$;

