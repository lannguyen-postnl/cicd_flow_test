CREATE VIEW admin.v_targets_sproc AS
WITH
    target_split AS
        (SELECT
             a.pg_proc_oid
           , a.schema_name
           , a.schema_name || '.' || a.sproc_name AS proc_qualified_name
           , i.number                             AS target_order
           , a.target_count
             --dynamic sql target: (?<=SOURCE_FLAG\\s'\\s\\|\\|\\s)([#*\\w\\.]+) looking for concat ||
             --normal sql target:  (?<=SOURCE_FLAG\\s)([#*\\w\\.]+)
           , REGEXP_SUBSTR(
                     sql_to_analyze
                 , '((?<=TARGET_FLAG\\s)([#*\\w\\.]+)|(?<=TARGET_FLAG\\s''\\s\\|\\|\\s)([#*\\w\\.]+))'
                 , /* position: */ 1
                 , /* occurrence: */ number
                 ,/*parameter*/ 'p'
                 )                                AS target_table
           , REGEXP_COUNT(target_table, '\\.')    AS target_table_dot_count
           , CHARINDEX('.', target_table)         AS first_dot_pos
           , sql_to_analyze
           , sql_original
         FROM
             admin.sproc_ddl_analysis a
                 INNER JOIN admin.integer i ON i.number <= a.target_count
         WHERE 1 = 1
           AND i.number > 0
            --and a.schema_name ='admin'
        )
SELECT DISTINCT--it can happen the same oid is referenced multiple times (although rarely, most relevant for tables with recursive logic).
               s.pg_proc_oid
  ,            s.proc_qualified_name
  ,            REPLACE(s.target_table, '.', '.sp_')                                AS expected_sp_name_based_on_target_table
  ,            CASE
                   WHEN REGEXP_COUNT(target_table, '\\.') < 1 AND io.table_object_type IS NOT NULL--basically no match found in impermanent objects (io).
                       THEN s.schema_name || '.' || target_table
                   WHEN REGEXP_COUNT(target_table, '\\.') = 2
                       THEN RIGHT(target_table, LEN(target_table) - CHARINDEX('.', target_table))
                   ELSE target_table
                   END                                                             AS target_name
  ,            COALESCE(io.table_object_type, 'table')                             AS target_type
  ,            CASE WHEN io.table_object_type IS NOT NULL THEN TRUE ELSE FALSE END AS is_impermanent_obj
  ,            CASE
                   WHEN is_impermanent_obj = TRUE THEN 'Format t.b.d. impermanent obj'
                   WHEN target_table_dot_count = 0 THEN 'Target does not have an explicit schema'
                   WHEN s.proc_qualified_name = expected_sp_name_based_on_target_table THEN 'Format OK'
                   -- schema incorrect
                   -- _unhappy flow, the one from lan should still represent proc_qualified name. So _unhappy is not enough.
                   ELSE 'Reformat SPROC name or add variant to check'
                   END                                                                format_check
  ,            s.sql_to_analyze
  ,            s.sql_original
FROM
    target_split s
        LEFT JOIN admin.sproc_ddl_impermanent_objects io
                  ON s.pg_proc_oid = io.pg_proc_oid AND s.target_table = io.table_object_name
WHERE 1 = 1
ORDER BY
    proc_qualified_name, target_order
WITH NO SCHEMA BINDING;

ALTER TABLE v_targets_sproc
    OWNER TO lannguyen;

