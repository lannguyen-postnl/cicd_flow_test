CREATE VIEW ldwh_postal_export_pre_model.text_interpretation_arnoltation AS
WITH
    within_group_aggregate AS (SELECT
                                   milestone_sid
                                 , milestone_name
                                 , milestone_index_sequence_id
                                 , milestone_index_within_sequence_sort_column
                                 , milestone_index_within_sequence_sort_direction
                                 , '{' || LISTAGG(scan_bk, ', ') || '}' scans
                               FROM
                                   ldwh_postal_export_pre_model.notes_arnold_new_milestone
                               WHERE milestone_sid > 0
                               GROUP BY 1, 2, 3, 4, 5)

  , within_gr AS (SELECT
                      milestone_name
                    , CASE
                          WHEN milestone_index_within_sequence_sort_direction = 'ASC' THEN 'earliest scan found in'
                          ELSE 'latest' END                            AS direction
                    , CASE
                          WHEN milestone_index_sequence_id = 1001 THEN ''
                          ELSE 'if previous group not found then ' END AS group_split_text
                    , milestone_index_sequence_id
                    , scans
                  FROM
                      within_group_aggregate)
--select * from within_gr
--start leg 3 external-ops [barcode]
SELECT
    milestone_name
  , LISTAGG(group_split_text || ' ' || direction || ' ' || scans, ',')
    WITHIN GROUP (ORDER BY milestone_index_sequence_id) AS bla
  , MIN(milestone_index_sequence_id)                       min_seq
  , COUNT(*)
FROM
    within_gr
GROUP BY
    1
ORDER BY
    milestone_name
WITH NO SCHEMA BINDING;

ALTER TABLE text_interpretation_arnoltation
    OWNER TO lannguyen;

