CREATE PROCEDURE job_ddl_analysis()
    LANGUAGE plpgsql
AS
$$
BEGIN
    CALL admin.sp_sproc_ddl_analysis();                     COMMIT; RAISE INFO 'Completed admin.sp_sproc_ddl_analysis';
        CALL admin.sp_sproc_ddl_declared_variables();               RAISE INFO 'Completed admin.sp_sproc_ddl_declared_variables';
        CALL admin.sp_sproc_ddl_arguments();                        RAISE INFO 'Completed admin.sp_sproc_ddl_arguments';
            CALL admin.sp_sproc_ddl_impermanent_objects();  COMMIT; RAISE INFO 'Completed admin.sp_sproc_ddl_impermanent_objects';
    CALL admin.sp_view_ddl_analysis();                              RAISE INFO 'Completed admin.sp_view_ddl_analysis';
        CALL admin.sp_permanent_lineage_objects();                  RAISE INFO 'Completed admin.sp_permanent_lineage_objects';
            CALL admin.sp_lineage_parent_child();           COMMIT; RAISE INFO 'Completed admin.sp_lineage_parent_child';
                CALL admin.sp_data_lineage_tree_raw();      COMMIT; RAISE INFO 'Completed admin.sp_data_lineage_tree_raw';
END;
$$;

