CREATE PROCEDURE job_basic_table_analysis()
    LANGUAGE plpgsql
AS
$$
BEGIN
    CALL admin.sp_table_constraints();
    CALL admin.sp_table_list();
END;
$$;

