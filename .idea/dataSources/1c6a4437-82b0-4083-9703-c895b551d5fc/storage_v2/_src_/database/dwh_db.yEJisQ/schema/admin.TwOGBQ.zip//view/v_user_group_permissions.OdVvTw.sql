CREATE VIEW v_user_group_permissions(username, groupname) AS
SELECT DISTINCT
    use2.usename AS username
  , pu.groname   AS groupname
FROM
    pg_class c
        LEFT JOIN pg_group pu ON ARRAY_TO_STRING(c.relacl, '|'::character varying::text) ~~
                                 (('%'::character varying::text || pu.groname::character varying::text) ||
                                  '%'::character varying::text)
        JOIN pg_user use2 ON ARRAY_TO_STRING(pu.grolist, '|'::character varying::text) ~~
                             (('%'::character varying::text || use2.usesysid::character varying::text) ||
                              '%'::character varying::text)
ORDER BY
    use2.usename;

ALTER TABLE v_user_group_permissions
    OWNER TO lannguyen;

