CREATE PROCEDURE sp_sproc_ddl_arguments()
    LANGUAGE plpgsql
AS
$$
DECLARE
    r_sproc record;
BEGIN

    FOR r_sproc IN
        WITH extract_arguments AS
        (
            SELECT
                  p.oid         AS pg_proc_oid
                , n.nspname     AS schema_name
                , p.proname     AS proc_name
                , p.proargnames AS arg_names
                , p.proargtypes AS arg_types
                , p.pronargs    AS argument_count
                --GENERATE_SERIES and FORMAT_TYPE are postgres/leader node function not officially supported. Really handy though.
                    --TL;DR: I got this info from an aws source though, rewritten it for readability:
                    --https://github.com/awslabs/amazon-redshift-utils/blob/master/src/AdminViews/v_get_stored_proc_params.sql
                , GENERATE_SERIES(1, argument_count) AS argument_order
              FROM
                  pg_proc p
                  INNER JOIN pg_namespace n ON p.pronamespace = n.oid
              WHERE 1=1
                AND prolang = (select oid from pg_language where lanname = 'plpgsql') --could be expanded if we use other languages than sql on redshift.
                AND n.nspname NOT IN ('pg_tables', 'information_schema','pg_catalog')
                AND argument_count > 0
        )
        SELECT
              pg_proc_oid
            , schema_name
            , proc_name
            , argument_order
            , argument_count
            , arg_names[argument_order]                       AS argument_name
            , FORMAT_TYPE(arg_types[argument_order - 1],NULL) AS argument_datatype
        FROM
            extract_arguments

            --Start of loop insert into admin.sproc_ddl_analysis
        LOOP
            EXECUTE ' insert into admin.sproc_ddl_arguments values ('
                       || quote_literal(r_sproc.pg_proc_oid)
                || ',' || quote_literal(r_sproc.schema_name)
                || ',' || quote_literal(r_sproc.proc_name)
                || ',' || quote_literal(r_sproc.argument_order)
                || ',' || quote_literal(r_sproc.argument_count)
                || ',' || quote_literal(r_sproc.argument_name)
                || ',' || quote_literal(r_sproc.argument_datatype)
                || ')';
        END LOOP;
    RAISE INFO 'Completed sproc_ddl_arguments';
END;
$$;

