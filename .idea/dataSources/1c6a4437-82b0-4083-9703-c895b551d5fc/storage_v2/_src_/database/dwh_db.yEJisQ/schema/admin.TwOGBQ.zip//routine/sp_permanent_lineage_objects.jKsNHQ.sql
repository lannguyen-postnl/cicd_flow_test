CREATE PROCEDURE sp_permanent_lineage_objects()
    LANGUAGE plpgsql
AS
$$
BEGIN
    TRUNCATE    admin.permanent_lineage_objects;
    INSERT INTO admin.permanent_lineage_objects
        WITH extract_obj_names AS (
            SELECT DISTINCT
                origin.source                                                             AS obj_name
                ,'s'                                                                      AS lineage_type
            FROM
                admin.v_lineage_parent_child origin
            WHERE 1=1
                AND origin.source_is_self_reference = FALSE
            GROUP BY 1,2

        UNION ALL

            SELECT DISTINCT
                origin.target                                                             AS obj_name
                ,'t'                                                                      AS lineage_type
            FROM
                admin.v_lineage_parent_child origin
            WHERE 1=1
                --Assumption for now: For targets self-references are irrelevant to analyze. They are still valid targets for lineage purposes.
            GROUP BY 1,2
        )
        --SELECT * FROM extract_obj_names/*

        , classify_endpoint_and_root AS (
            SELECT
                 obj_name
                ,listagg(lineage_type, '') as lineage_type_summary
            FROM
                extract_obj_names
            GROUP BY
                obj_name
            ORDER BY
                obj_name, lineage_type_summary
        )
        --SELECT * FROM classify_endpoint_and_root;

        SELECT
            row_number() OVER ( ORDER BY obj_name)                         as obj_sid
            ,obj_name
            ,case when lineage_type_summary = 's' then true else false end as is_root
            ,case when lineage_type_summary = 't' then true else false end as is_endpoint
        FROM
            classify_endpoint_and_root;
END;
$$;

