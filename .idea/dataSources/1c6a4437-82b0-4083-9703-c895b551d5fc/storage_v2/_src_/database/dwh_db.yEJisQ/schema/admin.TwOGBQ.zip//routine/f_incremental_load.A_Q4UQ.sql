CREATE FUNCTION f_incremental_load() RETURNS date
    IMMUTABLE
    LANGUAGE sql
AS
$$
   SELECT '9999-12-31'::date
$$;

