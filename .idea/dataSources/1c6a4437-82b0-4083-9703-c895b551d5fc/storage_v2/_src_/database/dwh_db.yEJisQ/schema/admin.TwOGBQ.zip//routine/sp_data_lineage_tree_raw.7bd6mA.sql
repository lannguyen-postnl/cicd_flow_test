CREATE PROCEDURE sp_data_lineage_tree_raw()
    LANGUAGE plpgsql
AS
$$
DECLARE
    _var_lvl int2 := 0;
BEGIN
    TRUNCATE TABLE admin.data_lineage_tree_raw;

    -- Start of hierarchy:
    INSERT INTO admin.data_lineage_tree_raw
        SELECT
            target_obj_sid as endpoint_obj_id, target_obj_sid as obj_sid, 0 as var_lvl, '.' || target_obj_sid::varchar(10) as path
            ,case when has_self_reference = FALSE then 0 else 1 end as cycle
            ,has_self_reference
        FROM
            admin.lineage_parent_child
        WHERE 1=1
            AND target_is_endpoint = TRUE
            AND has_self_reference = FALSE
        GROUP BY
            target_obj_sid, cycle, has_self_reference
    ;

    --increment the level:
    <<lineage_loop>>
    LOOP
        _var_lvl := _var_lvl + 1;

        INSERT INTO admin.data_lineage_tree_raw
        WITH loop_query AS (
            SELECT
                endpoint_obj_id, C.source_obj_sid as obj_sid, _var_lvl, P.path || '.' || C.source_obj_sid::varchar(10)  AS path
                ,regexp_count(P.path || '.' || C.source_obj_sid::varchar(10), '\\.')  -1               AS lvl_test
                ,CASE WHEN P.path LIKE '%.' || C.target_obj_sid::varchar(10) || '.%' THEN 1 ELSE 0 END AS cycle
                ,p.has_self_reference
            FROM
               admin.data_lineage_tree_raw P
               INNER JOIN admin.lineage_parent_child AS C ON C.target_obj_sid = P.obj_sid
            WHERE 1=1
               AND lvl_test = _var_lvl
               AND P.cycle = 0
               AND C.has_self_reference = FALSE
        )
        --Lvl test is not used in target table the rest is:
        SELECT endpoint_obj_id, obj_sid, _var_lvl, path, cycle, has_self_reference FROM loop_query;

        --Found is system variable that returns FALSE after empty insert.
        EXIT lineage_loop WHEN ( FOUND = FALSE OR _var_lvl = 100 );

        --Determine lvl in loop:
        RAISE INFO 'inserted level % into ', _var_lvl;

    END LOOP;
END;
$$;

