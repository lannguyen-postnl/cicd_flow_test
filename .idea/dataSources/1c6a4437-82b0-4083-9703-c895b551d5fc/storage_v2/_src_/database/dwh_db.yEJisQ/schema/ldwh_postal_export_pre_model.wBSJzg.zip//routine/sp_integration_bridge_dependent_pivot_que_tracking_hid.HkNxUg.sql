CREATE PROCEDURE sp_integration_bridge_dependent_pivot_que_tracking_hid()
    LANGUAGE plpgsql
AS
$$
DECLARE
   _VAR_inserted     	    INT         := 0;
   _VAR_current_ts          varchar     := current_timestamp;
BEGIN
    --Mapping consignment to tracking-hid level:
    INSERT INTO ldwh_postal_export_pre_model.integration_pivot_que_tracking_hid
        SELECT
            b.ti_tracking_hid
        FROM
            ldwh_postal_export_pre_model.integration_pivot_que_consignment_bk_hid c
            --Ti-less consignments are filtered. Maybe this is an issue we could capture with left join near future.
            --Assumption: Because refresh of bridge happens later then consignment load we do not expect this issue to occur.
            inner join ldwh_postal_export_pre_model.integration_bridge b on c.consignment_bk_hid = b.consignment_bk_hid;

    GET DIAGNOSTICS _VAR_inserted := ROW_COUNT; _VAR_current_ts := current_timestamp;
    RAISE INFO 'Fetched % Tracking_hid''s from integration_pivot_que_consignment_bk_hid: %', _VAR_inserted, _VAR_current_ts;

    TRUNCATE ldwh_postal_export_pre_model.integration_pivot_que_consignment_bk_hid;
    RAISE INFO 'Truncated integration_pivot_que_consignment_bk_hid';
END;
$$;

