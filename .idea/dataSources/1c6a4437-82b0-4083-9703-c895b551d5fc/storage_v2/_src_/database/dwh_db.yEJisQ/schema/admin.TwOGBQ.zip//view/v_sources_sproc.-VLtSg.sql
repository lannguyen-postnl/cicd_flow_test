CREATE VIEW admin.v_sources_sproc AS
WITH
    sproc_source_split AS (SELECT
                               a.pg_proc_oid
                             , a.schema_name
                             , a.schema_name || '.' || a.sproc_name AS proc_qualified_name
                             , i.number                             AS source_order
                             , a.source_count
                               --dynamic sql source: (?<=SOURCE_FLAG\\s'\\s\\|\\|\\s)([#*\\w\\.]+) looking for concat ||
                               --normal sql source:  (?<=SOURCE_FLAG\\s)([#*\\w\\.]+)
                             , REGEXP_SUBSTR(
                                       sql_to_analyze
                                   , '((?<=SOURCE_FLAG\\s)([#*\\w\\.]+)|(?<=SOURCE_FLAG\\s''\\s\\|\\|\\s)([#*\\w\\.]+))'
                                   , /* position: */ 1
                                   , /* occurrence: */ number
                                   ,/*parameter*/ 'p'
                                   )                                AS source
                             , sql_to_analyze
                             , sql_original
                           FROM
                               admin.sproc_ddl_analysis a
                                   INNER JOIN admin.integer i ON i.number <= a.source_count
                           WHERE 1 = 1
                             AND i.number > 0)

    --io = impermanent object:
  , io_determination AS (SELECT DISTINCT
                             s.pg_proc_oid
                           , s.schema_name
                           , s.proc_qualified_name
                           , s.source
                             --,io.table_object_name /*matching object in the impermanent objects table.*/
                           , io.table_object_type
                           , CASE WHEN io.table_object_type IS NOT NULL THEN TRUE ELSE FALSE END AS is_impermanent_obj
                             --metadata parsed:
                           , s.sql_to_analyze
                           , s.sql_original
                         FROM
                             sproc_source_split s
                                 LEFT JOIN admin.sproc_ddl_impermanent_objects io
                                           ON (s.pg_proc_oid = io.pg_proc_oid OR io.pg_proc_oid = -1) AND
                                              source = io.table_object_name)
SELECT
    i.pg_proc_oid
  , i.schema_name
  , i.proc_qualified_name
--   , i.source
  , CASE
        WHEN REGEXP_COUNT(i.source, '\\.') < 1 AND i.source LIKE 'pg_%'
            THEN 'pg_catalog.' || i.source
        WHEN REGEXP_COUNT(i.source, '\\.') < 1 AND is_impermanent_obj = FALSE
            THEN i.schema_name || '.' || i.source
        --for now two part naming is standard. Might need to become 3 part to match db names:
        WHEN REGEXP_COUNT(i.source, '\\.') = 2
            THEN RIGHT(i.source, LEN(i.source) - CHARINDEX('.', i.source))
        ELSE
            i.source
        END                                                                                   AS source_name
  , i.is_impermanent_obj
  , COALESCE(i.table_object_type, CASE WHEN v.view_name IS NOT NULL THEN 'view' END, 'table') AS source_type
  , i.sql_to_analyze
  , i.sql_original
FROM
    io_determination i
        LEFT JOIN admin.view_ddl_analysis v ON i.source = v.schema_name || '.' || v.view_name
WITH NO SCHEMA BINDING;

ALTER TABLE v_sources_sproc
    OWNER TO lannguyen;

