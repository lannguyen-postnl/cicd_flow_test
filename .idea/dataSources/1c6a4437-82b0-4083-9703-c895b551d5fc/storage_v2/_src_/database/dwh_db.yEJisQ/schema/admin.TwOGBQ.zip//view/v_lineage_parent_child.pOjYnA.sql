CREATE VIEW admin.v_lineage_parent_child AS
WITH
    lineage_parent_child AS
        (SELECT
             --, coalesce(src.proc_qualified_name,targ.proc_qualified_name) as proc_qualified_name
             source_name || ' (' || LOWER(source_type) || ')' AS source
           , target_name || ' (' || target_type || ')'        AS target
           , src.proc_qualified_name                          AS proc
           , CASE
                 WHEN source_name = target_name THEN 1
                 ELSE 0
                 END                                          AS source_is_self_reference
         --, sql_original
         FROM
             admin.v_sources_sproc src
                 --should target not always be impermanent and not null therefore reverse it after break?
                 FULL OUTER JOIN admin.v_targets_sproc targ ON src.pg_proc_oid = targ.pg_proc_oid
         WHERE 1 = 1
           AND targ.is_impermanent_obj = FALSE
           AND src.is_impermanent_obj = FALSE --impermanent objects are not relevant for this use case.
         UNION
         SELECT
             v.source_name || ' (' || LOWER(source_type) || ')' AS source
           , v.view_qualified_name || ' (view)'                 AS target
           , 'view'                                             AS proc
             --below
           , CASE
                 WHEN source_name = view_qualified_name THEN 1
                 ELSE 0
                 END                                            AS has_self_reference
         FROM
             admin.v_sources_views v
         WHERE is_impermanent_obj = FALSE)
SELECT
    source
  , target
  , proc
    --self reference definition: the targets of the 'same stored procedure' can be found in the sources of the 'same stored procedure' ergo partitioning by proc and source.
  , CASE
        WHEN MAX(source_is_self_reference) OVER (PARTITION BY source, proc) = 1 THEN TRUE
        ELSE FALSE END AS source_is_self_reference
FROM
    lineage_parent_child
    --test:
    --where proc = 'ldwh_postal_export.sp_fact_edi_postal_qualifier'
--GROUP BY 1,2,3
WITH NO SCHEMA BINDING;

ALTER TABLE v_lineage_parent_child
    OWNER TO lannguyen;

