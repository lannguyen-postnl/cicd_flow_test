CREATE PROCEDURE sp_sproc_ddl_impermanent_objects()
    LANGUAGE plpgsql
AS
$$
BEGIN
    TRUNCATE TABLE admin.sproc_ddl_impermanent_objects;

    INSERT INTO admin.sproc_ddl_impermanent_objects
        WITH ddl_analysis_sproc_cte_temptable AS
        (
                SELECT
                         a.pg_proc_oid
                       , a.schema_name || '.' || a.sproc_name                                       AS proc_qualified_name
                       , a.cte_count                                                                AS impermanent_object_count
                       , REGEXP_SUBSTR(a.sql_to_analyze, '(?<=CTE_FLAG\\s)\\w+', 1, i.number, 'cp') AS table_object_name
                       , 'cte'                                                                      AS table_object_type
                       , sql_to_analyze
                 FROM
                     admin.sproc_ddl_analysis a
                     INNER JOIN admin.integer i ON i.number <= a.cte_count
                 WHERE 1 = 1
                   AND i.number > 0

            UNION ALL

                 SELECT
                     a.pg_proc_oid
                   , a.schema_name || '.' || a.sproc_name                                                         AS proc_qualified_name
                   , a.create_temp_table_count                                                                    AS impermanent_object_count
                   , REGEXP_SUBSTR(a.sql_to_analyze, '(?<=CREATE_TEMP_TABLE_FLAG\\s)[#]?\\w+', 1, i.number, 'cp') AS table_name
                   , 'temp table'                                                                                 AS table_object_type
                   , sql_to_analyze
                 FROM
                     admin.sproc_ddl_analysis a
                     INNER JOIN admin.integer i ON i.number <= a.create_temp_table_count
                 WHERE 1 = 1
                   AND i.number > 0

            UNION ALL

                SELECT
                    dv.pg_proc_oid
                  , dv.proc_qualified_name
                  , dv.var_count            AS impermanent_object_count
                  , dv.var_name             AS table_object_name
                  , 'variable'              AS table_object_type
                  , dv.sql_to_analyze
                FROM
                    admin.sproc_ddl_declared_variables dv

            UNION ALL

                SELECT
                    ar.pg_proc_oid
                  , ar.proc_schema_name || '.' || ar.proc_name  AS proc_qualified_name
                  , ar.argument_count                           AS impermanent_object_count
                  , ar.argument_name                            AS table_object_name
                  , 'argument'                                  AS table_object_type
                  , 'extracted from metadata tables (not part of DDL saved in pg_sproc): ' || argument_datatype as sql_to_analyze
                FROM
                    admin.sproc_ddl_arguments ar

            UNION ALL

            --externally generated temp table (pk check only exception to date:
                SELECT
                    -1                                                      AS pg_proc_oid
                    ,'nested administrative sproc: admin.sp_pk_check_table\n result table of duplicates check' AS proc_qualified_name
                    ,1                                                      AS impermanent_object_count
                    ,'#sp_pk_check_table'                                   AS table_object_name
                    ,'admin temp table'                                     AS table_object_type
                    ,'check ddl parent caller'                              AS sql_to_analyze

        )
        SELECT * FROM ddl_analysis_sproc_cte_temptable;
END
$$;

