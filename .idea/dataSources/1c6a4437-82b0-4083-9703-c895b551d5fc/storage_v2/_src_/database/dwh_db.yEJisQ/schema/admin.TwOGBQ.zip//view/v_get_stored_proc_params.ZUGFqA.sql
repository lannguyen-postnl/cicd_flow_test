CREATE VIEW v_get_stored_proc_params(schema_name, proc_name, proc_id, "order", parameter, data_type) AS
SELECT
    n.nspname                                         AS schema_name
  , p.proname                                         AS proc_name
  , p.oid::integer                                    AS proc_id
  , a.arg_num                                         AS "order"
  , COALESCE(a.arg_name, ''::character varying::text) AS parameter
  , FORMAT_TYPE(a.arg_type, NULL::integer)            AS data_type
FROM
    pg_proc p
        LEFT JOIN pg_namespace n ON n.oid = p.pronamespace
        LEFT JOIN (SELECT
                       t.oid
                     , t.arg_num
                     , t.arg_names[t.arg_num]     AS arg_name
                     , t.arg_types[t.arg_num - 1] AS arg_type
                   FROM
                       (SELECT
                            GENERATE_SERIES(1, t.arg_count::integer) AS arg_num
                          , t.arg_names
                          , t.arg_types
                          , t.oid
                        FROM
                            (SELECT
                                 pg_proc.oid
                               , pg_proc.proargnames AS arg_names
                               , pg_proc.proargtypes AS arg_types
                               , pg_proc.pronargs    AS arg_count
                             FROM
                                 pg_proc
                             WHERE pg_proc.proowner <> 1 AND pg_proc.prolang = 100356::oid) t) t) a ON a.oid = p.oid
WHERE p.proowner <> 1 AND p.prolang = 100356::oid
ORDER BY
    n.nspname, p.proname, p.oid::integer, a.arg_num;

ALTER TABLE v_get_stored_proc_params
    OWNER TO lannguyen;

