CREATE PROCEDURE sp_sta_dim_tracking_interval_dml_action()
    LANGUAGE plpgsql
AS
$$
   DECLARE
        _VAR_inserts    int;      --For RAISE INFO of amount of inserted rows
        _VAR_deletes    int;      --For RAISE INFO of amount of deleted rows
        _VAR_TS         varchar;  --For RAISE INFO of current datatime
        _VAR_iterable   int := 1; --For RAISE INFO about amounts of loops the functions goes through to insert into ldwh.dim_tracking_interval
    BEGIN
    --Create staging table for events part 1, receives delete instructions from the loop:

        --below table is normally created in unique tracking module.
        CREATE TEMPORARY TABLE IF NOT EXISTS #tracking_id_events
        (
            barcode_hid          BIGINT         ENCODE RAW
           ,barcode_bk           VARCHAR(256)   ENCODE lzo
           ,scan_ts              TIMESTAMP      ENCODE AZ64
           ,tracking_hid         BIGINT         ENCODE RAW
           ,source_last_modified TIMESTAMP      ENCODE AZ64
        );

        --Create staging table for the interval calculations in the loop part 2:
        DROP TABLE IF EXISTS   #mark_tracking_interval;
        CREATE TEMPORARY TABLE IF NOT EXISTS #mark_tracking_interval
        (
            barcode_hid            BIGINT         ENCODE RAW
           ,barcode_bk             VARCHAR(256)   ENCODE lzo
           ,scan_ts                TIMESTAMP      ENCODE az64
           ,tracking_hid           BIGINT         ENCODE RAW
           ,row_nr                 INT2           ENCODE az64
           ,first_item_group       BOOLEAN
           ,source_last_modified TIMESTAMP
           --,is_last_interval       BOOLEAN        ENCODE RAW
       )
       DISTKEY ( barcode_hid ) SORTKEY ( barcode_hid, scan_ts );

       _VAR_TS := ( SELECT admin.f_getdatetime_minutes() ||':' ); RAISE INFO '% Created Staging tables', _VAR_TS;

       RAISE INFO 'Start Loop:';
          LOOP
              --Start Loop:
              RAISE INFO 'Start Run: %', _VAR_iterable;

              --Calculate intervals per iteration:
              INSERT INTO #mark_tracking_interval
                  SELECT
                      barcode_hid
                    , barcode_bk
                    , scan_ts
                    , tracking_hid
                    , ROW_NUMBER() OVER ( PARTITION BY barcode_hid ORDER BY scan_ts ) AS row_nr
                    , CASE
                        WHEN datediff(
                                 d
                                , min(scan_ts) OVER ( PARTITION BY barcode_hid )
                                , scan_ts
                             )   <= admin.f_postal_barcode_reused_days()
                            THEN TRUE ELSE FALSE
                    END AS first_item_group
                    ,source_last_modified
                  FROM
                    #tracking_id_events
                  ORDER BY
                    barcode_hid, scan_ts;

            GET DIAGNOSTICS _VAR_inserts := ROW_COUNT; _VAR_TS := ( SELECT admin.f_getdatetime_minutes() ||':' );
            RAISE INFO '% % rows inserted in #mark_tracking_interval', _VAR_TS, _VAR_inserts;

            --Marking for DML action (insert, delete, update):
            INSERT INTO ldwh_postal_export_pre_model.dim_tracking_interval_staging
                WITH dml_action AS
                (
                    SELECT
                         iv.tracking_hid                                             AS ti_tracking_hid
                       , iv.barcode_hid                                              AS ti_barcode_hid
                       , iv.barcode_bk                                               AS ti_barcode_bk
                       , iv.scan_ts                                                  AS ti_scan_ts
                       , iv.scan_ts                                                  AS ti_valid_from_dt
                       , ( iv.scan_ts + admin.f_postal_barcode_reused_days() )::date AS ti_valid_to_dt
                       , GETDATE()                                                   AS ti_record_last_modified_ts
                       , iv.source_last_modified                                     AS ti_source_last_modified
                       --DML (data manipulation language) action:
                       , CASE
                            --To be processed interval (iv) overlaps and is later or eq to the interval in target (ov_iv), which means that the existing intervals already cover the new one:
                            --Window function is to evaluated potential overlap with 2 other tracking iv's with close boundaries this is possible.
                            --Then we want no updates, although the update condition where the start date is earlier would be true for one of these iv's.
                            WHEN  MAX ( CASE WHEN ov_iv.ti_barcode_hid is not null AND iv.scan_ts >= ov_iv.ti_valid_from_dt  THEN 1 ELSE 0 END ) OVER ( PARTITION BY iv.tracking_hid ) = 1
                                THEN 'n' --no action
                            --To be processed interval (iv) overlaps and is earlier than interval in target (ov_iv), which means target needs to be updated and recalculated on barcode level:
                            WHEN ov_iv.ti_barcode_hid is not null AND iv.scan_ts < ov_iv.ti_valid_from_dt
                                THEN 'u' --update
                            --No overlap or match on barcode found means the interval can be inserted directly:
                            WHEN ov_iv.ti_barcode_hid is null
                                THEN 'i' --insert
                       END::char(1)                                                  AS ti_dml_action
                    FROM
                       #mark_tracking_interval iv
                       --ldwh_postal_export_pre_model.sta_dim_tracking_interval_dml_action should become actual target dim_tracking_interval:
                       LEFT JOIN ldwh_postal_export_pre_model.dim_tracking_interval AS ov_iv
                                --Join to find overlapping intervals per barcode, ergo overlapping intervals (ov_iv):
                           ON       iv.barcode_hid = ov_iv.ti_barcode_hid
                                --Overlap and earlier than overlap start:
                                AND admin.f_overlapping_interval(
                                            iv.scan_ts,             iv.scan_ts + admin.f_postal_barcode_reused_days(),
                                            ov_iv.ti_valid_from_dt, ov_iv.ti_valid_to_dt
                                    ) = TRUE
                                --Invalidated iv's don't count for recalculation:
                                AND ov_iv.invalidation_ts is null
                    WHERE
                       --make sure the earliest scan timestamp is selected.
                       row_nr = 1
                )
                --insert statement that filters intervals that should not have an action.
                SELECT * FROM dml_action WHERE ti_dml_action IN ( 'i', 'u' );

            GET DIAGNOSTICS _VAR_inserts := ROW_COUNT; _VAR_TS := ( SELECT admin.f_getdatetime_minutes() ||':' );
            RAISE INFO '% % rows inserted in ldwh.sta_dim_tracking_interval_dml_action', _VAR_TS, _VAR_inserts;

            --Remove first item-group from #tracking_id_events:
            DELETE FROM
               #tracking_id_events
            USING
               #mark_tracking_interval
            WHERE 1=1
               AND #mark_tracking_interval.tracking_hid     = #tracking_id_events.tracking_hid
               AND #mark_tracking_interval.first_item_group = TRUE;

            --Set delete and ts vars:
            _VAR_deletes := ( SELECT sum(rows) FROM STL_DELETE WHERE query = pg_last_query_id() ); _VAR_TS := ( SELECT admin.f_getdatetime_minutes() ||':' );
            RAISE INFO '% % rows deleted from #tracking_id_events', _VAR_TS, _VAR_deletes;

            --Truncate marking table:
            TRUNCATE #mark_tracking_interval; RAISE INFO 'End run %', _VAR_iterable;

            --End loop increase iterable:
            _VAR_iterable := _VAR_iterable + 1;

            --Exit-loop criteria:
            EXIT WHEN ( SELECT Count(*) FROM #tracking_id_events ) = 0;
          END LOOP;
    --?? Insert dummy var.?? this is to not evaluated already evaluated delta's when staging is empty.

    EXCEPTION WHEN OTHERS THEN RAISE EXCEPTION 'Error %, State %', SQLERRM, SQLSTATE;
END
$$;

